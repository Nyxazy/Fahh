from Logic.Commands.Client.LogicBoxDataCommand import LogicBoxDataCommand
from Utils.Reader import BSMessageReader
from Logic.Shop import Shop
from Logic.LogicBuy import LogicBuy
from database.DataBase import DataBase
from Utils.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply
class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.offer_index = self.read_Vint()


    def process(self):
        Shop.loadOffers(self)
        offers = self.offers
        if self.offer_index < 0 or self.offer_index >= len(offers):
            return
        offer = offers[self.offer_index]
        if int(self.player.low_id) in offer.get("WhoBuyed", []):
            return

        item_ids = offer['ID']
        multipliers = offer['Multiplier']
        brawlers = offer['BrawlerID']
        skins = offer['SkinID']
        cost = int(offer.get('Cost', 0) or 0)
        currency = int(offer.get('ShopType', 0) or 0)

        for item_id, brawler_id in zip(item_ids, brawlers):
            if int(item_id) == 8 and int(brawler_id) != 0:
                if int(self.player.UnlockedBrawlers.get(str(int(brawler_id)), 0)) != 1:
                    return

        if currency == 0 and self.player.gems < cost:
            return
        if currency == 1 and self.player.gold < cost:
            return
        if currency in (2, 3) and self.player.starpoints < cost:
            return

        if currency == 0:
            self.player.gems -= cost
            DataBase.replaceValue(self, 'gems', self.player.gems)
        elif currency == 1:
            self.player.gold -= cost
            DataBase.replaceValue(self, 'gold', self.player.gold)
        elif currency in (2, 3):
            self.player.starpoints -= cost
            DataBase.replaceValue(self, 'starpoints', self.player.starpoints)

        first_id = int(item_ids[0])
        if first_id in [6, 10, 14]:
            if first_id == 6:
                Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 10}).send()
            elif first_id == 10:
                Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 11}).send()
            elif first_id == 14:
                Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 12}).send()
            Shop.UpdateOfferData(self, self.offer_index)
            return

        mapped = []
        type_map = {
            1: 1,
            16: 2,
            5: 3,
            19: 8,
            9: 4,
            8: 5,
            3: 6,
            4: 7,
            24: 7
        }
        for item_id in item_ids:
            mapped.append(type_map.get(int(item_id), 0))

        if any(int(item_id) == 8 for item_id in item_ids):
            for brawler_id, amount in zip(brawlers, multipliers):
                brawler_id = int(brawler_id)
                amount = int(amount)
                if brawler_id != 0 and amount > 0:
                    current_points = int(self.player.brawlerPoints.get(str(brawler_id), 0) or 0)
                    self.player.brawlerPoints[str(brawler_id)] = min(current_points + amount, 1410)
            DataBase.replaceValue(self, 'brawlerPoints', self.player.brawlerPoints)

        if item_ids[0] != 0 and item_ids[1] != 0 and item_ids[2] != 0:
            LogicBuy(self.client, self.player, mapped[0], mapped[1], mapped[2], multipliers[0], multipliers[1], multipliers[2], brawlers[0], brawlers[1], brawlers[2], skins[0], skins[1], skins[2]).send()
        elif item_ids[0] != 0 and item_ids[1] != 0:
            LogicBuy(self.client, self.player, mapped[0], mapped[1], 0, multipliers[0], multipliers[1], 0, brawlers[0], brawlers[1], 0, skins[0], skins[1], 0).send()
        else:
            LogicBuy(self.client, self.player, mapped[0], 0, 0, multipliers[0], 0, 0, brawlers[0], 0, 0, skins[0], 0, 0).send()
        Shop.UpdateOfferData(self, self.offer_index)
