from Utils.Writer import Writer
from datetime import datetime
from ping3 import ping
from shared import connected_ips
from Logic.Premium import sync_player, is_premium, format_utc

class LobbyInfoMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.domain = 'f1.aurorix.net'

    def get_ping(self):
        """Calculate the ping in milliseconds or return 'N/A'."""
        ping_seconds = ping(self.domain)
        if ping_seconds is None:
            return 'N/A'

        ping_ms = int(ping_seconds * 40000)
        return '<1' if ping_ms == 0 and ping_seconds > 0 else ping_ms

    def encode(self):
        now = datetime.now()
        ping_ms = self.get_ping()
        ip_count = len(connected_ips)
        sync_player(self.player)
        premium_active = is_premium(player=self.player)
        premium_level = getattr(self.player, 'premium_level', 0)
        premium_end = getattr(self.player, 'premium_end_time', 0)
        premium_line = f'Premium: {premium_active}'
        if premium_active:
            premium_line += f' | Level: {premium_level} | Until: {format_utc(premium_end)}'
        message = (
            f'APPLE BRAWL\n'
            f'Версия: 29.231\n'
            f'TG: @Boost_Fair\n'
            f'Пинг: {ping_ms}ms\n'
            f'Онлайн: {ip_count}\n'
            f'{premium_line}\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n:)\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n'
        )
        self.writeVint(0)
        self.writeString(message)
        self.writeVint(0)