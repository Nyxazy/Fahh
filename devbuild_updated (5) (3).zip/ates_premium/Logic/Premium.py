import calendar
import sqlite3
import time
from datetime import datetime

DB_PATH = "database/Player/plr.db"
DEFAULT_MONTHS = 1
DEFAULT_LEVEL = 1


def utc_now_ts() -> int:
    return int(time.time())


def add_months(timestamp: int, months: int = DEFAULT_MONTHS) -> int:
    months = max(1, int(months or DEFAULT_MONTHS))
    dt = datetime.utcfromtimestamp(max(0, int(timestamp or utc_now_ts())))
    month_index = dt.month - 1 + months
    year = dt.year + month_index // 12
    month = month_index % 12 + 1
    last_day = calendar.monthrange(year, month)[1]
    day = min(dt.day, last_day)
    new_dt = dt.replace(year=year, month=month, day=day)
    return int(calendar.timegm(new_dt.utctimetuple()))


def format_utc(timestamp: int) -> str:
    if not timestamp:
        return "never"
    return datetime.utcfromtimestamp(int(timestamp)).strftime("%Y-%m-%d %H:%M:%S UTC")


def ensure_premium_columns(conn=None):
    close = False
    if conn is None:
        conn = sqlite3.connect(DB_PATH)
        close = True
    cur = conn.cursor()
    try:
        cur.execute("PRAGMA table_info(plrs)")
        cols = {row[1] for row in cur.fetchall()}
        if "premiumLevel" not in cols:
            cur.execute("ALTER TABLE plrs ADD COLUMN premiumLevel INT DEFAULT 0")
        if "premiumEndTime" not in cols:
            cur.execute("ALTER TABLE plrs ADD COLUMN premiumEndTime INT DEFAULT 0")
        if "premiumExpireNotice" not in cols:
            cur.execute("ALTER TABLE plrs ADD COLUMN premiumExpireNotice INT DEFAULT 0")
        if "premiumLastRewardTime" not in cols:
            cur.execute("ALTER TABLE plrs ADD COLUMN premiumLastRewardTime INT DEFAULT 0")
        conn.commit()
    except Exception:
        pass
    finally:
        if close:
            conn.close()


def _row_to_premium(row):
    if not row:
        return 0, 0, 0
    try:
        return int(row[0] or 0), int(row[1] or 0), int(row[2] or 0)
    except Exception:
        return 0, 0, 0


def premium_player_exists(lowid: int) -> bool:
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM plrs WHERE lowID=?", (int(lowid),))
    exists = cur.fetchone() is not None
    conn.close()
    return exists


def get_premium_by_lowid(lowid: int):
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT premiumLevel, premiumEndTime, premiumExpireNotice FROM plrs WHERE lowID=?",
        (int(lowid),),
    )
    row = cur.fetchone()
    conn.close()
    return _row_to_premium(row)


def get_premium_by_token(token: str):
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT premiumLevel, premiumEndTime, premiumExpireNotice FROM plrs WHERE token=?",
        (token,),
    )
    row = cur.fetchone()
    conn.close()
    return _row_to_premium(row)


def _update_by_lowid(lowid: int, level: int, end_time: int, notice: int = 0):
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute(
            "UPDATE plrs SET premiumLevel=?, premiumEndTime=?, premiumExpireNotice=?, vip=0 WHERE lowID=?",
            (int(level), int(end_time), int(notice), int(lowid)),
        )
    except Exception:
        cur.execute(
            "UPDATE plrs SET premiumLevel=?, premiumEndTime=?, premiumExpireNotice=? WHERE lowID=?",
            (int(level), int(end_time), int(notice), int(lowid)),
        )
    conn.commit()
    conn.close()


def _update_by_token(token: str, level: int, end_time: int, notice: int = 0):
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute(
            "UPDATE plrs SET premiumLevel=?, premiumEndTime=?, premiumExpireNotice=?, vip=0 WHERE token=?",
            (int(level), int(end_time), int(notice), token),
        )
    except Exception:
        cur.execute(
            "UPDATE plrs SET premiumLevel=?, premiumEndTime=?, premiumExpireNotice=? WHERE token=?",
            (int(level), int(end_time), int(notice), token),
        )
    conn.commit()
    conn.close()


def grant_premium_lowid(lowid: int, months: int = DEFAULT_MONTHS, level: int = DEFAULT_LEVEL):
    if not premium_player_exists(lowid):
        raise ValueError(f"player lowID {lowid} not found")
    level = max(1, int(level or DEFAULT_LEVEL))
    level = min(level, 3)
    months = max(1, int(months or DEFAULT_MONTHS))
    old_level, old_end, _ = get_premium_by_lowid(lowid)
    base = old_end if old_level > 0 and old_end > utc_now_ts() else utc_now_ts()
    new_end = add_months(base, months)
    _update_by_lowid(lowid, level, new_end, 0)
    set_premium_last_reward_lowid(lowid, 0)
    return new_end


def revoke_premium_lowid(lowid: int):
    if not premium_player_exists(lowid):
        raise ValueError(f"player lowID {lowid} not found")
    _update_by_lowid(lowid, 0, 0, 0)
    set_premium_last_reward_lowid(lowid, 0)


def expire_if_needed(player=None, lowid=None, token=None) -> bool:
    if player is not None:
        level = int(getattr(player, "premium_level", 0) or 0)
        end = int(getattr(player, "premium_end_time", 0) or 0)
        notice = int(getattr(player, "premium_expire_notice", 0) or 0)
        token = getattr(player, "token", token)
        lowid = getattr(player, "low_id", lowid)
    elif token is not None:
        level, end, notice = get_premium_by_token(token)
    else:
        level, end, notice = get_premium_by_lowid(lowid)

    if level > 0 and end and end <= utc_now_ts():
        if token:
            _update_by_token(token, 0, 0, 1)
        elif lowid is not None:
            _update_by_lowid(lowid, 0, 0, 1)
        if player is not None:
            player.premium_level = 0
            player.premium_end_time = 0
            player.premium_expire_notice = 1
            player.vip = 0
        return True
    return False


def sync_player(player):
    try:
        level = int(getattr(player, "premium_level", 0) or 0)
        end = int(getattr(player, "premium_end_time", 0) or 0)
        notice = int(getattr(player, "premium_expire_notice", 0) or 0)
        if not hasattr(player, "premium_level") or (level == 0 and end == 0 and getattr(player, "low_id", 0)):
            level, end, notice = get_premium_by_lowid(player.low_id)
        player.premium_level = level
        player.premium_end_time = end
        player.premium_expire_notice = notice
        try:
            player.premium_last_reward_time = get_premium_last_reward_lowid(player.low_id)
        except Exception:
            player.premium_last_reward_time = 0
        player.vip = 0
        expire_if_needed(player=player)
    except Exception:
        player.premium_level = 0
        player.premium_end_time = 0
        player.premium_expire_notice = 0
        player.premium_last_reward_time = 0
        player.vip = 0
    return player


def clear_expire_notice(player):
    try:
        player.premium_expire_notice = 0
        if getattr(player, "token", None):
            _update_by_token(player.token, int(getattr(player, "premium_level", 0) or 0), int(getattr(player, "premium_end_time", 0) or 0), 0)
    except Exception:
        pass


def is_premium(player=None, lowid=None) -> bool:
    if player is not None:
        sync_player(player)
        return int(getattr(player, "premium_level", 0) or 0) > 0 and int(getattr(player, "premium_end_time", 0) or 0) > utc_now_ts()
    level, end, _ = get_premium_by_lowid(lowid)
    if level > 0 and end <= utc_now_ts():
        expire_if_needed(lowid=lowid)
        return False
    return level > 0


def premium_level(player=None, lowid=None) -> int:
    if player is not None:
        return int(getattr(sync_player(player), "premium_level", 0) or 0)
    level, end, _ = get_premium_by_lowid(lowid)
    if level > 0 and end <= utc_now_ts():
        expire_if_needed(lowid=lowid)
        return 0
    return int(level or 0)


def premium_high_name_color(name_color: int, player=None, lowid=None) -> int:
    return 43000000 + int(name_color) if is_premium(player=player, lowid=lowid) else 0


def premium_trophy_bonus(base_trophies: int, level: int) -> int:
    base = int(base_trophies or 0)
    if base <= 0 or level <= 0:
        return 0
    return {1: 8, 2: 19, 3: 30}.get(min(int(level), 3), 0)


def premium_display_name(name: str, player=None, lowid=None) -> str:
    return f"[ VIP ] ( {name} )" if is_premium(player=player, lowid=lowid) else str(name)


def premium_reward_config(level: int):
    level = min(max(int(level or 0), 0), 3)
    rewards = {
        1: {"gems": 10, "gold": 2000, "days": 8},
        2: {"gems": 25, "gold": 6000, "days": 7},
        3: {"gems": 60, "gold": 10000, "days": 6},
    }
    return rewards.get(level)


def get_premium_last_reward_lowid(lowid: int) -> int:
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute("SELECT premiumLastRewardTime FROM plrs WHERE lowID=?", (int(lowid),))
        row = cur.fetchone()
        return int(row[0] or 0) if row else 0
    finally:
        conn.close()


def set_premium_last_reward_lowid(lowid: int, timestamp: int):
    ensure_premium_columns()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("UPDATE plrs SET premiumLastRewardTime=? WHERE lowID=?", (int(timestamp), int(lowid)))
    conn.commit()
    conn.close()


def premium_reward_due(player=None, lowid=None) -> bool:
    if player is not None:
        sync_player(player)
        lowid = getattr(player, "low_id", lowid)
        level = int(getattr(player, "premium_level", 0) or 0)
    else:
        level = premium_level(lowid=lowid)
    if level <= 0:
        return False
    cfg = premium_reward_config(level)
    if not cfg:
        return False
    last = int(getattr(player, "premium_last_reward_time", 0) or 0) if player is not None else get_premium_last_reward_lowid(lowid)
    return last <= 0 or utc_now_ts() - last >= cfg["days"] * 86400


def premium_pending_reward(player=None, lowid=None):
    if player is not None:
        sync_player(player)
        level = int(getattr(player, "premium_level", 0) or 0)
    else:
        level = premium_level(lowid=lowid)
    if not premium_reward_due(player=player, lowid=lowid):
        return None
    return premium_reward_config(level)


def mark_premium_reward_claimed(player=None, lowid=None):
    ts = utc_now_ts()
    if player is not None:
        lowid = getattr(player, "low_id", lowid)
        player.premium_last_reward_time = ts
    if lowid is not None:
        set_premium_last_reward_lowid(lowid, ts)
    return ts


def premium_remaining_seconds(player) -> int:
    sync_player(player)
    return max(0, int(getattr(player, "premium_end_time", 0) or 0) - utc_now_ts())
