import json
import sqlite3
import time

DB_PATH = "database/Player/plr.db"


def _now():
    return int(time.time())


def ensure_notification_columns(conn=None):
    close = False
    if conn is None:
        conn = sqlite3.connect(DB_PATH)
        close = True
    try:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(plrs)")
        cols = {row[1] for row in cur.fetchall()}
        if "notifications" not in cols:
            cur.execute("ALTER TABLE plrs ADD COLUMN notifications TEXT DEFAULT '[]'")
        cur.execute("PRAGMA table_info(plrs)")
        cols = {row[1] for row in cur.fetchall()}
        if "premiumLastRewardTime" in cols and "notifications" in cols:
            cur.execute("SELECT lowID, premiumLastRewardTime, notifications FROM plrs")
            for lowid, last_reward, notifications in cur.fetchall():
                lr = str(last_reward) if last_reward is not None else ""
                nf = str(notifications) if notifications is not None else ""
                if lr.strip().startswith("[") or lr.strip().startswith("{"):
                    try:
                        json.loads(lr)
                        replacement = lr
                        if nf.strip().startswith("[") or nf.strip().startswith("{"):
                            try:
                                json.loads(nf)
                                replacement = nf
                            except Exception:
                                pass
                        cur.execute("UPDATE plrs SET notifications=?, premiumLastRewardTime=0 WHERE lowID=?", (replacement, lowid))
                    except Exception:
                        cur.execute("UPDATE plrs SET premiumLastRewardTime=0 WHERE lowID=?", (lowid,))
        conn.commit()
    except Exception:
        pass
    finally:
        if close:
            conn.close()


class Notification:
    def __init__(self, **kwargs):
        self.Id = int(kwargs.get("Id", kwargs.get("id", 81)) or 81)
        self.Index = int(kwargs.get("Index", kwargs.get("index", 0)) or 0)
        self.IsViewed = bool(kwargs.get("IsViewed", kwargs.get("isViewed", kwargs.get("Read", False))))
        self.TimePassed = int(kwargs.get("TimePassed", kwargs.get("timePassed", 0)) or 0)
        self.CreatedAt = int(kwargs.get("CreatedAt", kwargs.get("Timer", _now())) or _now())
        self.MessageEntry = kwargs.get("MessageEntry", kwargs.get("Desc", "")) or ""
        self.PrimaryMessageEntry = kwargs.get("PrimaryMessageEntry", "") or ""
        self.SecondaryMessageEntry = kwargs.get("SecondaryMessageEntry", "") or ""
        self.ButtonMessageEntry = kwargs.get("ButtonMessageEntry", "") or ""
        self.FileLocation = kwargs.get("FileLocation", "") or ""
        self.FileSha = kwargs.get("FileSha", "") or ""
        self.ExtLint = kwargs.get("ExtLint", "") or ""
        self.HeroesIds = list(kwargs.get("HeroesIds", []))
        self.HeroesTrophies = list(kwargs.get("HeroesTrophies", []))
        self.HeroesTrophiesReseted = list(kwargs.get("HeroesTrophiesReseted", []))
        self.StarpointsAwarded = list(kwargs.get("StarpointsAwarded", []))
        self.DonationCount = int(kwargs.get("DonationCount", kwargs.get("Gems", 0)) or 0)
        self.GoldCount = int(kwargs.get("GoldCount", kwargs.get("Gold", 0)) or 0)
        self.Kind = kwargs.get("Kind", "") or ""
        self.SkinID = int(kwargs.get("SkinID", 0) or 0)
        self.BrawlerID = int(kwargs.get("BrawlerID", 0) or 0)

    def to_dict(self):
        return {
            "Id": self.Id,
            "Index": self.Index,
            "IsViewed": self.IsViewed,
            "TimePassed": self.TimePassed,
            "CreatedAt": self.CreatedAt,
            "MessageEntry": self.MessageEntry,
            "PrimaryMessageEntry": self.PrimaryMessageEntry,
            "SecondaryMessageEntry": self.SecondaryMessageEntry,
            "ButtonMessageEntry": self.ButtonMessageEntry,
            "FileLocation": self.FileLocation,
            "FileSha": self.FileSha,
            "ExtLint": self.ExtLint,
            "HeroesIds": self.HeroesIds,
            "HeroesTrophies": self.HeroesTrophies,
            "HeroesTrophiesReseted": self.HeroesTrophiesReseted,
            "StarpointsAwarded": self.StarpointsAwarded,
            "DonationCount": self.DonationCount,
            "GoldCount": self.GoldCount,
            "Kind": self.Kind,
            "SkinID": self.SkinID,
            "BrawlerID": self.BrawlerID,
        }

    def encode(self, stream):
        self.TimePassed = max(0, _now() - int(self.CreatedAt or _now()))
        stream.writeVint(self.Id)
        stream.writeInt(self.Index)
        stream.writeBoolean(self.IsViewed)
        stream.writeInt(self.TimePassed)
        stream.writeString(self.MessageEntry)
        if self.Id == 83:
            stream.writeInt(0)
            stream.writeString(self.PrimaryMessageEntry)
            stream.writeInt(0)
            stream.writeString(self.SecondaryMessageEntry)
            stream.writeInt(0)
            stream.writeString(self.ButtonMessageEntry)
            stream.writeString(self.FileLocation)
            stream.writeString(self.FileSha)
            stream.writeString(self.ExtLint)
        if self.Id == 79:
            count = min(len(self.HeroesIds), len(self.HeroesTrophies), len(self.HeroesTrophiesReseted), len(self.StarpointsAwarded))
            stream.writeVint(count)
            for i in range(count):
                stream.writeVint(self.HeroesIds[i])
                stream.writeVint(self.HeroesTrophies[i])
                stream.writeVint(self.HeroesTrophiesReseted[i])
                stream.writeVint(self.StarpointsAwarded[i])
        else:
            stream.writeVint(0)
        if self.Id == 89:
            stream.writeVint(self.DonationCount)
        elif self.Id == 94:
            stream.writeVint(29000000 + self.SkinID)
        elif self.Id == 93:
            stream.writeVint(1)
            stream.writeVint(16000000 + self.BrawlerID)


class NotificationFactory:
    def __init__(self, notifications=None):
        self.NotificationList = notifications or []
        self.reindex()

    def reindex(self):
        for i, n in enumerate(self.NotificationList):
            n.Index = i

    def add(self, notification):
        if not isinstance(notification, Notification):
            notification = Notification(**notification)
        notification.Index = len(self.NotificationList)
        self.NotificationList.append(notification)
        return notification

    def get_index(self):
        return len(self.NotificationList)

    def get(self, index):
        if index < 0 or index >= len(self.NotificationList):
            return None
        return self.NotificationList[index]

    def remove(self, index):
        if index < 0 or index >= len(self.NotificationList):
            return False
        self.NotificationList.pop(index)
        self.reindex()
        return True

    def has_unviewed_kind(self, kind):
        return any((not n.IsViewed) and n.Kind == kind for n in self.NotificationList)

    def encode(self, stream):
        self.reindex()
        stream.writeVint(len(self.NotificationList))
        for notification in self.NotificationList:
            notification.encode(stream)

    def to_json(self):
        self.reindex()
        return json.dumps([n.to_dict() for n in self.NotificationList], ensure_ascii=False)

    @classmethod
    def from_json(cls, raw):
        if not raw:
            return cls([])
        try:
            data = json.loads(raw)
        except Exception:
            data = []
        items = []
        if isinstance(data, dict):
            data = list(data.values())
        for entry in data:
            if isinstance(entry, str):
                items.append(Notification(Id=81, MessageEntry=entry))
            elif isinstance(entry, dict):
                items.append(Notification(**entry))
        return cls(items)

    @classmethod
    def load(cls, lowid):
        ensure_notification_columns()
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("SELECT notifications FROM plrs WHERE lowID=?", (int(lowid),))
        row = cur.fetchone()
        conn.close()
        return cls.from_json(row[0] if row else "[]")

    def save(self, lowid):
        ensure_notification_columns()
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("UPDATE plrs SET notifications=? WHERE lowID=?", (self.to_json(), int(lowid)))
        conn.commit()
        conn.close()


def default_welcome_notifications():
    factory = NotificationFactory()
    factory.add(Notification(
        Id=83,
        PrimaryMessageEntry="Welcome",
        SecondaryMessageEntry="Welcome to the server!",
        ButtonMessageEntry="OK",
        FileLocation="pop_up_1920x1235_welcome.png",
        FileSha="",
        ExtLint=""
    ))
    return factory.to_json()


def add_notification_lowid(lowid, message="", kind=81, **kwargs):
    factory = NotificationFactory.load(lowid)
    notification = build_notification(message=message, kind=kind, **kwargs)
    factory.add(notification)
    factory.save(lowid)
    return notification


def build_notification(message="", kind=81, **kwargs):
    if isinstance(kind, str):
        kind = int(kind)
    if kind >= 29000000:
        return Notification(Id=94, MessageEntry=message, SkinID=kind - 29000000, **kwargs)
    if kind >= 16000000:
        return Notification(Id=93, MessageEntry=message, BrawlerID=kind - 16000000, **kwargs)
    if kind == 83:
        return Notification(Id=83, MessageEntry=message, PrimaryMessageEntry=kwargs.get("PrimaryMessageEntry", message), SecondaryMessageEntry=kwargs.get("SecondaryMessageEntry", ""), ButtonMessageEntry=kwargs.get("ButtonMessageEntry", "OK"), FileLocation=kwargs.get("FileLocation", ""), FileSha=kwargs.get("FileSha", ""), ExtLint=kwargs.get("ExtLint", ""), Kind=kwargs.get("Kind", ""))
    if kind == 89:
        return Notification(Id=89, MessageEntry=message, DonationCount=kwargs.get("DonationCount", kwargs.get("Gems", 0)), GoldCount=kwargs.get("GoldCount", kwargs.get("Gold", 0)), Kind=kwargs.get("Kind", ""))
    if kind == 79:
        return Notification(Id=79, MessageEntry=message, HeroesIds=kwargs.get("HeroesIds", []), HeroesTrophies=kwargs.get("HeroesTrophies", []), HeroesTrophiesReseted=kwargs.get("HeroesTrophiesReseted", []), StarpointsAwarded=kwargs.get("StarpointsAwarded", []), Kind=kwargs.get("Kind", ""))
    return Notification(Id=81, MessageEntry=message, Kind=kwargs.get("Kind", ""))


def ensure_player_notifications(player):
    from Logic.Premium import premium_pending_reward, mark_premium_reward_claimed
    lowid = int(getattr(player, "low_id", 0) or 0)
    factory = NotificationFactory.load(lowid)
    if getattr(player, "premium_expire_notice", 0) and not factory.has_unviewed_kind("premium_expired"):
        factory.add(Notification(Id=81, MessageEntry="Your Premium has expired. Renew it to keep Premium bonuses.", Kind="premium_expired"))
        try:
            from Logic.Premium import clear_expire_notice
            clear_expire_notice(player)
        except Exception:
            pass
    reward = premium_pending_reward(player=player)
    if reward and not factory.has_unviewed_kind("premium_reward"):
        factory.add(Notification(Id=89, MessageEntry=f"Premium reward: {reward['gems']} gems and {reward['gold']} coins.", DonationCount=reward["gems"], GoldCount=reward["gold"], Kind="premium_reward"))
        mark_premium_reward_claimed(player=player)
    factory.save(lowid)
    return factory
