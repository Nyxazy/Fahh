import time
import sqlite3
import threading

class AntiCheat:


    def __init__(self, server):
        self.server = server
        self.ip_warning_counts = {}
        self.ip_lock = threading.Lock()
        self.ip_cooldown_seconds = 60 * 60  

    def check_ip(self, ip):
        """Hızlı IP kontrolü. True dönerse IP engellenecek."""
        
        if ip in self.server.blocked_ips:
            return True

     
        with self.ip_lock:
            cnt = self.ip_warning_counts.get(ip, 0)
            if cnt >= 20:
                
                self.block_ip(ip, reason="ip_warning_threshold")
                return True

        return False

    def record_packet(self, ip, packet_id, length):
        """Basit heuristik: kısa zamanda çok sayıda paket gönderiliyorsa uyarı sayısını arttır."""
    
        if length < 16:
            with self.ip_lock:
                self.ip_warning_counts[ip] = self.ip_warning_counts.get(ip, 0) + 1

      
        with self.ip_lock:
            if self.ip_warning_counts.get(ip, 0) >= 22:
                self.block_ip(ip, reason="packet_flood")

    def analyze_player(self, player, packet_id, data):
        """Oyun içi anormallikleri kontrol etmek için placeholder fonksiyon.
        Buraya oyuncu davranışı analizi eklenecek (hızlı eşya verme, anormal kaynak artışı vb.).
        Eğer şüpheli ise karantinaya al.
        """
        try:
          
            return False
        except Exception:
            return False

    def block_ip(self, ip, reason="unknown"):
        """IP'yi sunucunun blok listesini ekle ve config.json'u güncelle (core.py'de kullanılan mekanizma).
        Ayrıca blok zamanını kaydet."""
        try:
            self.server.blocked_ips.add(ip)
            self.block_timestamps[ip] = time.time()
            
            try:
                self.server.update_blocked_clients(ip)
            except Exception:
                pass
          
            try:
                self.server.log_blocked_ip(ip)
            except Exception:
                pass
        except Exception:
            pass

    def cleanup_expired_blocks(self):
        """Zaman aşımı dolan blokları temizler (isteğe bağlı)."""
        now = time.time()
        expired = []
        with self.ip_lock:
            for ip, ts in list(self.block_timestamps.items()):
                if now - ts > self.ip_cooldown_seconds:
                    expired.append(ip)
                    del self.block_timestamps[ip]
                    if ip in self.ip_warning_counts:
                        del self.ip_warning_counts[ip]

        for ip in expired:
            try:
                if ip in self.server.blocked_ips:
                    self.server.blocked_ips.discard(ip)
                
                try:
                    with open('config.json', 'r', encoding='utf-8') as f:
                        cfg = __import__('json').load(f)
                    if 'block' in cfg and ip in cfg['block']:
                        cfg['block'].remove(ip)
                        with open('config.json', 'w', encoding='utf-8') as f:
                            __import__('json').dump(cfg, f, indent=4)
                except Exception:
                    pass
            except Exception:
                pass

    def start_cleanup_loop(self, interval=600):
        def loop():
            while True:
                time.sleep(interval)
                try:
                    self.cleanup_expired_blocks()
                except Exception:
                    pass

        t = threading.Thread(target=loop, daemon=True)
        t.start()
