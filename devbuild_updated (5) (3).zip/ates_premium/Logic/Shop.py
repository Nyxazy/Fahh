import json
import os
import random
from datetime import datetime, timedelta
from Files.CsvReader import CsvReader


class Shop:
    OFFERS_PATH = "JSON/offers.json"
    DAILY_DIR = "JSON/daily_offers"
    MAX_BRAWLER_POINTS = 1410
    DAILY_OFFERS_COUNT = 6
    SKIN_SUFFIXES = ["Witch", "Rockstar", "Beach", "Pink", "Panda", "White", "Hair", "Gold", "Rudo", "Bandita", "Rey", "Knight", "Caveman", "Dragon", "Summer", "Summertime", "Pheonix", "Greaser", "GirlPrereg", "Box", "Santa", "Chef", "Boombox", "Wizard", "Reindeer", "GalElf", "Hat", "Footbull", "Popcorn", "Hanbok", "Cny", "Valentine", "WarsBox", "Nightwitch", "Cart", "Shiba", "GalBunny", "Ms", "GirlHotrod", "Maple", "RR", "Mecha", "MechaWhite", "MechaNight", "FootbullBlue", "Outlaw", "Hogrider", "BoosterDefault", "Shark", "HoleBlue", "BoxMoonFestival", "WizardRed", "Pirate", "GirlWitch", "KnightDark", "DragonDark", "DJ", "Wolf", "Brown", "Total", "Sally", "Leonard", "SantaRope", "Gift", "GT", "SniperDefaultAddonBee", "SniperLadyBug", "SniperLadyBugAddonBee", "Virus", "BoosterVirus", "HoleStreetNinja", "Gamer", "Valentines", "Koala", "BearKoala", "TurretDefault", "AgentP", "Football", "Arena", "Tanuki", "Horus", "ArenaPSG", "DarkBunny", "College", "TurretTanuki", "TotemDefault", "Bazaar", "RedDragon", "Constructor", "Hawaii", "Barbking", "Trader", "StationSummer", "Silver", "SniperMonster", "BombMonster", "SniperMonsterAddonBee", "Bank", "Retro", "Ranger", "Tracksuit", "Knight", "RetroAddon"]

    def _attach_helpers(self):
        self._seconds_until_next_8utc = lambda: Shop._seconds_until_next_8utc(self)
        self._today_key = lambda: Shop._today_key(self)
        self._daily_path = lambda: Shop._daily_path(self)
        self._make_offer = lambda *args, **kwargs: Shop._make_offer(self, *args, **kwargs)
        self._load_json = lambda *args, **kwargs: Shop._load_json(self, *args, **kwargs)
        self._save_json = lambda *args, **kwargs: Shop._save_json(self, *args, **kwargs)
        self._possible_powerpoint_brawlers = lambda: Shop._possible_powerpoint_brawlers(self)
        self._safe_int = lambda *args, **kwargs: Shop._safe_int(self, *args, **kwargs)
        self._unlocked_brawlers = lambda: Shop._unlocked_brawlers(self)
        self._unlocked_skins = lambda: Shop._unlocked_skins(self)
        self._csv_data = lambda: Shop._csv_data(self)
        self._generate_csharp_daily_skin_offers = lambda: Shop._generate_csharp_daily_skin_offers(self)
        self._generate_csharp_daily_offers = lambda: Shop._generate_csharp_daily_offers(self)
        self._load_daily_offers = lambda: Shop._load_daily_offers(self)
        self._save_daily_offers = lambda offers: Shop._save_daily_offers(self, offers)
        self._load_global_custom_offers = lambda: Shop._load_global_custom_offers(self)
        self._mark_all_offers_viewed = lambda: Shop.MarkAllOffersViewed(self)

    def _seconds_until_next_8utc(self):
        now = datetime.utcnow()
        target = now.replace(hour=8, minute=0, second=0, microsecond=0)
        if now >= target:
            target += timedelta(days=1)
        return max(1, int((target - now).total_seconds()))

    def _today_key(self):
        now = datetime.utcnow()
        if now.hour < 8:
            now -= timedelta(days=1)
        return now.strftime("%Y-%m-%d")

    def _daily_path(self):
        os.makedirs(Shop.DAILY_DIR, exist_ok=True)
        low_id = int(getattr(getattr(self, "player", None), "low_id", 0) or 0)
        return os.path.join(Shop.DAILY_DIR, f"{low_id}.json")

    def _make_offer(self, item_id, amount=1, brawler=0, skin=0, currency=0, cost=0, old_cost=0, title="DAILY DEAL", bgr="offer_boxes", display=1, timer=None):
        if timer is None:
            timer = Shop._seconds_until_next_8utc(self)
        return {
            "ID": [int(item_id), 0, 0],
            "Multiplier": [int(amount), 0, 0],
            "BrawlerID": [int(brawler), 0, 0],
            "SkinID": [int(skin), 0, 0],
            "ShopType": int(currency),
            "Cost": int(cost),
            "Timer": int(timer),
            "OfferView": 0,
            "WhoBuyed": [],
            "ShopDisplay": int(display),
            "OldCost": int(old_cost),
            "OfferTitle": title,
            "OfferBGR": bgr,
            "ETType": 0,
            "ETMultiplier": 0,
            "DailyGenerated": True
        }

    def _load_json(self, path, default):
        try:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass
        return default

    def _save_json(self, path, data):
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

    def _possible_powerpoint_brawlers(self):
        player = getattr(self, "player", None)
        if player is None:
            return [0]
        unlocked = getattr(player, "UnlockedBrawlers", {}) or {}
        points = getattr(player, "brawlerPoints", {}) or {}
        power = getattr(player, "brawlerPowerLevel", {}) or {}
        result = []
        for brawler_id, is_unlocked in unlocked.items():
            try:
                bid = int(brawler_id)
                if bid >= 40:
                    continue
                if int(is_unlocked) != 1:
                    continue
                if int(points.get(str(bid), 0) or 0) >= Shop.MAX_BRAWLER_POINTS:
                    continue
                if int(power.get(str(bid), 0) or 0) >= 8:
                    continue
                result.append(bid)
            except Exception:
                continue
        if not result:
            result = [0]
        return result

    def _safe_int(self, value, default=0):
        try:
            if value == "" or value is None:
                return default
            return int(value)
        except Exception:
            return default

    def _unlocked_brawlers(self):
        unlocked = getattr(getattr(self, "player", None), "UnlockedBrawlers", {}) or {}
        result = []
        for brawler_id, state in unlocked.items():
            try:
                bid = int(brawler_id)
                if bid < 40 and int(state) == 1:
                    result.append(bid)
            except Exception:
                continue
        return result

    def _unlocked_skins(self):
        unlocked = getattr(getattr(self, "player", None), "UnlockedSkins", {}) or {}
        result = set()
        if isinstance(unlocked, dict):
            for skin_id, state in unlocked.items():
                try:
                    if int(state) == 1:
                        result.add(int(skin_id))
                except Exception:
                    continue
        elif isinstance(unlocked, list):
            for skin_id in unlocked:
                try:
                    result.add(int(skin_id))
                except Exception:
                    continue
        return result

    def _csv_data(self):
        reader = CsvReader()
        characters = reader.readCsv('GameAssets/csv_logic/characters.csv')
        skins = reader.readCsv('GameAssets/csv_logic/skins.csv')
        skin_confs = reader.readCsv('GameAssets/csv_logic/skin_confs.csv')
        return characters, skins, skin_confs

    def _generate_csharp_daily_skin_offers(self):
        low_id = int(getattr(getattr(self, "player", None), "low_id", 0) or 0)
        rng = random.Random(f"skins:{Shop._today_key(self)}:{low_id}")
        timer = Shop._seconds_until_next_8utc(self)
        characters, skins, skin_confs = Shop._csv_data(self)
        skin_by_name = {row[0]: (idx, row) for idx, row in enumerate(skins) if row and row[0]}
        conf_by_name = {row[0]: row for row in skin_confs if row and row[0]}
        unlocked_brawlers = Shop._unlocked_brawlers(self)
        unlocked_skins = Shop._unlocked_skins(self)
        normal_skins = []
        star_skins = []

        for brawler_id in unlocked_brawlers:
            if brawler_id < 0 or brawler_id >= len(characters):
                continue
            character_name = characters[brawler_id][0]
            for suffix in Shop.SKIN_SUFFIXES:
                entry = skin_by_name.get(character_name + suffix)
                if not entry:
                    continue
                skin_id, skin = entry
                if skin_id in unlocked_skins:
                    continue
                if skin[0] in ("RocketGirlRanger", "PowerLevelerKnight", "BlowerTrader"):
                    continue
                conf = conf_by_name.get(skin[1])
                if conf and conf[1] and conf[1] != character_name:
                    continue
                legendary_cost = Shop._safe_int(self, skin[7])
                gem_cost = Shop._safe_int(self, skin[8])
                coin_cost = Shop._safe_int(self, skin[9])
                if legendary_cost > 1:
                    star_skins.append((skin_id, brawler_id, legendary_cost))
                    continue
                if skin[0].endswith("Gold"):
                    silver_name = skin[0].replace("Gold", "Silver")
                    silver_entry = skin_by_name.get(silver_name)
                    if silver_entry and silver_entry[0] not in unlocked_skins:
                        continue
                if gem_cost > 0:
                    normal_skins.append((skin_id, brawler_id, 0, max(0, gem_cost - 1)))
                elif coin_cost > 0:
                    normal_skins.append((skin_id, brawler_id, 1, coin_cost))

        rng.shuffle(normal_skins)
        rng.shuffle(star_skins)
        offers = []
        for skin_id, brawler_id, currency, cost in normal_skins[:8]:
            offers.append(Shop._make_offer(self, 4, amount=1, brawler=brawler_id, skin=skin_id, currency=currency, cost=cost, old_cost=0, title="DAILY SKIN", bgr="0", display=0, timer=timer))
        for skin_id, brawler_id, cost in star_skins[:3]:
            offers.append(Shop._make_offer(self, 4, amount=1, brawler=brawler_id, skin=skin_id, currency=3, cost=cost, old_cost=0, title="DAILY STAR SKIN", bgr="offer_legendary", display=0, timer=timer))
        return offers

    def _generate_csharp_daily_offers(self):
        low_id = int(getattr(getattr(self, "player", None), "low_id", 0) or 0)
        rng = random.Random(f"{Shop._today_key(self)}:{low_id}")
        timer = Shop._seconds_until_next_8utc(self)
        offers = []
        offers.append(Shop._make_offer(self, 6, amount=1, currency=0, cost=0, old_cost=0, title="DAILY FREE BOX", bgr="offer_boxes", display=1, timer=timer))

        possible = Shop._possible_powerpoint_brawlers(self)
        has_mega = False
        offcount = 0
        i = 1
        while i < Shop.DAILY_OFFERS_COUNT:
            if possible and possible != [0]:
                if (not has_mega) and rng.randint(0, 99) > 33:
                    offers.append(Shop._make_offer(self, 10, amount=1, currency=0, cost=40, old_cost=80, title="DAILY MEGA BOX", bgr="offer_boxes", display=1, timer=timer))
                    has_mega = True
                    offcount += 1
                    i += 1
                    if i >= Shop.DAILY_OFFERS_COUNT:
                        break
                brawler = possible.pop(rng.randrange(len(possible))) if possible else 0
                count = rng.randint(16, 100)
                offers.append(Shop._make_offer(self, 8, amount=count, brawler=brawler, currency=1, cost=count * 2, old_cost=0, title="DAILY POWER POINTS", bgr="offer_coins", display=1, timer=timer))
                offcount += 1
                i += 1
            else:
                break

        if offcount < 5 and not has_mega:
            offers.append(Shop._make_offer(self, 10, amount=1, currency=0, cost=40, old_cost=80, title="DAILY MEGA BOX", bgr="offer_boxes", display=1, timer=timer))

        return offers[:Shop.DAILY_OFFERS_COUNT]

    def _load_daily_offers(self):
        path = Shop._daily_path(self)
        data = Shop._load_json(self, path, {})
        today = Shop._today_key(self)
        if data.get("key") != today or data.get("version") != 2 or not isinstance(data.get("offers"), list):
            data = {"key": today, "version": 2, "offers": Shop._generate_csharp_daily_offers(self) + Shop._generate_csharp_daily_skin_offers(self)}
            Shop._save_json(self, path, data)
        offers = data.get("offers", [])
        timer = Shop._seconds_until_next_8utc(self)
        changed = False
        for offer in offers:
            if isinstance(offer, dict) and offer.get("Timer") != timer:
                offer["Timer"] = timer
                changed = True
        if changed:
            Shop._save_json(self, path, data)
        return offers

    def _save_daily_offers(self, offers):
        Shop._save_json(self, Shop._daily_path(self), {"key": Shop._today_key(self), "version": 2, "offers": offers})

    def _load_global_custom_offers(self):
        data = Shop._load_json(self, Shop.OFFERS_PATH, {})
        result = []
        for key, offer in data.items():
            if not isinstance(offer, dict):
                continue
            if offer.get("DailyGenerated"):
                continue
            if str(offer.get("OfferTitle", "")).upper().startswith(("DAILY", "ЕЖЕДНЕВ")):
                continue
            result.append((key, offer))
        return result

    def loadOffers(self):
        Shop._attach_helpers(self)
        self.offer_sources = []
        daily = Shop._load_daily_offers(self)
        custom = Shop._load_global_custom_offers(self)
        self.offers = []
        for idx, offer in enumerate(daily):
            self.offers.append(offer)
            self.offer_sources.append(("daily", idx))
        for key, offer in custom:
            self.offers.append(offer)
            self.offer_sources.append(("global", key))

    def UpdateOfferData(self, i):
        Shop._attach_helpers(self)
        if not hasattr(self, "offer_sources"):
            Shop.loadOffers(self)
        if int(i) < 0 or int(i) >= len(self.offer_sources):
            return
        source, key = self.offer_sources[int(i)]
        low_id = int(self.player.low_id)
        if source == "daily":
            offers = Shop._load_daily_offers(self)
            if key >= len(offers):
                return
            buyers = offers[key].setdefault("WhoBuyed", [])
            if low_id not in buyers:
                buyers.append(low_id)
            Shop._save_daily_offers(self, offers)
        else:
            data = Shop._load_json(self, Shop.OFFERS_PATH, {})
            if key not in data:
                return
            buyers = data[key].setdefault("WhoBuyed", [])
            if low_id not in buyers:
                buyers.append(low_id)
            Shop._save_json(self, Shop.OFFERS_PATH, data)

    def RemoveOffer(self, i):
        data = Shop._load_json(self, Shop.OFFERS_PATH, {})
        data.pop(str(i), None)
        data = {str(idx): offer for idx, offer in enumerate(data.values())}
        Shop._save_json(self, Shop.OFFERS_PATH, data)

    def MarkAllOffersViewed(self):
        Shop._attach_helpers(self)
        daily = Shop._load_daily_offers(self)
        changed = False
        for offer in daily:
            if isinstance(offer, dict) and offer.get("OfferView") != 2:
                offer["OfferView"] = 2
                changed = True
        if changed:
            Shop._save_daily_offers(self, daily)

        data = Shop._load_json(self, Shop.OFFERS_PATH, {})
        changed = False
        for offer in data.values():
            if isinstance(offer, dict) and offer.get("OfferView") != 2:
                offer["OfferView"] = 2
                changed = True
        if changed:
            Shop._save_json(self, Shop.OFFERS_PATH, data)

    def EncodeShopOffers(self):
        Shop._attach_helpers(self)
        Shop.loadOffers(self)
        wow = self.offers
        count = len(wow)
        self.writeVint(count)
        for i in range(count):
            item = wow[i]
            if item['ID'][0] != 0 and item['ID'][1] != 0 and item['ID'][2] != 0:
                self.writeVint(3)
                self.writeVint(item['ID'][0])
                self.writeVint(item['Multiplier'][0])
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0])
                self.writeVint(item['ID'][1])
                self.writeVint(item['Multiplier'][1])
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1])
                self.writeVint(item['ID'][2])
                self.writeVint(item['Multiplier'][2])
                self.writeScId(16, item['BrawlerID'][2])
                self.writeVint(item['SkinID'][2])
            elif item['ID'][0] != 0 and item['ID'][1] != 0:
                self.writeVint(2)
                self.writeVint(item['ID'][0])
                self.writeVint(item['Multiplier'][0])
                self.writeScId(16, item['BrawlerID'][0])
                self.writeVint(item['SkinID'][0])
                self.writeVint(item['ID'][1])
                self.writeVint(item['Multiplier'][1])
                self.writeScId(16, item['BrawlerID'][1])
                self.writeVint(item['SkinID'][1])
            else:
                brawler_id = int(item['BrawlerID'][0])
                unlocked = int(getattr(self.player, 'UnlockedBrawlers', {}).get(str(brawler_id), 1)) == 1
                if brawler_id == 0 or unlocked:
                    self.writeVint(1)
                    self.writeVint(item['ID'][0])
                    self.writeVint(item['Multiplier'][0])
                    self.writeScId(16, item['BrawlerID'][0])
                    self.writeVint(item['SkinID'][0])
                else:
                    self.writeVint(1)
                    self.writeVint(1)
                    self.writeVint(0)
                    self.writeScId(16, 0)
                    self.writeVint(0)

            self.writeVint(item['ShopType'])
            self.writeVint(item['Cost'])
            self.writeVint(item['Timer'])
            self.writeVint(item['OfferView'])
            self.writeVint(100)

            already_bought = int(self.player.low_id) in item.get("WhoBuyed", [])
            brawler_id = int(item['BrawlerID'][0])
            locked = brawler_id != 0 and int(getattr(self.player, 'UnlockedBrawlers', {}).get(str(brawler_id), 1)) == 0
            self.writeBoolean(already_bought or locked)
            self.writeBoolean(False)
            self.writeVint(0 if locked else item['ShopDisplay'])
            self.writeVint(item['OldCost'])
            self.writeVint(0)
            self.writeInt(0)
            self.write_string_reference(item['OfferTitle'])
            self.writeBoolean(False)
            self.writeString(item['OfferBGR'])
            self.writeVint(0)
            self.writeBoolean(False)
            self.writeVint(item['ETType'])
            self.writeVint(item['ETMultiplier'])
