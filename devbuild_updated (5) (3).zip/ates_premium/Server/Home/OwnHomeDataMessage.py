from Utils.Writer import Writer
import json
from datetime import datetime
import time
from Logic.Premium import sync_player, premium_display_name
from Logic.Notifications import ensure_player_notifications

                                                                    
try:
    from Logic.Notifications import Notifications
except Exception:
    class Notifications:
        @staticmethod
        def GetNotifCount(writer):
            try:
                return len(getattr(writer.player, 'notifications', {}))
            except Exception:
                return 0

try:
    from database.DataBase import DataBase
except Exception:
    from database.DataBase import DataBase                                                   

try:
    from Utils.Helpers import Helpers
except Exception:
    class Helpers:
        NEWBPTIME = 0

try:
    from Logic.Shop import Shop
except Exception:
    class Shop:
        boxes = []
        token_doubler = {'Cost': 0, 'Amount': 0}
        gold = {'Cost': 0, 'Amount': 0}
        @staticmethod
        def EncodeShopOffers(writer):
            writer.writeVint(0)

try:
    from Logic.Quest import Quest
except Exception:
    class Quest:
        @staticmethod
        def EncodeQuest(writer):
            writer.writeVint(0)

try:
    from Logic.Tokens import Tokens
except Exception:
    class Tokens:
        @staticmethod
        def EncodeTokens(writer):
            writer.writeVint(0)

try:
    from Logic.EventSlots import EventSlots
except Exception:
    class EventSlots:
        @staticmethod
        def loadEvents(writer):
            return []
        @staticmethod
        def offset(writer):
            return None

try:
    from Server.Login.LoginFailedMessage import LoginFailedMessage
except Exception:
    class LoginFailedMessage(Writer):
        def __init__(self, client, player, msg=''):
            super().__init__(client)
            self.player = player
            self.msg = msg
            self.id = 20103
        def send(self):
            try:
                                                  
                self.buffer = b''
                self.buffer = self.id.to_bytes(2, 'big', signed=True)
                self.writeInt(0,3)
                try:
                    self.client.send(self.buffer)
                except Exception:
                    pass
            except Exception:
                pass

try:
    from Server.Home.BattleBan import BattleBan
except Exception:
    def BattleBan(client, player):
        return None

try:
    from Logic.MCbyLkPrtctrd.MilestonesClaimHelpByLkPrtctrd import MilestonesClaimHelpByLkPrtctrd as LkPrtctrd
    from Logic.MCbyLkPrtctrd.MilestonesClaimSupplyByLkPrtctrd import MilestonesClaimSupplyByLkPrtctrd as Supply
except Exception:
    class LkPrtctrd:
        @staticmethod
        def BrawlPassEncode(writer, client, player):
            writer.writeVint(0)
        @staticmethod
        def BrawlPassEncodeOld(writer, client, player):
            writer.writeVint(0)
    class Supply:
        def __init__(self, client, player, a, b):
            pass
        def send(self):
            return None

try:
    from Utils.Fingerprint import Fingerprint
except Exception:
    class Fingerprint:
        @staticmethod
        def loadFinger(path):
            return None

class OwnHomeDataMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player
        self.timestamp = int(datetime.timestamp(datetime.now()))

    def encode(self):
        db = DataBase()
        db.player = self.player
        try:
            db.client = self.client
        except Exception:
            pass
        try:
            db.loadAccount()
        except Exception:
            pass
        sync_player(self.player)

        self.writeVint(0)
        self.writeVint(self.timestamp)

                                              
        self.writeVint(getattr(self.player, 'trophies', 0))
        self.writeVint(getattr(self.player, 'highest_trophies', 0))
        self.writeVint(getattr(self.player, 'highest_trophies', 0))
        self.writeVint(getattr(self.player, 'Troproad', 0))
        self.writeVint(getattr(self.player, 'player_experience', 0))
        self.writeScId(28, getattr(self.player, 'profile_icon', 0))
        self.writeScId(43, getattr(self.player, 'name_color', 0))

                                                 
        self.writeVint(0)

                              
        self.writeVint(1)
        self.writeVint(29)
        self.writeVint(getattr(self.player, 'skin_id', 0))

                        
        unlocked_skins = getattr(self.player, 'UnlockedSkins', {})
        self.writeVint(len(unlocked_skins))
        for i in unlocked_skins:
            try:
                if unlocked_skins.get(str(i)) == 1:
                    self.writeScId(29, int(i))
                else:
                    self.writeScId(29, 0)
            except Exception:
                self.writeScId(29, 0)

                                                       
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(getattr(self.player, 'highest_trophies', 0))
        self.writeVint(1)
        self.writeVint(1)

        self.writeBoolean(False)
        self.writeVint(getattr(self.player, 'tokensdoubler', 0))

        self.writeVint(60)
        self.writeVint(90)
        self.writeVint(getattr(Helpers, 'NEWBPTIME', 0))

        self.writeVint(0)
        self.writeBoolean(False)
        self.writeBoolean(False)

        self.writeByte(4)
        for x in range(3):
            self.writeVint(2)

        self.writeVint(0)
        self.writeVint(0)

                         
        try:
            Shop.EncodeShopOffers(self)
        except Exception:
            try:
                Shop().EncodeShopOffers(self)
            except Exception:
                self.writeVint(0)

        try:
            Tokens.EncodeTokens(self)
        except Exception:
            try:
                Tokens().EncodeTokens(self)
            except Exception:
                self.writeVint(0)

        self.writeVint(getattr(self.player, 'tickets', 0))
        self.writeVint(1)

        self.writeScId(16, getattr(self.player, 'brawler_id', 0))
        self.writeString(getattr(self.player, 'Region', ''))
        self.writeString(str(getattr(self.player, 'ccc', '')))

                          
        self.writeVint(2)
        self.writeInt(4)
        self.writeLkPrtctrdInt(getattr(self.player, 'bet', 0))
        self.writeInt(3)
        self.writeLkPrtctrdInt(getattr(self.player, 'betTok', 0))

        self.writeVint(0)

                             
        try:
            LkPrtctrd.BrawlPassEncode(self, self.client, self.player)
            LkPrtctrd.BrawlPassEncodeOld(self, self.client, self.player)
        except Exception:
            self.writeVint(0)

        self.writeVint(1)
        self.writeVint(1)
        self.writeVint(1)

        try:
            Quest.EncodeQuest(self)
        except Exception:
            pass

                         
        emotes = getattr(self.player, 'emotes_id', [])
        self.writeBoolean(True)
        self.writeVint(len(emotes))
        for emotes_id in emotes:
            try:
                if getattr(self.player, 'UnlockedPins', {}).get(str(emotes_id)) == 1:
                    self.writeScId(52, emotes_id)
                    self.writeVint(1)
                    self.writeVint(1)
                    self.writeVint(1)
                else:
                    self.writeScId(52, 0)
                    self.writeVint(1)
                    self.writeVint(1)
                    self.writeVint(1)
            except Exception:
                self.writeScId(52, 0)
                self.writeVint(1)
                self.writeVint(1)
                self.writeVint(1)

        self.writeVint(2019049)
        self.writeVint(100)
        self.writeVint(10)

        for item in getattr(Shop, 'boxes', []):
            try:
                self.writeVint(item.get('Cost', 0))
                self.writeVint(item.get('Multiplier', 0))
            except Exception:
                self.writeVint(0)
                self.writeVint(0)

        self.writeVint(getattr(Shop, 'token_doubler', {}).get('Cost', 0))
        self.writeVint(getattr(Shop, 'token_doubler', {}).get('Amount', 0))

        self.writeVint(500)
        self.writeVint(50)
        self.writeVint(999900)

        events = []
        try:
            events = EventSlots.loadEvents(self)
        except Exception:
            events = []
        count = len(events)
        self.writeVint(count+1)
        for i in range(count+1):
            self.writeVint(i)

        try:
            EventSlots.offset(self)
        except Exception:
            pass

                             
        self.writeVint(0)
        self.writeVint(8)
        for i in [20, 35, 75, 140, 290, 480, 800, 1250]:
            self.writeVint(i)

        self.writeVint(8)
        for i in [1,2,3,4,5,10,15,20]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [10,30,80]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [6,20,60]:
            self.writeVint(i)

        self.writeVint(1)
        self.writeVint(getattr(Shop, 'gold', {}).get('Cost', 0))
        self.writeVint(1)
        self.writeVint(getattr(Shop, 'gold', {}).get('Amount', 0))

                         
        self.writeVint(0)
        self.writeVint(200)
        self.writeVint(20)
        self.writeVint(60)
        self.writeVint(10)
        self.writeVint(5)
        self.writeVint(6)
        self.writeVint(50)
        self.writeVint(120)
        self.writeBoolean(True)

        self.writeVint(1)
        self.writeScId(16, 39)
        self.writeInt(99999)
        self.writeInt(99999)

        self.writeVint(4)
        self.writeInt(1)
        self.writeInt(41000000 + getattr(self.player, 'theme', 0))

                            
        try:
            with open('config.json') as f:
                config = json.load(f)
        except Exception:
            config = {}

        self.writeInt(14)
        self.writeInt(1 if config.get('DoubleTokensEvent', False) else 0)

        self.writeInt(21)
        self.writeInt(1)

        self.writeInt(31)
        self.writeInt(0)

        self.writeVint(0)
        self.writeVint(0)

        self.writeInt(getattr(self.player, 'high_id', 0))
        self.writeInt(getattr(self.player, 'low_id', 0))

                                                 
        notif_count = 0
        try:
            notif_count = Notifications.GetNotifCount(self)
        except Exception:
            notif_count = 0

        premium_active = is_premium(player=self.player)
        premium_notice_count = 1 if premium_active else 0
        expired_notice_count = 1 if getattr(self.player, 'premium_expire_notice', 0) else 0
        reward = premium_pending_reward(player=self.player)
        reward_notice_count = 1 if reward else 0
        self.writeVint(2 + premium_notice_count + expired_notice_count + reward_notice_count + notif_count)
                                        
        self.writeVint(81)
        self.writeInt(1)
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("Добро пожаловать на наш приватный сервер OWN BRAWL!\n<c3>Админы:</c> @ZoxDev\n<c3>Бот:</c> @ownbrawlbot")
        self.writeVint(1)

        if premium_active:
            self.writeVint(81)
            self.writeInt(2283000)
            self.writeBoolean(False)
            self.writeInt(0)
            self.writeString(f"Premium active!\nLevel: {getattr(self.player, 'premium_level', 0)}\nExpires at: {format_utc(getattr(self.player, 'premium_end_time', 0))}")
            self.writeVint(1)

        if reward:
            self.writeVint(81)
            self.writeInt(2284000)
            self.writeBoolean(False)
            self.writeInt(0)
            self.writeString(f"Premium reward available!\nClaim {reward['gems']} gems and {reward['gold']} coins.\nNext reward every {reward['days']} days.")
            self.writeVint(1)

        if getattr(self.player, 'premium_expire_notice', 0):
            self.writeVint(81)
            self.writeInt(2283001)
            self.writeBoolean(False)
            self.writeInt(0)
            self.writeString("Your Premium has expired. Renew it to keep Premium bonuses.")
            self.writeVint(1)
            clear_expire_notice(self.player)

                                                             
        for index, notification in getattr(self.player, 'notifications', {}).items():
            try:
                nid = notification.get('ID', 0)
                if nid == 1:
                    self.writeVint(94)
                    self.writeInt(int(index))
                    self.writeBoolean(notification.get('Read', False))
                    self.writeInt(self.timestamp - notification.get('Timer', self.timestamp))
                    self.writeString(notification.get('Desc', ''))
                    self.writeVint(29000000 + notification.get('SkinID', 0))
                elif nid == 2:
                    self.writeVint(93)
                    self.writeInt(int(index))
                    self.writeBoolean(notification.get('Read', False))
                    self.writeInt(self.timestamp - notification.get('Timer', self.timestamp))
                    self.writeString(notification.get('Desc', ''))
                    self.writeVint(1)
                    self.writeVint(16000000 + notification.get('BrawlerID', 0))
                elif nid == 3:
                    self.writeVint(89)
                    self.writeInt(int(index))
                    self.writeBoolean(notification.get('Read', False))
                    self.writeInt(self.timestamp - notification.get('Timer', self.timestamp))
                    self.writeString(notification.get('Desc', ''))
                    self.writeVint(1)
                    self.writeVint(notification.get('Gems', 0))
                elif nid == 4:
                                               
                    self.writeVint(79)
                    self.writeInt(int(index))
                    self.writeBoolean(notification.get('Read', False))
                    self.writeInt(self.timestamp - notification.get('Timer', self.timestamp))
                    self.writeString("Сброс сезона")
                    opened_brawlers_count = sum(getattr(self.player, 'UnlockedBrawlers', {}).values())
                    self.writeVint(opened_brawlers_count)
                    total_starpoints = 0
                    for brawler_id, is_unlocked in getattr(self.player, 'UnlockedBrawlers', {}).items():
                        if is_unlocked == 1:
                            brawlers_trophies = self.player.brawlers_trophies.get(brawler_id, 0)
                            if brawlers_trophies > 500:
                                trophy_loss = int(brawlers_trophies * 0.3)
                                new_trophies = brawlers_trophies - trophy_loss
                                if new_trophies < 500:
                                    new_trophies = 500
                                    trophy_loss = brawlers_trophies - 500
                                actual_loss = trophy_loss
                                star_points_gained = actual_loss
                            else:
                                trophy_loss = 0
                                actual_loss = 0
                                star_points_gained = 0
                                new_trophies = brawlers_trophies
                            total_starpoints += star_points_gained
                            self.writeVint(16000000 + int(brawler_id))
                            self.writeVint(brawlers_trophies)
                            self.writeVint(actual_loss)
                            self.writeVint(star_points_gained)
                elif nid == 5:
                    self.writeVint(81)
                    self.writeInt(int(index))
                    self.writeBoolean(notification.get('Read', False))
                    self.writeInt(self.timestamp - notification.get('Timer', self.timestamp))
                    self.writeString(notification.get('Desc', ''))
                    self.writeVint(1)
            except Exception:
                continue

                                             
        self.writeVint(83)
        self.writeInt(0)
        self.writeBoolean(True)
        self.writeInt(0)
        self.writeString("ZoxDev")
        self.writeInt(0)
        self.writeString("Добро пожаловать в Speed Brawl!")
        self.writeInt(0)
        self.writeString("Поддержи наш проект купив гемы/випку!\nТакже заходи в наш тгк - @SpeedBrawlnw")
        self.writeInt(0)
        self.writeString("ТЕЛЕГРАМ")
        self.writeString("/b2d704b22b95a4d70f66e89da867a64b")
        self.writeString('3a35620676c1d08d12086257a5ae03eb612452d8')
        self.writeString("brawlstars://extlink?page=https%3A%2F%2Ft.me%2Fspeedbrawlnw")
        self.writeVint(3473)

        self.writeVint(0)
        self.writeBoolean(False)

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(getattr(self.player, 'high_id', 0))
        self.writeVint(getattr(self.player, 'low_id', 0))

        self.writeVint(0)
        self.writeVint(0)

        if getattr(self.player, 'name', '') == "VBC26":
            self.writeString("VBC26")
            self.writeVint(0)
        else:
            self.writeString(str(getattr(self.player, 'name', '')))
            self.writeVint(1)

        self.writeInt(0)

        self.writeVint(8)

                                                       
        card_unlock = getattr(self.player, 'card_unlock_id', [])
        self.writeVint(len(card_unlock) + 4)
        index = 0
        for unlock_id in card_unlock:
            self.writeScId(23, unlock_id)
            try:
                self.writeVint(self.player.UnlockedBrawlers.get(str(index), 1))
            except Exception:
                self.writeVint(1)
            index += 1

                   
        self.writeVint(5)
        self.writeVint(1)
        self.writeVint(0)

        self.writeVint(5)
        self.writeVint(8)
        self.writeVint(getattr(self.player, 'gold', 0))

        self.writeVint(5)
        self.writeVint(9)
        self.writeVint(0)

        self.writeVint(5)
        self.writeVint(10)
        self.writeVint(getattr(self.player, 'starpoints', 0))

                                  
        b_trophies = getattr(self.player, 'brawlers_trophies', {})
        self.writeVint(len(b_trophies))
        for b_id, trophies in b_trophies.items():
            self.writeScId(16, int(b_id))
            self.writeVint(trophies)

                         
        self.writeVint(len(b_trophies))
        for b_id, trophies in b_trophies.items():
            self.writeScId(16, int(b_id))
            self.writeVint(trophies)

        self.writeVint(0)

                                             
        b_points = getattr(self.player, 'brawlerPoints', {})
        self.writeVint(len(b_points))
        for b_id, val in b_points.items():
            self.writeScId(16, int(b_id))
            self.writeVint(val)

        b_power = getattr(self.player, 'brawlerPowerLevel', {})
        self.writeVint(len(b_power))
        for b_id, val in b_power.items():
            self.writeScId(16, int(b_id))
            self.writeVint(val)

                               
        sp = getattr(self.player, 'StarPowerUnlocked', {})
        self.writeVint(len(sp))
        for b_id, val in sp.items():
            self.writeScId(23, int(b_id))
            self.writeVint(val)

                  
        self.writeVint(len(getattr(self.player, 'UnlockedBrawlers', {})))
        for b_id, val in getattr(self.player, 'Brawler_newTag', {}).items():
            self.writeScId(16, int(b_id))
            self.writeVint(val)

        self.writeVint(getattr(self.player, 'gems', 0))
        self.writeVint(getattr(self.player, 'gems', 0))
        self.writeVint(1)
        self.writeVint(self.player.player_experience if getattr(self.player, 'player_experience', 0) >= 40 else 0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(2)
        self.writeVint(int(time.time()))
        try:
            db.replaceValue('online', 2)
        except Exception:
            pass

        try:
            settings = json.load(open('config.json', 'r'))
        except Exception:
            settings = {}

        if getattr(self.player, 'gold', 0) < 0:
            self.player.gold = 0
            try:
                db.replaceValue('gold', self.player.gold)
            except Exception:
                pass
        if getattr(self.player, 'gems', 0) < 0:
            self.player.gems = 0
            try:
                db.replaceValue('gems', self.player.gems)
            except Exception:
                pass


        if getattr(self.player, 'low_id', 0) in settings.get('banID', []):
            try:
                LoginFailedMessage(self.client, self.player, 'Ваш аккаунт заблокирован!').send()
            except Exception:
                pass

        try:
            BattleBan(self.client, self.player)
        except Exception:
            pass

        if getattr(self.player, 'BPTOKEN', 0) >= 53000:
            try:
                Supply(self.client, self.player, "BOXLkPrtctrd", {"BoxDID": 12}).send()
                self.player.BPTOKEN = 52500
                db.replaceValue('BPTOKEN', self.player.BPTOKEN)
            except Exception:
                pass
from Utils.Writer import Writer
from database.DataBase import DataBase
from Logic.Shop import Shop
import json
from datetime import datetime
from Logic.EventSlots import EventSlots
from Server.Login.LoginFailedMessage import LoginFailedMessage
from Server.Home.BattleBan import BattleBan
from Logic.MCbyLkPrtctrd.MilestonesClaimHelpByLkPrtctrd import MilestonesClaimHelpByLkPrtctrd as LkPrtctrd
from Utils.Fingerprint import Fingerprint
from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
class OwnHomeDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player
        self.timestamp = int(datetime.timestamp(datetime.now()))

    def encode(self):
        DataBase.loadAccount(self)
        sync_player(self.player)

        self.writeVint(0)
        self.writeVint(self.timestamp)             

        self.writeVint(self.player.trophies)                   
        self.writeVint(self.player.trophies)                               
        self.writeVint(self.player.highest_trophies)
        self.writeVint(self.player.Troproad)
        self.writeVint(220+self.player.player_experience)              
                                                   
        self.writeScId(28, self.player.profile_icon)                  
        self.writeScId(43, self.player.name_color)                        

        self.writeVint(0)         

                              
        self.writeVint(1)
        self.writeVint(29)
        self.writeVint(self.player.skin_id)          

                              
                            
                             
                                       

        self.writeVint(len(self.player.UnlockedSkins))
        for i in self.player.UnlockedSkins:
            if self.player.UnlockedSkins[str(i)]==1:
                self.writeScId(29, int(i))
            else:
                self.writeScId(29, 0)

        self.writeVint(0)         

        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeBoolean(True)                                         

        self.writeVint(0)                         
        self.writeVint(2592000)                    
        self.writeVint(2592000)
        self.writeVint(2592000)

        self.writeVint(0)
        self.writeBoolean(False)
        self.writeBoolean(False)

        self.writeByte(4)                                 

        for x in range(3):
            self.writeVint(2)

        self.writeVint(0)
        self.writeVint(0)

                    
        Shop.EncodeShopOffers(self)
                        

        self.writeVint(0)         

        self.writeVint(200)
        self.writeVint(2000)                                    

        self.writeVint(0)         

        self.writeVint(self.player.tickets)           
        self.writeVint(1)

        self.writeScId(16, self.player.brawler_id)                    

        self.writeString(self.player.Region)            
        self.writeString(f"{self.player.ccc}")                             

                
        self.writeVint(2)         
        self.writeInt(4)
        self.writeLkPrtctrdInt(self.player.bet)
        self.writeInt(3)
        self.writeLkPrtctrdInt(self.player.betTok)

        self.writeVint(0)         
        
        LkPrtctrd.BrawlPassEncode(self,self.client,self.player)

        self.writeVint(0)         

        self.writeBoolean(True)         
        self.writeVint(0)
        
        self.writeBoolean(True)         
        self.writeVint(0)

        self.writeVint(2019049)

        self.writeVint(100)
        self.writeVint(10)

        self.writeVint(30)
        self.writeVint(3)
        self.writeVint(80)
        self.writeVint(10)

        self.writeVint(50)
        self.writeVint(1000)

        self.writeVint(500)
        self.writeVint(50)
        self.writeVint(999900)

        self.writeVint(0)         

        self.writeVint(8)         

        self.writeVint(1)
        self.writeVint(2)
        self.writeVint(3)
        self.writeVint(4)
        self.writeVint(5)
        self.writeVint(6)
        self.writeVint(7)
        self.writeVint(8)

                      
        count = len(EventSlots.maps)
        self.writeVint(count)

        for map in EventSlots.maps:

            self.writeVint(EventSlots.maps.index(map) + 1)
            self.writeVint(EventSlots.maps.index(map) + 1)
            self.writeVint(map['Ended'])                                       
            self.writeVint(EventSlots.Timer)         

            self.writeVint(0)
            self.writeScId(15, map['ID'])

            self.writeVint(map['Status'])

            self.writeString()
            self.writeVint(0)
            self.writeVint(0)                         
            self.writeVint(0)                               

            if map['Modifier'] > 0:
                self.writeBoolean(True)                        
                self.writeVint(1)              
            else:
                self.writeBoolean(False)

            self.writeVint(0)
            self.writeVint(0)

        self.writeVint(0)         

        self.writeVint(8)
        self.writeVint(20)
        self.writeVint(35)
        self.writeVint(75)
        self.writeVint(140)
        self.writeVint(290)
        self.writeVint(480)
        self.writeVint(800)
        self.writeVint(1250)

        self.writeVint(8)
        self.writeVint(1)
        self.writeVint(2)
        self.writeVint(3)
        self.writeVint(4)
        self.writeVint(5)
        self.writeVint(10)
        self.writeVint(15)
        self.writeVint(20)

        self.writeVint(3)
        self.writeVint(10)
        self.writeVint(30)
        self.writeVint(80)

        self.writeVint(3)
        self.writeVint(6)
        self.writeVint(20)
        self.writeVint(60)

        self.writeVint(1)             
        self.writeVint(500)                  

        self.writeVint(1)             
        self.writeVint(10000)                  

        self.writeVint(0)
        self.writeVint(200)              
        self.writeVint(20)               
        self.writeVint(0)
        self.writeVint(10)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)

        self.writeBoolean(True)               

        self.writeVint(0)         

        self.writeVint(1)              
        self.writeInt(1)
                                                                                                
        self.writeInt(41000000 + self.player.theme)            

        self.writeVint(0)         
        self.writeVint(0)         

        self.writeInt(self.player.high_id)
        self.writeInt(self.player.low_id)

        notification_factory = ensure_player_notifications(self.player)
        notification_factory.encode(self)
  
        self.writeVint(0)
        self.writeBoolean(False)

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(self.player.high_id)           
        self.writeVint(self.player.low_id)          

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)

        if self.player.name == "VBC26":
            self.writeString("VBC26")               
            self.writeVint(0)
        else:
            self.writeString(premium_display_name(self.player.name, player=self.player))               
            self.writeVint(1)

        self.writeInt(0)

        self.writeVint(8)

                                             
        self.writeVint(len(self.player.card_unlock_id) + 2)         

        index = 0
        for unlock_id in self.player.card_unlock_id:
            self.writeScId(23, unlock_id)
            try:
                self.writeVint(self.player.UnlockedBrawlers[str(index)])
            except:
                self.writeVint(1)
            index += 1

        self.writeVint(5)          
        self.writeVint(8)               
        self.writeVint(self.player.gold)                   

        self.writeVint(5)          
        self.writeVint(10)               
        self.writeVint(self.player.starpoints)                   

                                 
        self.writeVint(len(self.player.brawlers_trophies))                  
        for brawler_id, trophies in self.player.brawlers_trophies.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlers_trophies[f"{int(brawler_id)}"])

                                          
        self.writeVint(len(self.player.brawlers_trophies))                  
        for brawler_id, trophies in self.player.brawlers_trophies.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlers_trophies[f"{int(brawler_id)}"])

        self.writeVint(0)         

                                       
        self.writeVint(len(self.player.brawlerPoints))                  
        for brawler_id, trophies in self.player.brawlerPoints.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlerPoints[f"{int(brawler_id)}"])

                                    
        self.writeVint(len(self.player.brawlerPowerLevel))                  
        for brawler_id, trophies in self.player.brawlerPowerLevel.items():
                self.writeScId(16, int(brawler_id))
                self.writeVint(self.player.brawlerPowerLevel[f"{int(brawler_id)}"])

        spgList = []
        for brawler_id, level in self.player.brawlerPowerLevel.items():
            if level >= 8:
                unlocked_spg = Cards.get_spg_id(int(brawler_id))
                for spg_id in unlocked_spg:
                    if str(spg_id) in self.player.brawlers_spg_unlock:
                        if self.player.brawlers_spg_unlock[str(spg_id)] == 1:
                            spgList.append(spg_id)

        self.writeVint(len(self.player.card_skills_id))
        for skill_id in self.player.card_skills_id:
            self.writeScId(23, skill_id)      
            if skill_id in spgList:          
                self.writeVint(1)                 
            else:
                self.writeVint(0)                    
                                 
        self.writeVint(0)                  

        self.writeVint(self.player.gems)               
        self.writeVint(self.player.gems)
        self.writeVint(40)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(2)
        self.writeVint(1585502369)
        DataBase.replaceValue(self, 'online', 2)
        config = open('config.json', 'r')
        content = config.read()
        settings = json.loads(content)
        if self.player.gold < 0:
            self.player.gold = 0
            DataBase.replaceValue(self, 'gold', self.player.gold)
        if self.player.gems < 0:
            self.player.gems = 0
            DataBase.replaceValue(self, 'gems', self.player.gems)
        if self.player.low_id in settings['banID']:
            update_url = 'https://t.me/zoxdev'
            self.player.err_code = 11
            LoginFailedMessage(self.client, self.player, 'Ваш аккаунт заблокирован!\nЕсли это ошибка - @Boost_Fair').send()
        BattleBan(self.client, self.player)

