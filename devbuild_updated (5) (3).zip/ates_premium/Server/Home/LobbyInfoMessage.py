from Utils.Writer import Writer
from datetime import datetime
import random
from Logic.Premium import sync_player, is_premium, format_utc
class LobbyInfoMessage(Writer):
    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.count = count

    def encode(self):
        now = datetime.now()
        ping = random.randint(19,33)
        sync_player(self.player)
        premium_active = is_premium(player=self.player)
        premium_level = getattr(self.player, 'premium_level', 0)
        premium_end = getattr(self.player, 'premium_end_time', 0)
        premium_line = f'Premium: {premium_active}'
        if premium_active:
            premium_line += f' | Level: {premium_level} | Until: {format_utc(premium_end)}'
        self.writeVint(0)                              
        self.writeString(f'Apple brawl\nTG: @Appel brawl\nPing: {ping}ms\nOnline: {self.count}\n{premium_line}\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n')
        self.writeVint(0)
