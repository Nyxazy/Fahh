from Utils.Writer import Writer
from database.DataBase import DataBase
import json
import time

class BrawlerLeader(Writer):
    def __init__(self, client, player, ID):
        super().__init__(client)
        self.id = 24403
        self.player = player
        self.brawler = ID

                                       
    def by_tr(self, plr):
        return json.loads(plr[2])['brawlersTrophies'][str(self.brawler)]

    def encode(self):
        self.indexOfPlayer = 1
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(16, self.brawler)
        self.writeString()

                                                                                 
        fetch = DataBase.GetLeaderboardByBrawler(self, self.brawler)
        fetch.sort(key=self.by_tr, reverse=True)

                                                   
        player_count = sum(1 for i in fetch if self.by_tr(i) > 0)
        self.writeVint(player_count)                                 

                                                   
        for i in fetch:
            trophies = self.by_tr(i)
            if trophies > 0:
                self.writeVint(0)           
                self.writeVint(i[0])          
                self.writeVint(1)

                                               
                self.writeVint(trophies)
                self.writeVint(1)

                self.writeString("")                  

                                       
                premium_active = i[5] > 0 and i[6] > time.time()
                player_name = f"[ VIP ] ( {i[1]} )" if premium_active else i[1]
                self.writeString(player_name)

                self.writeVint(100)                  
                self.writeVint(28000000 + i[3])
                self.writeVint(43000000 + i[4])

                                                                      
                self.writeVint(43000000 + i[4] if premium_active else 0)
                self.writeVint(0)

                                                               
        self.writeVint(0)
        self.writeVint(1)                                    
        self.writeVint(0)
        self.writeVint(0)
        self.writeString("RU")