from Utils.Writer import Writer
from database.DataBase import DataBase
import sys
import os
import random
from Logic.Premium import premium_level, premium_trophy_bonus, premium_high_name_color, premium_display_name
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class BattleResultMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.player = player

    def encode(self):
        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        tropGained = 0
        tokenGained = 0

                                                                                  
        rank_values = {
            (0, 49): (30, 20, 15, 10, 3, 2, 0, 0, 0, 0),
            (50, 99): (30, 20, 15, 10, 3, 2, 0, 0, 0, 0),
            (100, 249): (30, 28, 13, 10, 3, 0, 0, -1, -2, -2),
            (250, 399): (30, 20, 15, 3, 0, -2, -2, -2, -2, -3),
            (400, 499): (30, 20, 14, 3, 0, -1, -2, -2, -3, -3),
            (500, 649): (30, 20, 13, 2, -1, -2, -3, -3, -3, -3),
            (650, 799): (30, 12, 16, 0, -2, -3, -3, -3, -3, -4),
            (800, 899): (30, 14, 10, 0, -2, -3, -3, -4, -4, -4),
            (900, 1099): (15, 10, 0, -2, -2, -3, -3, -4, -4, -4),
            (1100, 1249): (10, 4, -1, -2, -3, -3, -4, -4, -4, -5),
            (1250, 100000): (7, 5, -3, -5, -6, -7, -8, -9, -10, -11)
        }


                                                            
        for (min_trophies, max_trophies), ranks in rank_values.items():
            if min_trophies <= brawler_trophies <= max_trophies:
                rank_1_val, rank_2_val, rank_3_val, rank_4_val, rank_5_val, rank_6_val, rank_7_val, rank_8_val, rank_9_val, rank_10_val = ranks
                break

                                                                 
        if self.player.rank == 1:
            tropGained = rank_1_val
            tokenGained = 20
        elif self.player.rank == 2:
            tropGained = rank_2_val
            tokenGained = 20
        elif self.player.rank == 3:
            tropGained = rank_3_val
            tokenGained = 20
        elif self.player.rank == 4:
            tropGained = rank_4_val
            tokenGained = 15
        elif self.player.rank == 5:
            tropGained = rank_5_val
            tokenGained = 15
        elif self.player.rank == 6:
            tropGained = rank_6_val
            tokenGained = 15
        elif self.player.rank == 7:
            tropGained = rank_7_val
            tokenGained = random.randint(10, 15)
        elif self.player.rank == 8:
            tropGained = rank_8_val
            tokenGained = random.randint(10, 15)
        elif self.player.rank == 9:
            tropGained = rank_9_val
            tokenGained = random.randint(1, 10)
        elif self.player.rank == 10:
            tropGained = rank_10_val
            tokenGained = random.randint(1, 10)
            

                            
        self.writeVint(2)                        
        self.writeVint(self.player.rank)          

        premium_lvl = premium_level(player=self.player)
        premium_bonus = premium_trophy_bonus(tropGained, premium_lvl)
        tropGained += premium_bonus

        self.writeVint(tokenGained)                 
        self.writeVint(tropGained)                   

        self.writeVint(0)                                
        self.writeVint(0)                  
        self.writeVint(0)                     
        self.writeVint(0)                          
        self.writeVint(0)                            
        self.writeVint(0)                                 
        self.writeVint(0)                            
        self.writeVint(0)                                                           
        self.writeVint(0)                           
        self.writeVint(0)                           
        self.writeVint(0)                              
        self.writeVint(0)                    
        self.writeVint(premium_bonus)
        self.writeVint(16)                                                                
        self.writeVint(-64)                              
        self.writeVint(0)                                       
            
                       
        self.writeVint(6)                            
        
        self.writeVint(1)                            
        self.writeScId(16, self.player.brawler_id)                 
        self.writeScId(29, self.player.skin_id)              
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)])                        
        self.writeVint(0)                               
        self.writeVint(self.player.brawlerPowerLevel[str(self.player.brawler_id)])                           
        self.writeBoolean(True)                         
        self.writeInt(0)         
        self.writeInt(self.player.low_id)        
        self.writeString(premium_display_name(self.player.name, player=self.player))            
        self.writeVint(100)                          
        self.writeVint(28000000 + self.player.profile_icon)                      
        self.writeVint(43000000 + self.player.name_color)                    
        self.writeVint(premium_high_name_color(self.player.name_color, player=self.player))

        self.writeVint(0)                            
        self.writeScId(16, self.player.bot1)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString(self.player.bot1_n)             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    
            
        self.writeVint(0)                            
        self.writeScId(16, self.player.bot2)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString(self.player.bot2_n)             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    

        self.writeVint(2)                            
        self.writeScId(16, self.player.bot3)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString(self.player.bot3_n)             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    

        self.writeVint(2)                            
        self.writeScId(16, self.player.bot4)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString(self.player.bot4_n)             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    

        self.writeVint(2)                            
        self.writeScId(16, self.player.bot5)                
        self.writeVint(0)             
        self.writeVint(0)                   
        self.writeVint(0)                               
        self.writeVint(1)                      
        self.writeBoolean(False)                         
        self.writeString(self.player.bot5_n)             
        self.writeVint(0)                          
        self.writeVint(28000000)                      
        self.writeVint(43000000)                    
        self.writeVint(43000000)                    
        
                          
        self.writeVint(2)        
        self.writeVint(0)                       
        self.writeVint(0)                           
        self.writeVint(8)                            
        self.writeVint(0)                                

                                          
        self.writeVint(0)        

                                            
        self.writeVint(2)        
        self.writeVint(1)                            
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)])                   
        self.writeVint(self.player.brawlers_trophies[str(self.player.brawler_id)])                            
        self.writeVint(5)                              
        self.writeVint(10)                    
        self.writeVint(0)                              
        
        self.writeScId(28, 0)                                           
        self.writeBoolean(False)              
        if self.player.name != "VBC26":
            self.player.bet = tropGained
            self.player.betTok = tokenGained
            self.player.brawlers_trophies[str(self.player.brawler_id)] += self.player.bet
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            self.player.BPTOKEN = self.player.BPTOKEN + tokenGained
            DataBase.replaceValue(self, 'BPTOKEN', self.player.BPTOKEN)
            self.player.sdWINS = self.player.sdWINS + 1
            DataBase.replaceValue(self, 'sdWINS', self.player.sdWINS)
            self.player.player_experience += 10
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
            
            brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)