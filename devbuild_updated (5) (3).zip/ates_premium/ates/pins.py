class PinsManager:
    def __init__(self, server):
        self.server = server
        self.enabled = False

    def start(self):
        pass

    def enable(self):
        self.enabled = True

    def disable(self):
        self.enabled = False
