class NotificationManager:
    def __init__(self, server=None):
        self.server = server

    def start(self):
        pass

    def send(self, player_id, message, kind=81, **kwargs):
        try:
            from Logic.Notifications import add_notification_lowid
            if isinstance(message, dict):
                text = message.get('MessageEntry') or message.get('Desc') or message.get('message') or str(message)
                kind = message.get('Id') or message.get('ID') or message.get('kind') or kind
                kwargs.update(message)
                add_notification_lowid(player_id, text, kind=kind, **kwargs)
            else:
                add_notification_lowid(player_id, str(message), kind=kind, **kwargs)
            return True
        except Exception:
            return False

    def remove(self, player_id, notification_id=None):
        try:
            from Logic.Notifications import NotificationFactory
            factory = NotificationFactory.load(player_id)
            if notification_id is None:
                factory.NotificationList.clear()
            else:
                factory.remove(int(notification_id))
            factory.save(player_id)
            return True
        except Exception:
            return False
