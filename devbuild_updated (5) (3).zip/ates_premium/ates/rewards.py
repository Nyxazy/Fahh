"""Rewards collector skeleton for map rewards and other automatic grants."""
class RewardsCollector:
    def __init__(self, server):
        self.server = server

    def start(self):
        pass

    def grant_map_reward(self, player, map_id):
        try:
            player.gold = getattr(player, 'gold', 0) + 50
            return True
        except Exception:
            return False
