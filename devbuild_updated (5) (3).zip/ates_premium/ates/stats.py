
class StatsManager:
    def __init__(self, server):
        self.server = server

    def start(self):
        pass

    def get_player_stats(self, player_id):
        
        return {}
