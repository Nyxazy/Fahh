"""Features package: exposes FeaturesManager."""
from .manager import FeaturesManager

__all__ = ["FeaturesManager"]
