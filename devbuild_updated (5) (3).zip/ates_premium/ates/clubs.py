class ClubsManager:
    def __init__(self, server):
        self.server = server
        self.clubs = {}

    def start(self):
        pass

    def create_club(self, name, owner_id):
        club_id = len(self.clubs) + 1
        self.clubs[club_id] = {'name': name, 'owner': owner_id, 'members': [owner_id]}
        return club_id
