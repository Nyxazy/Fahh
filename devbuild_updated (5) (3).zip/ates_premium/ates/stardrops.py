import random

class StarDrops:
    def __init__(self, server):
        self.server = server

    def start(self):
        pass

    def drop_for_player(self, player):
        if random.random() < 0.1:
            return {'starpoints': random.randint(1,5)}
        return None
