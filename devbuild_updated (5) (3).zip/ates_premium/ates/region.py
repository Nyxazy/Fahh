
class RegionManager:
    def __init__(self, server):
        self.server = server
        self.auto_detect = True

    def start(self):
        pass

    def detect_region(self, ip):
        try:
            return self.server.detect_region_from_ip(ip)
        except Exception:
            return 'Unknown'

    def set_player_region(self, player, region_name):
        player.Region = region_name
