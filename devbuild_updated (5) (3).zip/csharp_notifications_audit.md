# C# server notifications audit — `royale-brawl-v29`

Repository inspected:

```txt
/home/user/repos/royale-brawl-v29
```

## Main structure

The C# server has a real notification system based on:

```txt
src/Supercell.Laser.Logic/Home/Items/Notification.cs
src/Supercell.Laser.Logic/Home/Items/NotificationFactory.cs
src/Supercell.Laser.Logic/Home/ClientHome.cs
```

Each account has:

```cs
ClientHome.NotificationFactory
```

Because the whole account is serialized in the `accounts.Data` JSON column, notifications are persisted with the account.

## Notification encoding

File:

```txt
src/Supercell.Laser.Logic/Home/Items/Notification.cs
```

Fields:

```cs
Id
Index
IsViewed
TimePassed
MessageEntry
PrimaryMessageEntry
SecondaryMessageEntry
ButtonMessageEntry
FileLocation
FileSha
ExtLint
HeroesIds
HeroesTrophies
HeroesTrophiesReseted
StarpointsAwarded
DonationCount
```

Base encoding order:

```cs
stream.WriteVInt(Id);
stream.WriteInt(Index);
stream.WriteBoolean(IsViewed);
stream.WriteInt(TimePassed);
stream.WriteString(MessageEntry);
```

Special types:

| Id | Meaning in this server |
|---:|---|
| `81` | free text notification |
| `83` | popup/image/link notification |
| `89` | gems/donation notification; view gives `DonationCount` gems |
| `79` | season reset/starpoints notification |

For `Id == 83`, it writes title/subtitle/button/file/link fields.

For `Id == 79`, it writes brawler trophy reset/starpoints arrays.

For `Id == 89`, it writes `DonationCount`.

## NotificationFactory

File:

```txt
src/Supercell.Laser.Logic/Home/Items/NotificationFactory.cs
```

Important behavior:

```cs
notification.Index = GetIndex();
NotificationList.Add(notification);
```

`GetIndex()` returns `NotificationList.Count`.

During HomeData encode:

```cs
stream.WriteVInt(NotificationList.Count);
foreach notification -> notification.Encode(stream);
```

## Where HomeData sends notifications

File:

```txt
src/Supercell.Laser.Logic/Home/ClientHome.cs
```

In `Encode()`:

```cs
encoder.WriteLong(HomeId);
NotificationFactory.Encode(encoder);
```

So the inbox is sent directly from `Home.NotificationFactory`.

## Server commands related to notifications

Files:

```txt
src/Supercell.Laser.Logic/Command/Home/LogicAddNotificationCommand.cs
src/Supercell.Laser.Logic/Command/Home/LogicDeleteNotificationCommand.cs
src/Supercell.Laser.Logic/Command/Home/LogicViewInboxNotificationCommand.cs
src/Supercell.Laser.Server/Command/CommandManager.cs
```

Command types:

| Command | Type | Direction |
|---|---:|---|
| `LogicAddNotificationCommand` | `206` | server -> client through `AvailableServerCommandMessage` |
| `LogicDeleteNotificationCommand` | `514` | client -> server |
| `LogicViewInboxNotificationCommand` | `528` | client -> server |

## Viewing notifications

File:

```txt
src/Supercell.Laser.Server/Command/CommandManager.cs
```

When a notification is viewed:

1. Checks index.
2. Checks `IsViewed`.
3. If `Id == 79`, gives starpoints from `StarpointsAwarded`.
4. If `Id == 89`, sends a delivery command with gems:

```cs
GatchaDrop reward = new GatchaDrop(8);
reward.Count = NotificationList[index].DonationCount;
```

5. Marks:

```cs
IsViewed = true;
```

## Deleting notifications

Same file:

```cs
LogicDeleteNotificationReceived()
```

It removes notification from `NotificationList`.

Potential issue: it returns false if notification is viewed:

```cs
if (NotificationList[index].IsViewed) return false;
```

That means viewed notifications cannot be deleted by this command, which is probably backwards depending on client behavior.

## Where notifications are created

### New account welcome popup

File:

```txt
src/Supercell.Laser.Server/Database/Accounts.cs
```

On account create:

```cs
Id = 83
PrimaryMessageEntry = "royale brawl v29"
SecondaryMessageEntry = "check out my github (github.com/erder00)"
ButtonMessageEntry = "click click click"
FileLocation = "pop_up_1920x1235_welcome.png"
ExtLint = "brawlstars://extlink?page=https%3A%2F%2Fgithub.com%2Ferder00"
```

### Discord mute/unmute

File:

```txt
src/Supercell.Laser.Server/Discord/Commands.cs
```

Mute/community ban adds:

```cs
Id = 81
MessageEntry = "Social functions have been disabled..."
```

Unmute adds:

```cs
Id = 81
MessageEntry = "You have been unmuted..."
```

### Discord add gems

File:

```txt
src/Supercell.Laser.Server/Discord/Commands.cs
```

`!addgems` creates:

```cs
Id = 89
DonationCount = donationAmount
MessageEntry = "received X gems, enjoy!"
```

It also sends `LogicAddNotificationCommand` live if player is online.

### Discord give premium

File:

```txt
src/Supercell.Laser.Server/Discord/Commands.cs
```

`!givepremium` creates:

```cs
Id = 89
DonationCount = 40
MessageEntry = "Vip status activated/extended..."
```

Important: because it is `Id = 89`, viewing the Premium notification gives 40 gems.

### Trophy reset / season reset

File:

```txt
src/Supercell.Laser.Server/Discord/Commands.cs
```

A reset flow creates:

```cs
Id = 79
HeroesIds
HeroesTrophies
HeroesTrophiesReseted
StarpointsAwarded
```

Viewing it gives starpoints.

### Leave battle penalty

File:

```txt
src/Supercell.Laser.Server/Message/MessageManager.cs
```

When player leaves battle:

```cs
Id = 81
MessageEntry = "Because of leaving match, you recieved leave penalty: X trophies!"
```

Only added if notification count is below 5.

### Royale ID registration reward

File:

```txt
src/Supercell.Laser.Server/Message/MessageManager.cs
```

Creates:

```cs
Id = 89
DonationCount = 200
MessageEntry = "royale ID Thank you for connecting!"
```

Viewing it gives 200 gems.

### Premium expired

File:

```txt
src/Supercell.Laser.Server/Message/MessageManager.cs
```

Creates:

```cs
Id = 81
MessageEntry = "Hello!\nYour Premium status has expired."
```

But there is a bug:

```cs
PremiumLevel > 1
```

Since `!givepremium` sets `PremiumLevel = 1`, the default Premium level does not expire through this branch.

## Problems found

### 1. Index bounds bug

In `CommandManager.cs`:

```cs
if (command.NotificationIndex > HomeMode.Home.NotificationFactory.GetIndex()) return false;
```

Should be:

```cs
if (command.NotificationIndex >= HomeMode.Home.NotificationFactory.GetIndex()) return false;
```

Because valid indexes are `0` to `Count - 1`.

This bug exists in both view and delete handlers.

### 2. `Id = 89` always gives gems

Any notification with `Id = 89` gives `DonationCount` gems when viewed.

So `!givepremium` is not just a Premium message; it gives 40 gems too.

### 3. Premium expiration bug

The expiration notification only happens when:

```cs
PremiumLevel > 1
```

But `!givepremium` sets:

```cs
PremiumLevel = 1
```

Should be `PremiumLevel > 0`.

### 4. No cleanup/reindex after deletion

`NotificationFactory.Add()` indexes by count. Delete removes an entry but does not reindex remaining entries.

If client uses array position, it may still work; if it uses stored `Index`, gaps may cause confusion.

### 5. Delete refuses viewed notifications

```cs
if (NotificationList[index].IsViewed) return false;
```

This may prevent deleting already claimed/read notifications.

### 6. Some commands add notifications but do not save immediately

Accounts are saved periodically by cache, but commands such as `!addgems`/`!givepremium` should ideally call:

```cs
Accounts.Save(account);
```

immediately after modification.

## Difference from Python version

The C# version is more organized than the original Python version because:

- notifications are part of account data
- `NotificationFactory` encodes them directly
- `LogicAddNotificationCommand` can push live notifications to online users
- `IsViewed` prevents repeated claims

But C# has the bugs listed above.
