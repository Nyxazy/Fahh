# Notifications audit/update — `#1/ates_premium`

Status after the latest change: the old Python notification systems were replaced by a C#-style `NotificationFactory` port.

## New active notification system

New file:

```txt
Logic/Notifications.py
```

Main classes/functions:

```py
Notification
NotificationFactory
ensure_notification_columns()
add_notification_lowid()
ensure_player_notifications()
```

Notifications are now stored per-player in SQLite inside the `plrs` table:

```sql
notifications TEXT DEFAULT '[]'
```

This replaces the old `JSON/notifications.json` storage.

## Removed old JSON notification storage

The old file was removed:

```txt
JSON/notifications.json
```

The TeleBot, moderation and server admin code now write to the new database-backed notification system instead of writing to `JSON/notifications.json`.

## Active HomeData encoder

File:

```txt
Server/Home/OwnHomeDataMessage.py
```

The active `OwnHomeDataMessage` now uses:

```py
notification_factory = ensure_player_notifications(self.player)
notification_factory.encode(self)
```

So notifications are encoded from the database-backed `NotificationFactory`, like the C# server.

## Supported notification types

| Id | Meaning |
|---:|---|
| `81` | free text notification |
| `83` | popup/link notification |
| `89` | reward notification; gives gems and optionally gold |
| `79` | season reset/starpoints style notification |
| `93` | brawler notification compatibility |
| `94` | skin notification compatibility |

## Claim/view logic

File:

```txt
Logic/Commands/Client/LogicViewNotificationCommand.py
```

Client command:

```txt
528
```

It now loads the notification by index from `NotificationFactory`.

Behavior:

- If `Id == 89`, it gives `DonationCount` gems and `GoldCount` coins using `MilestonesClaimSupplyByLkPrtctrd`.
- If `Id == 79`, it gives starpoints from `StarpointsAwarded`.
- After processing, it sets `IsViewed = True` and saves back to SQLite.

## Delete logic

New file:

```txt
Logic/Commands/Client/LogicDeleteNotificationCommand.py
```

Client command:

```txt
514
```

It removes the notification from `NotificationFactory` and reindexes the list.

Connected in:

```txt
Logic/Commands/LogicCommandManager.py
```

## Premium reward notification

Premium rewards are now added as real inbox notifications:

```py
Id = 89
DonationCount = gems
GoldCount = coins
Kind = "premium_reward"
```

When the player opens the notification, they receive the rewards through `MCbyLkPrtctrd`.

## Premium reward table

| Level | Gems | Gold | Interval |
|---:|---:|---:|---:|
| 1 | 10 | 2000 | 8 days |
| 2 | 25 | 6000 | 7 days |
| 3 | 60 | 10000 | 6 days |

When Premium is granted/extended, the first reward is made available immediately.

## TeleBot integration

File:

```txt
atesbot1v1.py.py
```

The function:

```py
add_notification()
```

now calls:

```py
Logic.Notifications.add_notification_lowid()
```

So these commands now write to the real inbox system:

```txt
/gems
/premium
/del_premium
/addnotiftoall
/addpopuptoall
/addgemstoall
```

## Chat moderation integration

File:

```txt
ates/chat_moderation.py
```

The functions:

```py
send_inbox_notification()
add_notification_to_player_obj()
```

now write to `Logic.Notifications.add_notification_lowid()`.

## NotificationManager integration

File:

```txt
ates/notifications.py
```

`NotificationManager` is now a wrapper around the new DB-backed notification system.

## ServerAdmin integration

File:

```txt
ates/server_admin.py
```

Resource grants now create a DB-backed inbox notification.

## Database changes

New player column:

```sql
notifications TEXT DEFAULT '[]'
```

Existing Premium columns remain:

```sql
premiumLevel INT DEFAULT 0
premiumEndTime INT DEFAULT 0
premiumExpireNotice INT DEFAULT 0
premiumLastRewardTime INT DEFAULT 0
```

## Main result

The notification system is now centralized and C#-style:

- one `Notification` object format
- one `NotificationFactory`
- notifications stored in player data
- HomeData encodes the factory
- view command processes rewards and marks viewed
- delete command removes notifications
- TeleBot/moderation/admin all write to the same system
