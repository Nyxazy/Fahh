import socket, struct, sys, time

def make_client_hello(major=12):
    body = b''
    body += struct.pack('>i', 0)            # Protocol
    body += struct.pack('>i', 1)            # KeyVersion
    body += struct.pack('>i', major)        # MajorVersion
    body += struct.pack('>i', 0)            # MinorVersion
    body += struct.pack('>i', 0)            # Build
    ch = b''                                # ContentHash string (-1 = empty)
    body += struct.pack('>i', -1)
    body += struct.pack('>i', 1)            # DeviceType
    body += struct.pack('>i', 1)            # AppStore
    header = struct.pack('>h', 10100) + struct.pack('>I', len(body))[1:] + struct.pack('>h', 0)
    return header + body

def parse_header(data):
    pid = struct.unpack('>h', data[0:2])[0]
    length = (data[2]<<16)|(data[3]<<8)|data[4]
    version = struct.unpack('>h', data[5:7])[0]
    return pid, length, version

s = socket.create_connection(('127.0.0.1', 9339), timeout=5)
s.sendall(make_client_hello(12))
hdr = s.recv(7)
if len(hdr) < 7:
    print("FAIL: no response header, got", hdr); sys.exit(1)
pid, length, version = parse_header(hdr)
body = b''
while len(body) < length:
    chunk = s.recv(length - len(body))
    if not chunk: break
    body += chunk
s.close()
print("response id:", pid, "len:", length, "version:", version)
print("body hex:", body.hex())
ok = (pid == 20100 and length == 28 and body[0:4] == b'\x00\x00\x00\x18'
      and body[4:15] != b'\x00'*11 and body[15:28] == bytes.fromhex('00446f6e277420747279203a29'))
print("ServerHello handshake:", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
