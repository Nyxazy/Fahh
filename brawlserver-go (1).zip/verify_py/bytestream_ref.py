# Reference extracted VERBATIM from Utils/ByteStream.py (writeVInt + readVInt).
import json

class BS:
    def __init__(self, payload=b''):
        self.messagePayload = bytearray(payload)
        self.offset = 0
        self.bitoffset = 0
        self.length = len(payload)
    def writeVInt(self, data):
        self.bitoffset = 0
        if type(data) == str:
            data = int(data)
        final = b''
        if (data & 2147483648) != 0:
            if data >= -63:
                final += (data & 0x3F | 0x40).to_bytes(1, 'big', signed=False); self.offset += 1
            elif data >= -8191:
                final += (data & 0x3F | 0xC0).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F).to_bytes(1, 'big', signed=False); self.offset += 2
            elif data >= -1048575:
                final += (data & 0x3F | 0xC0).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 13) & 0x7F).to_bytes(1, 'big', signed=False); self.offset += 3
            elif data >= -134217727:
                final += (data & 0x3F | 0xC0).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 13) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 20) & 0x7F).to_bytes(1, 'big', signed=False); self.offset += 4
            else:
                final += (data & 0x3F | 0xC0).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 13) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 20) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 27) & 0xF).to_bytes(1, 'big', signed=False); self.offset += 5
        else:
            if data <= 63:
                final += (data & 0x3F).to_bytes(1, 'big', signed=False); self.offset += 1
            elif data <= 8191:
                final += (data & 0x3F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F).to_bytes(1, 'big', signed=False); self.offset += 2
            elif data <= 1048575:
                final += (data & 0x3F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 13) & 0x7F).to_bytes(1, 'big', signed=False); self.offset += 3
            elif data <= 134217727:
                final += (data & 0x3F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 13) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 20) & 0x7F).to_bytes(1, 'big', signed=False); self.offset += 4
            else:
                final += (data & 0x3F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 6) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 13) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 20) & 0x7F | 0x80).to_bytes(1, 'big', signed=False)
                final += ((data >> 27) & 0xF).to_bytes(1, 'big', signed=False); self.offset += 5
        self.messagePayload += final
    def readVInt(self):
     try:
        offset = self.offset
        self.bitoffset = 0
        v4 = offset + 1
        self.offset = offset + 1
        result = self.messagePayload[offset] & 0x3F
        if (self.messagePayload[offset] & 0x40) != 0:
            if (self.messagePayload[offset] & 0x80) != 0:
                self.offset = offset + 2
                v7 = self.messagePayload[v4]
                v8 = result & 0xFFFFE03F | ((v7 & 0x7F) << 6)
                if (v7 & 0x80) != 0:
                    self.offset = offset + 3
                    v9 = v8 & 0xFFF01FFF | ((self.messagePayload[offset + 2] & 0x7F) << 13)
                    if (self.messagePayload[offset + 2] & 0x80) != 0:
                        self.offset = offset + 4
                        v10 = v9 & 0xF80FFFFF | ((self.messagePayload[offset + 3] & 0x7F) << 20)
                        if (self.messagePayload[offset + 3] & 0x80) != 0:
                            self.offset = offset + 5
                            return v10 & 0x7FFFFFF | (self.messagePayload[offset + 4] << 27) | 0x80000000
                        else:
                            return v10 | 0xF8000000
                    else:
                        return v9 | 0xFFF00000
                else:
                    return v8 | 0xFFFFE000
            else:
                return self.messagePayload[offset] | 0xFFFFFFC0
        elif (self.messagePayload[offset] & 0x80) != 0:
            self.offset = offset + 2
            v6 = self.messagePayload[v4]
            result = result & 0xFFFFE03F | ((v6 & 0x7F) << 6)
            if (v6 & 0x80) != 0:
                self.offset = offset + 3
                result = result & 0xFFF01FFF | ((self.messagePayload[offset + 2] & 0x7F) << 13)
                if (self.messagePayload[offset + 2] & 0x80) != 0:
                    self.offset = offset + 4
                    result = result & 0xF80FFFFF | ((self.messagePayload[offset + 3] & 0x7F) << 20)
                    if (self.messagePayload[offset + 3] & 0x80) != 0:
                        self.offset = offset + 5
                        return result & 0x7FFFFFF | (self.messagePayload[offset + 4] << 27)
        return result
     except:
         return 0

# Generate byte vectors via writeVInt for a range, then decode each with readVInt.
vals = list(range(-2000, 2001)) + [10000, 100000, 1000000, -50000, 1410, 9999999, 69746974, 8640, 734974]
vectors = []
for v in vals:
    w = BS()
    w.writeVInt(v)
    seq = bytes(w.messagePayload)
    r = BS(seq)
    decoded = r.readVInt()
    vectors.append({"hex": seq.hex(), "py": decoded})
print(json.dumps(vectors))
