# Reference CSV logic extracted from the original Files/CsvLogic/*.py
import csv, json

def read(name):
    rows=[]
    with open('/home/user/brawlserver-go/internal/csvlogic/assets/'+name) as f:
        r=csv.reader(f); lc=0
        for row in r:
            if lc==0 or lc==1: lc+=1
            else: rows.append(row); lc+=1
    return rows

def cell(row,i): return row[i] if i<len(row) else ''
def low(s): return s.lower() if isinstance(s,str) else s

chars=read('characters.csv'); cards=read('cards.csv'); skins=read('cards.csv') and read('skins.csv'); locs=read('locations.csv'); thumbs=read('player_thumbnails.csv')

out={}
# Characters.get_brawlers_id
bids=[]
for i,row in enumerate(chars):
    if cell(row,20)=='Hero' and low(cell(row,2))!='true' and low(cell(row,1))!='true':
        bids.append(i)
out['brawlers_id']=bids
# Cards.get_spg_id
spg=[]
for i,row in enumerate(cards):
    if low(cell(row,5))=='4' or low(cell(row,5))=='5': spg.append(i)
out['spg_id']=spg
# Cards.get_brawler_unlock
un=[]
for i,row in enumerate(cards):
    if low(cell(row,4))=='0': un.append(i)
out['brawler_unlock']=un
# Skins.get_skins_id
sk=[]
for i,row in enumerate(skins):
    if cell(row,2)!='': sk.append(i)
out['skins_id']=sk
# Locations.getAllLocations
al=[]
for i,row in enumerate(locs):
    if low(cell(row,1))!='true': al.append(i)
out['all_locations']=al
# default skins
defs=[cell(r,22) for r in chars]
nond=[i for i,row in enumerate(skins) if cell(row,0) not in defs and cell(row,2)!='']
out['non_default_skins']=nond
# gamemode string for a few ids
out['gm7']=cell(locs[7],14)
# rarity for a few card ids
out['rarity3']=cell(cards[2],10)
# thumbnails
out['thumbs']=list(range(len(thumbs)))
out['thumb_trophies_3']=cell(thumbs[3],2)
print(json.dumps(out))
