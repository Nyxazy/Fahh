# Reference VInt/Writer implementation extracted VERBATIM from the original
# Utils/Writer.py (classic brawl server). Used only to validate the Go port.

class Writer:
    def __init__(self):
        self.buffer = b''
    def writeInt(self, data, length=4):
        self.buffer += data.to_bytes(length, 'big')
    def writeByte(self, data):
        self.writeInt(data, 1)
    def writeVint(self, data, rotate=True):
        final = b''
        if data == 0:
            self.writeByte(0)
        else:
            data = (data << 1) ^ (data >> 31)
            while data:
                b = data & 0x7f
                if data >= 0x80:
                    b |= 0x80
                if rotate:
                    rotate = False
                    lsb = b & 0x1
                    msb = (b & 0x80) >> 7
                    b >>= 1
                    b = b & ~0xC0
                    b = b | (msb << 7) | (lsb << 6)
                final += b.to_bytes(1, 'big')
                data >>= 7
        self.buffer += final
    def writeString(self, string=None):
        if string is None:
            self.writeInt((2**32)-1)
        else:
            encoded = string.encode('utf-8')
            self.writeInt(len(encoded))
            self.buffer += encoded

import json, sys
vals = list(range(-2000, 2001)) + [10000, 100000, 1000000, -50000, 2147483647, -2147483648, 1410, 9999999, 69746974, 8640]
out = {}
for v in vals:
    w = Writer()
    w.writeVint(v)
    out[v] = w.buffer.hex()
# also strings
w = Writer(); w.writeString(None); out["__str_none__"] = w.buffer.hex()
w = Writer(); w.writeString("hello"); out["__str_hello__"] = w.buffer.hex()
print(json.dumps(out))
