import re, os
md = open('/home/user/uploads/PROJETO_COMPLETO_SERVIDOR.md','r',encoding='utf-8',errors='replace').read()
os.makedirs('/home/user/brawlserver-go/GameAssets/csv_logic', exist_ok=True)
pat = re.compile(r'### 📄 Arquivo: ([^\n]+?)\n.*?```(?:csv|json)?\n(.*?)\n```', re.S)
found = {}
for name, body in pat.findall(md):
    found[name.strip()] = body
for tgt in ['characters.csv','cards.csv','skins.csv','locations.csv','player_thumbnails.csv','alliance_badges.csv','alliance_roles.csv']:
    if tgt in found:
        open('/home/user/brawlserver-go/GameAssets/csv_logic/'+tgt,'w',encoding='utf-8').write(found[tgt])
        print('wrote', tgt, len(found[tgt]),'bytes')
    else:
        print('MISSING', tgt)
