# Removes EVERY // and /* */ comment from .go files, preserving:
#   - string literals (so "http://..." URLs are not corrupted)
#   - //go: compiler directives (//go:embed etc.)
import os, glob

def strip(src):
    out = []
    i = 0
    n = len(src)
    state = 'CODE'
    while i < n:
        c = src[i]
        nxt = src[i+1] if i+1 < n else ''
        if state == 'CODE':
            if c == '/' and nxt == '/':
                if src[i:].startswith('//go:'):
                    k = i
                    while k < n and src[k] != '\n':
                        out.append(src[k]); k += 1
                    i = k
                    continue
                state = 'LINEC'; i += 2; continue
            elif c == '/' and nxt == '*':
                state = 'BLOCK'; i += 2; continue
            elif c == '"':
                state = 'DQ'; out.append(c); i += 1; continue
            elif c == '`':
                state = 'RAW'; out.append(c); i += 1; continue
            else:
                out.append(c); i += 1; continue
        elif state == 'LINEC':
            if c == '\n':
                out.append('\n'); state = 'CODE'
            i += 1; continue
        elif state == 'BLOCK':
            if c == '*' and nxt == '/':
                state = 'CODE'; i += 2
            else:
                i += 1
            continue
        elif state == 'DQ':
            out.append(c)
            if c == '\\' and nxt != '':
                out.append(nxt); i += 2; continue
            elif c == '"':
                state = 'CODE'; i += 1; continue
            i += 1; continue
        elif state == 'RAW':
            out.append(c)
            if c == '`':
                state = 'CODE'
            i += 1; continue
    return ''.join(out)

def cleanup(src):
    lines = src.split('\n')
    out = []
    blank = 0
    for ln in lines:
        s = ln.rstrip()
        if s == '':
            blank += 1
            if blank <= 1:
                out.append('')
            continue
        blank = 0
        out.append(s)
    while out and out[-1] == '':
        out.pop()
    return '\n'.join(out) + '\n'

root = '/home/user/brawlserver-go'
files = glob.glob(root + '/**/*.go', recursive=True)
total = 0
for f in files:
    orig = open(f, encoding='utf-8').read()
    new = cleanup(strip(orig))
    if new != orig:
        open(f, 'w', encoding='utf-8').write(new)
        total += 1
        print('stripped', os.path.relpath(f, root))
print('files changed:', total, 'of', len(files))
