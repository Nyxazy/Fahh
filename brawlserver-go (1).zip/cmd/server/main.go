package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"

	"brawlserver/internal/config"
	"brawlserver/internal/logger"
	"brawlserver/internal/messages"
	"brawlserver/internal/server"
	"brawlserver/internal/serverstates"
)

type ServerCLI struct {
	states *serverstates.States
	srv    *server.Server
}

func (cli *ServerCLI) startServer(ip string, port int) {
	if cli.srv == nil {
		cli.srv = server.New(ip, port, cli.states)
		if err := cli.srv.Start(); err != nil {
			logger.Errorf("Failed to start server: %v", err)
			return
		}
	}
	cli.states.SetMaintenance(false)
	cli.states.SetRunning(true)
	logger.Info("Server started.")
}

func (cli *ServerCLI) stopServer() {
	if cli.srv != nil {
		cli.states.SetRunning(false)
		cli.srv = nil
		logger.Info("Server stopped.")
	}
}

func (cli *ServerCLI) setMaintenance() {
	if cli.srv != nil {
		cli.states.SetMaintenance(true)
		logger.Info("Server is now in maintenance mode.")
	}
}

func (cli *ServerCLI) run() {
	reader := bufio.NewReader(os.Stdin)
	for {
		fmt.Println("\nCommands:")
		fmt.Println("1. Start Server")
		fmt.Println("2. Stop Server")
		fmt.Println("3. Set Maintenance Mode")
		fmt.Println("4. Exit")
		fmt.Print("Enter your choice: ")
		choice, _ := reader.ReadString('\n')
		choice = strings.TrimSpace(choice)

		switch choice {
		case "1":
			fmt.Print("Enter IP address (default 0.0.0.0): ")
			ip, _ := reader.ReadString('\n')
			ip = strings.TrimSpace(ip)
			if ip == "" {
				ip = "0.0.0.0"
			}
			fmt.Print("Enter port (default 9339): ")
			portStr, _ := reader.ReadString('\n')
			portStr = strings.TrimSpace(portStr)
			port := 9339
			if portStr != "" {
				if p, err := strconv.Atoi(portStr); err == nil {
					port = p
				}
			}
			cli.startServer(ip, port)
		case "2":
			cli.stopServer()
		case "3":
			cli.setMaintenance()
		case "4":
			cli.stopServer()
			logger.Info("Exiting.")
			return
		default:
			fmt.Println("Invalid choice. Please try again.")
		}
	}
}

func main() {
	if err := config.LoadError(); err != nil {
		logger.Warningf("config load warning: %v", err)
	}
	_ = config.GetValue()
	messages.RegisterAll()
	cli := &ServerCLI{states: serverstates.New()}
	if os.Getenv("BS_AUTO_START") == "1" {
		ip := os.Getenv("BS_IP")
		if ip == "" {
			ip = "0.0.0.0"
		}
		port := 9339
		if p, err := strconv.Atoi(os.Getenv("BS_PORT")); err == nil {
			port = p
		}
		cli.startServer(ip, port)
		select {}
	}
	cli.run()
}
