package battle

import (
	"math"

	"brawlserver/internal/database"
	"brawlserver/internal/logic"
)

type Rewards struct {
	TokensGain          int
	TrophiesGain        int
	DoubledTokens       int
	RemainingTokens     int
	ExpRewardsArray     map[int]int
	BrawlerTrophies     int
	BrawlerTrophiesRank int
	Experience          int
	StarPlayerExp       int
	HasStarKey          bool
}

type BattleFields struct {
	GameMode     int
	Rank         int
	Victory      int
	Result       int
	IsInRealGame bool
	HeroesCount  int
	Heroes       []Hero
	ReceiveTime  float64
}

type Hero struct {
	ID         [2]int
	SkinID     [2]int
	Trophies   int
	PowerLevel int
	Team       int
	IsPlayer   bool
	Name       string
	LowID      int
}

type Manager struct {
	Player               *logic.Player
	DB                   *database.DataBase
	rank                 int
	brawlerT             int
	brawlerTRank         int
	hasStarKey           bool
	rankTrophies         []int
	expRewards           []int
	tokenRewards         []int
	trophiesGain         int
	experienceGain       int
	tokensGain           int
	starPlayerExp        int
	expRewardsArray      map[int]int
	doubledTokens        int
	remainingTokens      int
	totalTokens          int
	milestonesRewardRank int
}

func NewManager(p *logic.Player, db *database.DataBase) *Manager {
	return &Manager{Player: p, DB: db}
}

func (m *Manager) getTrophyModifiers(trophies int) (int, int, int) {
	ranges := []struct{ lo, hi, a, b, c int }{
		{0, 29, 0, 0, 6},
		{30, 59, -1, 0, 6},
		{60, 99, -2, 0, 6},
		{100, 139, -2, 0, 5},
		{140, 219, -3, 0, 5},
		{220, 299, -4, 0, 5},
		{300, 499, -5, 0, 5},
		{500, 599, -6, 0, 5},
		{600, 699, -7, 0, 4},
		{700, 799, -7, 0, 3},
		{800, 899, -8, 0, 3},
		{900, math.MaxInt32, -9, 0, 2},
	}
	for _, r := range ranges {
		if r.lo <= trophies && trophies <= r.hi {
			return r.a, r.b, r.c
		}
	}
	return 0, 0, 0
}

func (m *Manager) getSoloTrophyModifiers(trophies int) []int {
	ranges := []struct {
		lo, hi int
		t      []int
	}{
		{0, 29, []int{8, 7, 6, 5, 5, 4, 3, 2, 1, 0}},
		{30, 59, []int{8, 7, 6, 4, 3, 2, 0, -1, -2, -4}},
		{60, 99, []int{8, 7, 5, 4, 3, 1, 0, -2, -3, -4}},
		{100, 139, []int{7, 6, 5, 3, 2, 1, -1, -2, -3, -4}},
		{140, 219, []int{7, 6, 4, 3, 2, 0, -1, -3, -4, -5}},
		{220, 299, []int{7, 6, 4, 3, 1, 0, -2, -3, -4, -5}},
		{300, 499, []int{7, 6, 4, 2, 1, -1, -2, -4, -6, -7}},
		{500, 599, []int{6, 5, 3, 2, 0, -2, -3, -4, -6, -7}},
		{600, 699, []int{5, 4, 3, 1, -1, -2, -3, -4, -6, -7}},
		{700, math.MaxInt32, []int{5, 3, 2, 1, -1, -2, -4, -5, -6, -7}},
	}
	for _, r := range ranges {
		if r.lo <= trophies && trophies <= r.hi {
			return r.t
		}
	}
	return []int{0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
}

func (m *Manager) getDuoTrophyModifiers(trophies int) []int {
	ranges := []struct {
		lo, hi int
		t      []int
	}{
		{0, 29, []int{7, 5, 4, 2, 0}},
		{30, 59, []int{7, 5, 2, -1, -3}},
		{60, 99, []int{7, 4, 2, -1, -4}},
		{100, 139, []int{6, 4, 1, -1, -4}},
		{140, 219, []int{6, 4, 1, -2, -5}},
		{220, 499, []int{6, 3, 0, -3, -6}},
		{500, 599, []int{6, 3, 0, -4, -6}},
		{600, 699, []int{4, 2, -1, -4, -6}},
		{700, 799, []int{3, 1, -1, -4, -6}},
		{800, 899, []int{3, 1, -2, -5, -7}},
		{900, math.MaxInt32, []int{2, 0, -3, -5, -7}},
	}
	for _, r := range ranges {
		if r.lo <= trophies && trophies <= r.hi {
			return r.t
		}
	}
	return []int{0, 0, 0, 0, 0}
}

func (m *Manager) ProcessRewards(fields *BattleFields) *Rewards {
	m.rank = fields.Rank
	hero0 := fields.Heroes[0]
	key := itoa(hero0.ID[1])
	bd := m.Player.UnlockedBrawlers.Get(key)
	if bd == nil {
		return &Rewards{}
	}
	m.brawlerT = bd.Trophies
	m.brawlerTRank = bd.HighestTrophies
	m.hasStarKey = false

	switch fields.GameMode {
	case 2:
		m.rankTrophies = m.getSoloTrophyModifiers(m.brawlerT)
		if fields.Rank <= 4 {
			m.hasStarKey = true
		}
	case 5:
		m.rankTrophies = m.getDuoTrophyModifiers(m.brawlerT)
		if fields.Rank <= 2 {
			m.hasStarKey = true
		}
	default:
		a, b, c := m.getTrophyModifiers(m.brawlerT)
		m.rankTrophies = []int{a, b, c}
		m.rank = fields.Victory
		if fields.Victory == 0 {
			m.hasStarKey = true
		}
	}

	switch fields.GameMode {
	case 2:
		m.expRewards = []int{0, 1, 2, 3, 4, 5, 6, 9, 12, 15}
		m.tokenRewards = []int{0, 2, 4, 6, 8, 12, 16, 22, 28, 34}
	case 5:
		m.expRewards = []int{0, 2, 4, 8, 14}
		m.tokenRewards = []int{0, 4, 8, 20, 32}
	default:
		m.expRewards = []int{4, 6, 8}
		m.tokenRewards = []int{10, 15, 20}
	}

	if m.Player.TutorialState == 2 {
		m.trophiesGain = pyIdx(m.rankTrophies, m.rank-1)
		m.experienceGain = pyIdx(m.expRewards, m.rank-1)
		m.tokensGain = pyIdx(m.tokenRewards, m.rank-1)
	}

	if hero0.IsPlayer {
		if m.Player.TutorialState == 2 {
			m.experienceGain += 10
			m.starPlayerExp = 10
		}
		m.expRewardsArray = map[int]int{0: m.experienceGain, 8: m.starPlayerExp}
	} else {
		m.starPlayerExp = 0
		m.expRewardsArray = map[int]int{0: m.experienceGain}
	}

	if m.tokensGain < m.Player.TokensDoubler {
		m.doubledTokens = m.tokensGain
	} else {
		m.doubledTokens = m.Player.TokensDoubler
	}
	m.remainingTokens = m.Player.TokensDoubler - m.doubledTokens
	m.totalTokens = m.tokensGain + m.doubledTokens

	m.milestonesRewardRank = 0
	bd.Trophies += m.trophiesGain
	if bd.HighestTrophies < bd.Trophies {
		bd.HighestTrophies = bd.Trophies
	}
	for _, milestone := range logic.RankTrophies {
		if m.brawlerT < milestone && bd.Trophies >= milestone {
			m.milestonesRewardRank = 10
		}
	}

	if m.Player.TutorialState == 2 {
		if m.hasStarKey {
			m.Player.StarkeysReward = 1
			m.Player.BigBoxes += 1
		}
		switch fields.GameMode {
		case 2:
			m.Player.SoloWins += 1
			m.DB.ReplaceValue("solo_wins", m.Player.SoloWins)
		case 5:
			m.Player.DuoWins += 1
			m.DB.ReplaceValue("duo_wins", m.Player.DuoWins)
		default:
			m.Player.ThreeVSThreeWins += 1
			m.DB.ReplaceValue("three_vs_three_wins", m.Player.ThreeVSThreeWins)
		}
		m.Player.PlayerExperience += m.experienceGain + m.starPlayerExp
		m.Player.TokensDoubler = m.remainingTokens
		m.Player.BrawlBoxes += m.totalTokens
		m.Player.Trophies += m.trophiesGain
		if m.Player.Trophies > m.Player.HighestTrophies {
			m.Player.HighestTrophies = m.Player.Trophies
		}
		m.Player.TrophyReward = m.trophiesGain
		m.Player.KeyReward = m.totalTokens
		if m.hasStarKey {
			m.Player.StarKeyReward = 1
		} else {
			m.Player.StarKeyReward = 0
		}
		m.DB.ReplaceValue("key_reward", m.Player.KeyReward)
		m.DB.ReplaceValue("trophy_reward", m.Player.TrophyReward)
		m.DB.ReplaceValue("star_key_reward", m.Player.StarKeyReward)
		m.DB.ReplaceValue("unlocked_brawlers", m.Player.UnlockedBrawlers)
		m.DB.ReplaceValue("player_experience", m.Player.PlayerExperience)
		m.DB.ReplaceValue("tokens_doubler", m.Player.TokensDoublerDB)
		m.DB.ReplaceValue("brawl_boxes", m.Player.BrawlBoxes)
		m.DB.ReplaceValue("big_boxes", m.Player.BigBoxes)
		m.DB.ReplaceValue("trophies", m.Player.Trophies)
		m.DB.ReplaceValue("highest_trophies", m.Player.HighestTrophies)
	}

	return &Rewards{
		TokensGain:          m.tokensGain,
		TrophiesGain:        m.trophiesGain,
		DoubledTokens:       m.doubledTokens,
		RemainingTokens:     m.remainingTokens,
		ExpRewardsArray:     m.expRewardsArray,
		BrawlerTrophies:     m.brawlerT,
		BrawlerTrophiesRank: m.brawlerTRank,
		Experience:          m.experienceGain,
		StarPlayerExp:       m.starPlayerExp,
		HasStarKey:          m.hasStarKey,
	}
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	neg := i < 0
	if neg {
		i = -i
	}
	var buf [12]byte
	pos := len(buf)
	for i > 0 {
		pos--
		buf[pos] = byte('0' + i%10)
		i /= 10
	}
	if neg {
		pos--
		buf[pos] = '-'
	}
	return string(buf[pos:])
}

func pyIdx(s []int, i int) int {
	n := len(s)
	if n == 0 {
		return 0
	}
	if i < 0 {
		i += n
	}
	if i < 0 || i >= n {
		return s[n-1]
	}
	return s[i]
}
