package battle

func MapGemGrab4(stream *BitStream) {
	for i := 0; i < 142; i++ {
		stream.WritePositiveInt(0, 1)
	}
}

func MapHeist3(stream *BitStream) {
	for i := 0; i < 102; i++ {
		stream.WritePositiveInt(0, 1)
	}
}

func MapBall2(stream *BitStream) {
	for i := 0; i < 165; i++ {
		stream.WritePositiveInt(0, 1)
	}
}
