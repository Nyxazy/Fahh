package battle

type BattlePlayer struct {
	GameObjects                  int
	ShouldRespawnEverythingState int
	BallScoreState               int
	IsBallAlone                  bool
	TeamScore                    [6]int
	EnnemyScore                  [6]int
	HasBall                      [6]bool
	PlayersX                     [7]int
	PlayersY                     [7]int
	PlayersAngle                 [6]int
	PlayersHp                    [7]int
	PlayersMaxHp                 [6]int
	PlayersItems                 [6]int
	PlayersDamages               [6]int
	PlayersDamage                [6]int
	ObjectLowID                  [7]int
	ObjectHighID                 [7]int
	GameObjectType               [7]string
	HasAllWallDestroyed          bool
	BrawlerID                    int
}

func NewBattlePlayer() *BattlePlayer {
	return &BattlePlayer{IsBallAlone: true}
}
