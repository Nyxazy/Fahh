package battle

import "math"

func LogicGameObjectServerEncode(stream *BitStream, player *BattlePlayer, index int) {
	stream.WritePositiveInt(player.PlayersX[index], 13)
	stream.WritePositiveInt(player.PlayersY[index], 14)
	stream.WritePositiveInt(0, 7)
	stream.WritePositiveInt(0, 12)
	stream.WritePositiveInt(10, 4)
}

func LogicCharacterServerEncode(stream *BitStream, player *BattlePlayer, objectIndex int) {
	LogicGameObjectServerEncode(stream, player, objectIndex)
	if objectIndex != 6 {
		if objectIndex == 0 {
			stream.WritePositiveInt(0, 1)
		} else {
			stream.WritePositiveInt(player.PlayersAngle[objectIndex], 9)
			stream.WritePositiveInt(player.PlayersAngle[objectIndex], 9)
		}
		stream.WritePositiveInt(0, 3)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(1, 1)
		stream.WritePositiveInt(63, 6)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 2)
		stream.WritePositiveInt(0, 7)
		stream.WritePositiveInt(0, 5)
		stream.WritePositiveInt(player.PlayersHp[objectIndex], 13)
		stream.WritePositiveInt(player.PlayersMaxHp[objectIndex], 13)
		stream.WritePositiveInt(player.PlayersItems[objectIndex], 6)
		stream.WritePositiveInt(int(boolToInt(player.HasBall[objectIndex])), 1)
		stream.WritePositiveInt(0, 13)
		stream.WritePositiveInt(0, 11)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(1, 1)
		stream.WritePositiveInt(1, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 9)
		if objectIndex == 0 {
			stream.WritePositiveInt(1, 1)
			stream.WritePositiveInt(0, 9)
		}
		if player.ShouldRespawnEverythingState == 1 {
			player.PlayersDamages[objectIndex] = 1
			player.PlayersDamage[objectIndex] = player.PlayersHp[objectIndex]
		}
		stream.WritePositiveInt(player.PlayersDamages[objectIndex], 5)
		for x := 0; x < player.PlayersDamages[objectIndex]; x++ {
			stream.WritePositiveInt(player.PlayersDamage[objectIndex], 15)
			player.PlayersHp[objectIndex] -= player.PlayersDamage[objectIndex]
		}
		stream.WritePositiveInt(0, 11)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 12)
		stream.WritePositiveInt(3000, 12)
		stream.WritePositiveInt(0, 11)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 12)
	} else {
		stream.WritePositiveInt(player.PlayersX[objectIndex], 13)
		stream.WritePositiveInt(player.PlayersY[objectIndex], 14)
		stream.WritePositiveInt(102, 7)
		stream.WritePositiveInt(0, 12)
		stream.WritePositiveInt(10, 4)
		stream.WritePositiveInt(0, 3)
		if player.BallScoreState == 2 {
			player.BallScoreState = 3
		}
		stream.WritePositiveInt(player.PlayersHp[objectIndex], 13)
		stream.WritePositiveInt(1, 13)
		stream.WritePositiveInt(0, 2)
		stream.WritePositiveInt(0, 2)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 1)
		stream.WritePositiveInt(0, 9)
		if player.BallScoreState == 1 {
			player.PlayersDamage[objectIndex] = 1
			player.BallScoreState = 3
		}
		stream.WritePositiveInt(player.PlayersDamage[objectIndex], 5)
		for x := 0; x < player.PlayersDamage[objectIndex]; x++ {
			stream.WritePositiveInt(1, 15)
		}
	}
}

func LogicGameObjectManagerEncode(stream *BitStream, player *BattlePlayer, tick, mapIndex, tileMapHeight, tileMapWidth, gameModeVariation int) {
	stream.WritePositiveInt(2000000, 21)
	stream.WritePositiveInt(0, 15)
	stream.WriteBoolean(false)
	stream.WriteBoolean(false)
	stream.WriteBoolean(false)
	stream.WriteBoolean(false)
	stream.WriteBoolean(false)
	if tileMapWidth < 21 {
		stream.WritePositiveInt(0, 5)
		stream.WritePositiveInt(0, 6)
		stream.WritePositiveInt(tileMapWidth, 5)
		stream.WritePositiveInt(tileMapHeight, 6)
	} else {
		stream.WritePositiveInt(0, 6)
		stream.WritePositiveInt(0, 7)
		stream.WritePositiveInt(tileMapWidth, 6)
		stream.WritePositiveInt(tileMapHeight, 7)
	}
	for x := 0; x < 165; x++ {
		stream.WriteBoolean(player.HasAllWallDestroyed)
	}
	for x := 0; x < 6; x++ {
		stream.WriteBoolean(true)
		stream.WriteBoolean(true)
		if x == 0 {
			stream.WritePositiveInt(4000, 12)
		}
	}
	switch gameModeVariation {
	case 5:
		stream.WriteBoolean(true)
		stream.WritePositiveInt(1, 1)
		stream.WritePositiveInt(0, 1)
	case 6:
		stream.WritePositiveInt(0, 4)
	case 9:
		stream.WritePositiveInt(0, 3)
	case 3:
		stream.WritePositiveInt(0, 3)
		stream.WritePositiveInt(0, 3)
	case 7:
		stream.WritePositiveInt(0, 7)
	}
	for x := 0; x < 6; x++ {
		stream.WritePositiveInt(player.TeamScore[x], 7)
		stream.WritePositiveInt(0, 4)
	}
	for players := 0; players < 6; players++ {
		distance := int(math.Sqrt(float64((player.PlayersX[players]-player.PlayersX[6])*(player.PlayersX[players]-player.PlayersX[6]) + (player.PlayersY[players]-player.PlayersY[6])*(player.PlayersY[players]-player.PlayersY[6]))))
		_ = distance
		if player.GameObjects == 0 {
			player.GameObjects = 7
			player.PlayersX[players] = 1950
			player.PlayersY[players] = 6450
			player.PlayersX[6] = 2550
			player.PlayersY[6] = 4950
		}
		if player.ShouldRespawnEverythingState == 1 {
			player.GameObjects = 0
			player.ShouldRespawnEverythingState = 0
		}
		if player.BallScoreState == 5 {
			player.ShouldRespawnEverythingState = 1
			player.BallScoreState = 0
		}
		if player.BallScoreState == 4 {
			player.BallScoreState = 5
			player.HasBall[players] = false
		}
		if player.BallScoreState == 3 {
			player.GameObjects = 6
			player.BallScoreState = 4
		}
		if distance <= 600 && player.IsBallAlone && player.GameObjects == 7 {
			player.HasBall[players] = true
			player.IsBallAlone = false
			player.TeamScore[players] += 1
			player.BallScoreState = 1
		}
		if player.HasBall[players] {
			player.PlayersX[6] = player.PlayersX[players] + 10
			player.PlayersY[6] = player.PlayersY[players] + 100
		}
	}
	if player.PlayersY[6] == 0 {
		player.BallScoreState = 1
	}
	stream.WritePositiveInt(player.GameObjects, 7)
	for objects := 0; objects < player.GameObjects; objects++ {
		stream.WritePositiveInt(player.ObjectLowID[objects], 5)
		stream.WritePositiveInt(player.ObjectHighID[objects], 8)
	}
	for index := 0; index < player.GameObjects; index++ {
		stream.WritePositiveInt(2, 5)
		stream.WritePositiveInt(index, 14)
	}
	for index := 0; index < player.GameObjects; index++ {
		if player.GameObjectType[index] == "Character" {
			LogicCharacterServerEncode(stream, player, index)
		}
	}
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}
