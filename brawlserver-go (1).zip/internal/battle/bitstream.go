package battle

type BitStream struct {
	buffer   []byte
	bitIndex int
	offset   int
}

func NewBitStream() *BitStream {
	return &BitStream{buffer: []byte{}}
}

func (b *BitStream) GetBuffer() []byte { return b.buffer }

func (b *BitStream) Size() int { return len(b.buffer) }

func (b *BitStream) ReadBit() int {
	if b.offset > len(b.buffer) {
		return 0
	}
	value := (b.buffer[b.offset] >> b.bitIndex) & 1
	b.bitIndex++
	if b.bitIndex == 8 {
		b.bitIndex = 0
		b.offset++
	}
	return int(value)
}

func (b *BitStream) WriteBit(data int) {
	if b.bitIndex == 0 {
		b.offset++
		b.buffer = append(b.buffer, 0xff)
	}
	value := b.buffer[b.offset-1]
	value &= ^(1 << b.bitIndex)
	value |= byte(data << b.bitIndex)
	b.buffer[b.offset-1] = value
	b.bitIndex = (b.bitIndex + 1) % 8
}

func (b *BitStream) writeBits(bits []int, count int) {
	i := 0
	position := 0
	for i < count {
		p := 0
		for p < 8 && i < count {
			value := (bits[position] >> p) & 1
			b.WriteBit(value)
			p++
			i++
		}
		position++
	}
}

func (b *BitStream) WriteBoolean(value bool) {
	if value {
		b.WritePositiveInt(1, 1)
	} else {
		b.WritePositiveInt(0, 1)
	}
}

func (b *BitStream) writePositiveIntBytes(value []byte, bitsCount int) {
	bits := make([]int, bitsCount)
	for i := 0; i < bitsCount; i++ {
		bits[i] = 0
	}
	bitterly := make([]int, 0)
	for i := 0; i < len(value); i++ {
		for bit := 0; bit < 8; bit++ {
			bitterly = append(bitterly, (int(value[i])>>bit)&1)
		}
	}
	for i := 0; i < bitsCount && i < len(bitterly); i++ {
		bits[i] = bitterly[i]
	}
	b.writeBits(bits, bitsCount)
}

func (b *BitStream) WritePositiveInt(value int, bitsCount int) {
	buf := make([]byte, 4)
	for i := 0; i < 4; i++ {
		buf[3-i] = byte(value >> (i * 8))
	}
	b.writePositiveIntBytes(buf, bitsCount)
}

func (b *BitStream) WriteInt(value int, bitsCount int) {
	val := value
	if val <= -1 {
		b.WritePositiveInt(0, 1)
		val = -value
	} else if val >= 0 {
		b.WritePositiveInt(1, 1)
		val = value
	}
	b.WritePositiveInt(val, bitsCount)
}

func (b *BitStream) WritePositiveVInt(value int, count int) {
	v3 := 1
	v7 := value
	if v7 != 0 {
		if v7 < 1 {
			v3 = 0
		} else {
			v8 := v7
			v3 = 0
			v3++
			v8 >>= 1
			for v8 != 0 {
				v3++
				v8 >>= 1
			}
		}
	}
	b.WritePositiveInt(v3-1, count)
	b.WritePositiveInt(v7, v3)
}

func (b *BitStream) WritePVIntMax255OZ(value int) {
	if value == 0 {
		b.WritePositiveInt(1, 1)
		return
	}
	b.WritePositiveInt(0, 1)
	b.WritePositiveVInt(value, 3)
}

func (b *BitStream) WritePVIntMax65535OZ(value int) {
	if value == 0 {
		b.WritePositiveInt(1, 1)
		return
	}
	b.WritePositiveInt(0, 1)
	b.WritePositiveVInt(value, 4)
}

func (b *BitStream) WriteOldPositiveInt(value int, bitsCount int) {
	b.WritePositiveInt(value, bitsCount)
}
