package battle

const (
	ArtTest           = false
	BattleRoyaleTicks = 16000
	LaserBallTicks    = 4280
	BossFightTicks    = 9680
	NormalTicks       = 3080
)

func GetBattleTicks(gameModeVariation int) int {
	if ArtTest {
		return 99999999
	}
	switch gameModeVariation {
	case 9, 6:
		return BattleRoyaleTicks
	case 5:
		return LaserBallTicks
	case 7:
		return BossFightTicks
	default:
		return NormalTicks
	}
}

func SetDefaultStartRotation(playerTeam int) int {
	if playerTeam == 1 {
		return 90
	}
	return 270
}
