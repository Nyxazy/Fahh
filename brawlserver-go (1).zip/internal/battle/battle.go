package battle

import "math"

type BattleState struct {
	BattleTicks [4]float64
	X           [4][6]int
	Y           [4][6]int
	Dx          [4][6]int
	Dy          [4][6]int
	Gems        [4][6]int
	Brawler     [4][6]int
}

func NewBattleState() *BattleState {
	b := &BattleState{}
	for i := 0; i < 4; i++ {
		b.X[i] = [6]int{2550, 2550, 0, 0, 0, 0}
		b.Y[i] = [6]int{150, 9750, 0, 0, 0, 0}
		b.Dx[i] = [6]int{2550, 2550, 0, 0, 0, 0}
		b.Dy[i] = [6]int{150, 9750, 0, 0, 0, 0}
	}
	return b
}

var DefaultBattle = NewBattleState()

func Update(player, mapIdx int) {
	movespeed := 30
	deltaX := [6]int{}
	deltaY := [6]int{}

	hacc := DefaultBattle.Dx[mapIdx][player] - DefaultBattle.X[mapIdx][player]
	hacc2 := DefaultBattle.Dy[mapIdx][player] - DefaultBattle.Y[mapIdx][player]

	if hacc != 0 {
		if hacc > 0 {
			if movespeed <= hacc {
				deltaX[player] += movespeed
			} else {
				deltaX[player] += hacc
			}
		} else {
			if -movespeed >= hacc {
				deltaX[player] += -movespeed
			} else {
				deltaX[player] += hacc
			}
		}
		DefaultBattle.X[mapIdx][player] += deltaX[player]
	}

	if hacc2 != 0 {
		if hacc2 > 0 {
			if movespeed <= hacc2 {
				deltaY[player] += movespeed
			} else {
				deltaY[player] += hacc2
			}
		} else {
			if -movespeed >= hacc2 {
				deltaY[player] += -movespeed
			} else {
				deltaY[player] += hacc2
			}
		}
		DefaultBattle.Y[mapIdx][player] += deltaY[player]
	}
}

func getDistance(ob1x, ob1y, ob2x, ob2y int) int {
	xDist := ob1x - ob2x
	if xDist < 0 {
		xDist = -xDist
	}
	yDist := ob1y - ob2y
	if yDist < 0 {
		yDist = -yDist
	}
	return int(math.Sqrt(float64(xDist*xDist + yDist*yDist)))
}
