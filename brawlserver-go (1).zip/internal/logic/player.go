package logic

import (
	"encoding/json"

	"brawlserver/internal/config"
	"brawlserver/internal/csvlogic"
)

type BrawlerData struct {
	CardID          int   `json:"CardID"`
	Skins           []int `json:"Skins"`
	SelectedSkin    int   `json:"selectedSkin"`
	Trophies        int   `json:"Trophies"`
	HighestTrophies int   `json:"HighestTrophies"`
	PowerLevel      int   `json:"PowerLevel"`
	PowerPoints     int   `json:"PowerPoints"`
	State           int   `json:"State"`
	StarPower       int   `json:"StarPower"`
}

func NewBrawlerData(cardID, state int) *BrawlerData {
	return &BrawlerData{CardID: cardID, Skins: []int{0}, State: state}
}

type Player struct {
	Name               string         `json:"name"`
	LowID              int            `json:"low_id"`
	ClubID             int            `json:"club_id"`
	ClubRole           int            `json:"club_role"`
	IsFbLinked         int            `json:"is_fb_linked"`
	FacebookID         string         `json:"facebook_id"`
	FacebookToken      string         `json:"-"`
	PlayerExperience   int            `json:"player_experience"`
	SoloWins           int            `json:"solo_wins"`
	DuoWins            int            `json:"duo_wins"`
	ThreeVSThreeWins   int            `json:"three_vs_three_wins"`
	Gems               int            `json:"gems"`
	Gold               int            `json:"gold"`
	KeyReward          int            `json:"key_reward"`
	TrophyReward       int            `json:"trophy_reward"`
	StarKeyReward      int            `json:"star_key_reward"`
	TokensDoublerDB    int            `json:"tokens_doubler"`
	PlayerTokens       int            `json:"player_tokens"`
	Tickets            int            `json:"tickets"`
	AvailableTokensDB  int            `json:"available_tokens"`
	BrawlerID          int            `json:"brawler_id"`
	SkinID             int            `json:"skin_id"`
	Trophies           int            `json:"trophies"`
	HighestTrophies    int            `json:"highest_trophies"`
	ProfileIcon        int            `json:"profile_icon"`
	BrawlBoxes         int            `json:"brawl_boxes"`
	BigBoxes           int            `json:"big_boxes"`
	DoNotDisturb       int            `json:"do_not_disturb"`
	RoomID             int            `json:"room_id"`
	UnlockedBrawlers   *BrawlerMap    `json:"unlocked_brawlers"`
	Friends            map[string]int `json:"friends"`
	LastConnectionTime float64        `json:"last_connection_time"`
	PlayerStatus       int            `json:"player_status"`
	TutorialState      int            `json:"tutorialState"`
	TrophyRoad         int            `json:"trophyRoad"`
	MatchmakeSlot      any            `json:"matchmakeSlot"`
	MatchmakeState     int            `json:"matchmakeState"`
	Region             string         `json:"region"`
	UnlockedEvents     int            `json:"unlockedEvents"`

	HighID              int     `json:"-"`
	Token               string  `json:"-"`
	BoxID               int     `json:"-"`
	LastRecieved        int     `json:"-"`
	LastEventTimeStamp  int64   `json:"-"`
	LastChaosMap        int     `json:"-"`
	LastSeenKey         int     `json:"-"`
	LastSeenGameroomKey int     `json:"-"`
	IsTrophyRoad        bool    `json:"-"`
	PreferredLanguage   [2]int  `json:"-"`
	MapID               int     `json:"-"`
	MapIndex            int     `json:"-"`
	MaintenanceTime     int     `json:"-"`
	SlotIndex           int     `json:"-"`
	SkinsID             []int   `json:"-"`
	BrawlersID          []int   `json:"-"`
	CardSkillsID        []int   `json:"-"`
	CardUnlockID        []int   `json:"-"`
	NameColor           int     `json:"-"`
	ExpPoints           int     `json:"-"`
	BattleTick          int     `json:"-"`
	ClubHighID          int     `json:"-"`
	StarkeysReward      int     `json:"-"`
	Playermmindex       int     `json:"-"`
	UpdateURL           string  `json:"-"`
	PatchURL            string  `json:"-"`
	PatchSha            string  `json:"-"`
	ErrCode             int     `json:"-"`
	Maintenance         bool    `json:"-"`
	Patch               bool    `json:"-"`
	MessageTick         int     `json:"-"`
	BotMessageTick      int     `json:"-"`
	BattleResult        int     `json:"-"`
	GameType            int     `json:"-"`
	Rank                int     `json:"-"`
	Team                int     `json:"-"`
	IsReady             bool    `json:"-"`
	Result              int     `json:"-"`
	Bot1                int     `json:"-"`
	Bot1N               *string `json:"-"`
	Bot2                int     `json:"-"`
	Bot2N               *string `json:"-"`
	Bot3                int     `json:"-"`
	Bot3N               *string `json:"-"`
	Bot4                int     `json:"-"`
	Bot4N               *string `json:"-"`
	Bot5                int     `json:"-"`
	Bot5N               *string `json:"-"`
	DeviceID            string  `json:"-"`
	Device              string  `json:"-"`

	TokensDoubler   int `json:"-"`
	AvailableTokens int `json:"-"`
	Tokens          int `json:"-"`
}

func defaultBrawlers() *BrawlerMap {
	m := NewBrawlerMap()
	m.Set("0", &BrawlerData{CardID: 0, Skins: []int{0}, SelectedSkin: 0, Trophies: 0, HighestTrophies: 0, PowerLevel: 0, PowerPoints: 0, State: 2, StarPower: 0})
	return m
}

func NewPlayer() *Player {
	cfg := config.GetValue()
	p := &Player{
		HighID:             0,
		Token:              "None",
		PlayerStatus:       3,
		LastConnectionTime: 0,
		FacebookID:         "None",
		Friends:            map[string]int{},
		MapID:              7,
		MaintenanceTime:    777,
		Region:             "FR",
		Name:               "Brawler",
		PlayerExperience:   0,
		BrawlBoxes:         cfg.BrawlBoxTokens,
		BigBoxes:           cfg.BigBoxTokens,
		Trophies:           cfg.Trophies,
		ExpPoints:          cfg.ExperiencePoints,
		Gems:               cfg.Gems,
		Gold:               cfg.Gold,
		Tickets:            cfg.Tickets,
		AvailableTokens:    500,
		AvailableTokensDB:  500,
		TrophyRoad:         1,
		LowID:              0,
		TutorialState:      2,
		UnlockedBrawlers:   defaultBrawlers(),
		UpdateURL:          cfg.UpdateUrl,
		PatchURL:           cfg.PatchUrl,
	}
	p.PatchSha = LoadFingerprint("GameAssets/fingerprint.json")
	if cfg.Patch {
		p.ErrCode = 7
		p.Patch = true
	}
	if cfg.Maintenance {
		p.ErrCode = 10
		p.Maintenance = true
	}

	p.SkinsID = csvlogic.GetSkinsID()
	p.BrawlersID = csvlogic.GetBrawlersID()
	p.CardSkillsID = csvlogic.GetSpgID()
	p.CardUnlockID = csvlogic.GetBrawlerUnlock()
	return p
}

func (p *Player) MarshalJSON() ([]byte, error) {
	type alias Player
	return json.Marshal((*alias)(p))
}

func (p *Player) UnmarshalJSON(data []byte) error {
	type alias Player
	tmp := NewPlayerDefaultsOnly()
	if err := json.Unmarshal(data, (*alias)(tmp)); err != nil {
		return err
	}
	*p = *tmp
	return nil
}

func NewPlayerDefaultsOnly() *Player {
	cfg := config.GetValue()
	return &Player{
		Name:              "Brawler",
		Region:            "FR",
		MapID:             7,
		MaintenanceTime:   777,
		AvailableTokens:   500,
		AvailableTokensDB: 500,
		TrophyRoad:        1,
		TutorialState:     2,
		PlayerStatus:      3,
		Token:             "None",
		FacebookID:        "None",
		Friends:           map[string]int{},
		UnlockedBrawlers:  defaultBrawlers(),
		BrawlBoxes:        cfg.BrawlBoxTokens,
		BigBoxes:          cfg.BigBoxTokens,
		Gems:              cfg.Gems,
		Gold:              cfg.Gold,
		Tickets:           cfg.Tickets,
		Trophies:          cfg.Trophies,
		ExpPoints:         cfg.ExperiencePoints,
		UpdateURL:         cfg.UpdateUrl,
		PatchURL:          cfg.PatchUrl,
	}
}
