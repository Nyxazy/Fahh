package logic

import (
	"encoding/json"
	"math"
	"os"

	"brawlserver/internal/csvlogic"
)

func LoadFingerprint(path string) string {
	data, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	var m map[string]any
	if err := json.Unmarshal(data, &m); err != nil {
		return ""
	}
	if s, ok := m["sha"].(string); ok {
		return s
	}
	return ""
}

func LoadFingerprintFull(path string) string {
	data, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	var m map[string]any
	if err := json.Unmarshal(data, &m); err != nil {
		return ""
	}
	out, err := json.Marshal(m)
	if err != nil {
		return ""
	}
	return string(out)
}

type ShopOffer struct {
	OfferID          int `json:"OfferID"`
	Value            int `json:"Value"`
	Currency         int `json:"Currency"`
	Price            int `json:"Price"`
	Timer            int `json:"Timer"`
	IsOfferSeen      int `json:"IsOfferSeen"`
	IsOfferPurchased int `json:"IsOfferPurchased"`
}

type ShopBoxes struct {
	Name       string `json:"Name"`
	Cost       int    `json:"Cost"`
	Multiplier int    `json:"Multiplier"`
}

type ShopGold struct {
	Cost   int `json:"Cost"`
	Amount int `json:"Amount"`
}

var (
	ShopOffers = []ShopOffer{
		{OfferID: 15, Value: 1, Currency: 0, Price: 0, Timer: 777, IsOfferSeen: 0, IsOfferPurchased: 0},
		{OfferID: 2, Value: 20, Currency: 0, Price: 0, Timer: 777, IsOfferSeen: 0, IsOfferPurchased: 0},
		{OfferID: 4, Value: 86, Currency: 0, Price: 0, Timer: 777, IsOfferSeen: 0, IsOfferPurchased: 0},
	}
	ShopBoxesList = []ShopBoxes{
		{Name: "Big Box", Cost: 30, Multiplier: 3},
		{Name: "Mega Box", Cost: 80, Multiplier: 10},
	}
	ShopGoldList = []ShopGold{
		{Cost: 20, Amount: 150},
		{Cost: 50, Amount: 400},
		{Cost: 140, Amount: 1200},
	}
	ShopTokenDoubler = ShopGold{Cost: 50, Amount: 1000}
)

var MilestonesArray = []int{
	1, 0, 0, 10, 0, 1, 11, 10, 0, 0, 0, 1, 1, 10, 10, 0, 1, 11, 10, 0, 0, 0, 1, 2, 20, 10, 0, 1, 11, 10, 0, 0, 0, 1, 3, 30, 10, 0, 1, 11, 10, 0, 0, 0, 1, 4, 40, 20, 0, 1, 11, 10, 0, 0, 0, 1, 5, 60, 20, 0, 1, 11, 10, 0, 0, 0, 1, 6, 80, 20, 0, 1, 11, 10, 0, 0, 0, 1, 7, 100, 20, 0, 1, 11, 10, 0, 0, 0, 1, 8, 120, 20, 0, 1, 11, 10, 0, 0, 0, 1, 9, 140, 20, 0, 1, 11, 10, 0, 0, 0, 1, 10, 160, 20, 0, 1, 11, 10, 0, 0, 0, 1, 11, 180, 40, 0, 1, 11, 10, 0, 0, 0, 1, 12, 220, 40, 0, 1, 11, 10, 0, 0, 0, 1, 13, 260, 40, 0, 1, 11, 10, 0, 0, 0, 1, 14, 300, 40, 0, 1, 11, 10, 0, 0, 0, 1, 15, 340, 40, 0, 1, 11, 10, 0, 0, 0, 1, 16, 380, 40, 0, 1, 11, 10, 0, 0, 0, 1, 17, 420, 40, 0, 1, 11, 10, 0, 0, 0, 1, 18, 460, 40, 0, 1, 11, 10, 0, 0, 0,
}

var RankTrophies = []int{0, 10, 20, 30, 40, 60, 80, 100, 120, 140, 160, 180, 220, 260, 300, 340, 380, 420, 460, 500}

type BoxDef struct {
	Name             string
	NewCharPosition  string
	MaxUpgradePoints int
	Price            int
	Coins            [2]int
	UpgradePoints    [2]int
	Tickets          []int
	Gems             []int
	TokensDoubler    []int
}

var Boxes = []BoxDef{
	{Name: "Brawl Box", NewCharPosition: "Start", MaxUpgradePoints: 2, Coins: [2]int{13, 70}, UpgradePoints: [2]int{4, 25}, Tickets: []int{1, 2, 3}, Gems: []int{3, 5, 6, 8, 12}, TokensDoubler: []int{200}},
	{Name: "Big Box", NewCharPosition: "Middle", MaxUpgradePoints: 3, Coins: [2]int{25, 105}, UpgradePoints: [2]int{5, 30}, Gems: []int{3, 5, 6, 8, 12}, Tickets: []int{1, 2, 3, 5}, TokensDoubler: []int{200, 400}},
	{Name: "Shop Big Box", NewCharPosition: "Middle", MaxUpgradePoints: 3, Price: 30, Coins: [2]int{25, 105}, UpgradePoints: [2]int{5, 30}, Gems: []int{3, 5, 6, 8, 12}, Tickets: []int{1, 2, 3, 5}, TokensDoubler: []int{200, 400}},
	{Name: "Mega Box", NewCharPosition: "End", MaxUpgradePoints: 5, Price: 80, Coins: [2]int{100, 250}, UpgradePoints: [2]int{5, 50}, Tickets: []int{1, 2, 3, 5}, Gems: []int{3, 5, 6, 8, 12}, TokensDoubler: []int{200, 400, 600}},
}

const EventSlotTimer = 86399

type EventSlotMap struct {
	ID       int
	Status   int
	Ended    bool
	Modifier int
	Tokens   int
}

var EventSlotsMaps = []EventSlotMap{
	{ID: 7, Status: 2, Ended: false, Modifier: 3, Tokens: 10},
	{ID: 32, Status: 2, Ended: false, Modifier: 2, Tokens: 10},
	{ID: 0, Status: 2, Ended: false, Modifier: 1, Tokens: 10},
	{ID: 25, Status: 2, Ended: false, Modifier: 4, Tokens: 10},
	{ID: 38, Status: 2, Ended: false, Modifier: 5, Tokens: 10},
	{ID: 21, Status: 2, Ended: false, Modifier: 5, Tokens: 2},
}

func GetPlayerCountWithGameMode(gameModeVariation int) int {
	playerCount := 6
	if gameModeVariation == 8 {
		playerCount = 3
	}
	if gameModeVariation == 6 || gameModeVariation == 9 {
		playerCount = 10
	}
	if gameModeVariation != 0 {
		return playerCount
	}
	return 10
}

func GetDistanceBetween(x1, y1, x2, y2 float64) float64 {
	return math.Sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))
}

func AllLocationsList() []int {
	return csvlogic.GetAllLocations()
}
