package logic

import (
	"bytes"
	"encoding/json"
	"fmt"
	"sort"
)

type BrawlerEntry struct {
	Key  string
	Data *BrawlerData
}

type BrawlerMap struct {
	entries []BrawlerEntry
	index   map[string]int
}

func NewBrawlerMap() *BrawlerMap {
	return &BrawlerMap{index: map[string]int{}}
}

func (m *BrawlerMap) Len() int {
	if m == nil {
		return 0
	}
	return len(m.entries)
}

func (m *BrawlerMap) Get(key string) *BrawlerData {
	if m == nil {
		return nil
	}
	if i, ok := m.index[key]; ok {
		return m.entries[i].Data
	}
	return nil
}

func (m *BrawlerMap) Has(key string) bool {
	if m == nil {
		return false
	}
	_, ok := m.index[key]
	return ok
}

func (m *BrawlerMap) Set(key string, data *BrawlerData) {
	if m.index == nil {
		m.index = map[string]int{}
	}
	if i, ok := m.index[key]; ok {
		m.entries[i].Data = data
		return
	}
	m.index[key] = len(m.entries)
	m.entries = append(m.entries, BrawlerEntry{Key: key, Data: data})
}

func (m *BrawlerMap) Delete(key string) {
	if m == nil || m.index == nil {
		return
	}
	i, ok := m.index[key]
	if !ok {
		return
	}
	m.entries = append(m.entries[:i], m.entries[i+1:]...)
	delete(m.index, key)
	for j := i; j < len(m.entries); j++ {
		m.index[m.entries[j].Key] = j
	}
}

func (m *BrawlerMap) Range(fn func(key string, data *BrawlerData)) {
	if m == nil {
		return
	}
	for _, e := range m.entries {
		fn(e.Key, e.Data)
	}
}

func (m *BrawlerMap) Keys() []string {
	if m == nil {
		return nil
	}
	out := make([]string, len(m.entries))
	for i, e := range m.entries {
		out[i] = e.Key
	}
	return out
}

func (m BrawlerMap) MarshalJSON() ([]byte, error) {
	var buf bytes.Buffer
	buf.WriteByte('{')
	for i, e := range m.entries {
		if i > 0 {
			buf.WriteByte(',')
		}
		k, _ := json.Marshal(e.Key)
		buf.Write(k)
		buf.WriteByte(':')
		v, err := json.Marshal(e.Data)
		if err != nil {
			return nil, err
		}
		buf.Write(v)
	}
	buf.WriteByte('}')
	return buf.Bytes(), nil
}

func (m *BrawlerMap) UnmarshalJSON(data []byte) error {
	if m.index == nil {
		m.index = map[string]int{}
	}
	m.entries = nil
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	tok, err := dec.Token()
	if err != nil {
		return err
	}
	if d, ok := tok.(json.Delim); !ok || d != '{' {
		return fmt.Errorf("BrawlerMap: expected object")
	}
	for dec.More() {
		t, err := dec.Token()
		if err != nil {
			return err
		}
		key, _ := t.(string)
		var bd BrawlerData
		if err := dec.Decode(&bd); err != nil {
			return err
		}
		dp := &bd
		m.index[key] = len(m.entries)
		m.entries = append(m.entries, BrawlerEntry{Key: key, Data: dp})
	}
	return nil
}

func SortedNumericKeys(keys []string) []string {
	out := append([]string(nil), keys...)
	sort.Slice(out, func(i, j int) bool {
		return atoi(out[i]) < atoi(out[j])
	})
	return out
}

func atoi(s string) int {
	n := 0
	neg := false
	i := 0
	if len(s) > 0 && s[0] == '-' {
		neg, i = true, 1
	}
	for ; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			break
		}
		n = n*10 + int(s[i]-'0')
	}
	if neg {
		return -n
	}
	return n
}
