package config

import (
	"encoding/json"
	"fmt"
	"os"
	"sync"
)

type Settings struct {
	Gems                    int    `json:"Gems"`
	Gold                    int    `json:"Gold"`
	Tickets                 int    `json:"Tickets"`
	Starpoints              int    `json:"Starpoints,omitempty"`
	BrawlBoxTokens          int    `json:"BrawlBoxTokens"`
	BigBoxTokens            int    `json:"BigBoxTokens"`
	Trophies                int    `json:"Trophies"`
	ExperiencePoints        int    `json:"ExperiencePoints"`
	BrawlerTrophies         int    `json:"BrawlerTrophies"`
	BrawlerTrophiesForRank  int    `json:"BrawlerTrophiesForRank"`
	BrawlerPowerLevel       int    `json:"BrawlerPowerLevel"`
	BrawlerUpgradePoints    int    `json:"BrawlerUpgradePoints"`
	ThemeID                 int    `json:"ThemeID"`
	SupportedContentCreator string `json:"SupportedContentCreator,omitempty"`
	ShowPacketsInLog        bool   `json:"ShowPacketsInLog"`
	Maintenance             bool   `json:"Maintenance"`
	MaintenanceTime         int    `json:"MaintenanceTime,omitempty"`
	Patch                   bool   `json:"Patch"`
	PatchUrl                string `json:"PatchUrl"`
	UpdateUrl               string `json:"UpdateUrl"`

	UnlockedBrawlersOption string         `json:"UnlockedBrawlersOption"`
	UnlockedBrawler        map[string]int `json:"UnlockedBrawler"`
}

type Configuration struct {
	DisableNagle      bool     `json:"DisableNagle"`
	PrintEnabled      bool     `json:"PrintEnabled"`
	UseContentUpdater bool     `json:"UseContentUpdater"`
	Proxy             bool     `json:"Proxy"`
	DumpPacket        bool     `json:"DumpPacket"`
	Blacklist         []string `json:"Blacklist"`
	DumpMajor         int      `json:"DumpMajor"`
}

var (
	path     = "config.json"
	once     sync.Once
	settings Settings
	cfgErr   error
)

func defaultSettings() Settings {
	return Settings{
		Gems:                   99999,
		Gold:                   99999,
		Tickets:                99999,
		Starpoints:             99999,
		BrawlBoxTokens:         9900,
		BigBoxTokens:           9990,
		Trophies:               0,
		ExperiencePoints:       99999,
		BrawlerTrophies:        0,
		BrawlerTrophiesForRank: 0,
		BrawlerPowerLevel:      8,
		BrawlerUpgradePoints:   0,
		ThemeID:                0,
		ShowPacketsInLog:       false,
		Maintenance:            false,
		MaintenanceTime:        3600,
		Patch:                  false,
		PatchUrl:               "http://192.168.0.103:8080/",
		UpdateUrl:              "https://github.com/PhoenixFire6879/Classic-Brawl",
		UnlockedBrawlersOption: "Off",
		UnlockedBrawler:        map[string]int{},
	}
}

func CreateConfig() error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	enc.SetIndent("", "  ")
	return enc.Encode(defaultSettings())
}

func load() {
	data, err := os.ReadFile(path)
	if err != nil {
		fmt.Println("Creating config.json...")
		if cerr := CreateConfig(); cerr != nil {
			cfgErr = cerr
			return
		}
		data, err = os.ReadFile(path)
		if err != nil {
			cfgErr = err
			return
		}
	}
	settings = defaultSettings()
	if err := json.Unmarshal(data, &settings); err != nil {
		cfgErr = err
		return
	}
}

func GetValue() Settings {
	once.Do(load)
	return settings
}

func LoadError() error {
	once.Do(load)
	return cfgErr
}

func SetPath(p string) {
	path = p
	once = sync.Once{}
}
