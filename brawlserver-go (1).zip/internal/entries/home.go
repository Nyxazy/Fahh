package entries

import (
	"fmt"
	"time"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/database"
	"brawlserver/internal/logic"
)

func EncodeEventSlots(w *bytestream.Writer, slot int) {
	w.WriteVInt(slot)
}

func EncodeEventData(w *bytestream.Writer, p *logic.Player, db *database.DataBase, index, state int) {
	eventData := db.LoadEvents(state)
	info := eventData["info"].(map[string]any)
	events := info["events"].(map[string]any)
	event := events[fmt.Sprintf("%d", index)].(map[string]any)

	w.WriteVInt(index + 1)
	w.WriteVInt(index + 1)
	w.WriteVInt(toInt(event["TimeStamp"]) - int(time.Now().Unix()))
	w.WriteVInt(toInt(event["TimeStamp"]) - int(time.Now().Unix()))
	w.WriteVInt(toInt(event["Tokens"]))
	w.WriteDataReference(15, toInt(event["ID"]))
	w.WriteVInt(2)
	w.WriteStringVal("HIIIIIIIIIIIIIIII!")
	w.WriteVInt(1)

	modifiers := []int{}
	if mod, ok := event["Modifier"].(map[string]any); ok {
		for k, rc := range mod {
			for i := 0; i < toInt(rc); i++ {
				modifiers = append(modifiers, atoi(k))
			}
		}
	} else if mod, ok := event["Modifier"].(map[string]int); ok {
		for k, rc := range mod {
			for i := 0; i < rc; i++ {
				modifiers = append(modifiers, atoi(k))
			}
		}
	}
	hasZero := false
	for _, m := range modifiers {
		if m == 0 {
			hasZero = true
			break
		}
	}
	if hasZero {
		modifiers = nil
	}
	w.WriteVInt(len(modifiers))
	for _, m := range modifiers {
		w.WriteVInt(m)
	}
	if index == 4 {
		p.LastChaosMap = toInt(event["ID"])
	}
	p.LastEventTimeStamp = int64(toInt(event["TimeStamp"]))
}

func EncodeConfData(w *bytestream.Writer, p *logic.Player, db *database.DataBase) {
	w.WriteVInt(int(time.Now().Unix()))
	w.WriteVInt(100)
	w.WriteVInt(15)
	for _, item := range logic.ShopBoxesList {
		w.WriteVInt(item.Cost)
		w.WriteVInt(item.Multiplier)
	}
	w.WriteVInt(logic.ShopTokenDoubler.Cost)
	w.WriteVInt(logic.ShopTokenDoubler.Amount)
	w.WriteVInt(69746974)
	w.WriteVInt(50)
	w.WriteVInt(999900)

	EncodeArrayVInt(w, []int{0, 30, 80, 170, 350, 0})

	w.WriteVInt(5)
	for slot := 1; slot <= 5; slot++ {
		EncodeEventSlots(w, slot)
	}

	eventData := db.LoadEvents(1)
	info := eventData["info"].(map[string]any)
	events := info["events"].(map[string]any)
	count := len(events)
	w.WriteVInt(count)
	for i := 0; i < count; i++ {
		EncodeEventData(w, p, db, i, 1)
	}
	w.WriteVInt(count)
	for i := 0; i < count; i++ {
		EncodeEventData(w, p, db, i, 1)
	}

	EncodeArrayVInt(w, []int{20, 35, 75, 140, 290, 480, 800, 1250})
	EncodeArrayVInt(w, []int{1, 2, 3, 4, 5, 10, 15, 20})
	EncodeArrayVInt(w, []int{10, 30, 80})
	EncodeArrayVInt(w, []int{6, 20, 60})
	EncodeArrayVInt(w, []int{20, 50, 140})
	EncodeArrayVInt(w, []int{150, 200, 1200})

	w.WriteVInt(0)
	w.WriteVInt(621)
	for _, x := range logic.MilestonesArray {
		w.WriteVInt(x)
	}

	w.WriteVInt(p.AvailableTokens)
	w.WriteVInt(20)
	w.WriteVInt(8640)
	w.WriteVInt(10)
	w.WriteVInt(5)
	w.WriteBoolean(true)
	w.WriteBoolean(true)
	w.WriteBoolean(true)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
}

func EncodeDailyData(w *bytestream.Writer, p *logic.Player, db *database.DataBase) {
	w.WriteVInt(int(time.Now().Unix()))
	w.WriteVInt(0)
	w.WriteVInt(p.Trophies)
	w.WriteVInt(p.HighestTrophies)
	w.WriteVInt(0)
	w.WriteVInt(p.TrophyRoad)
	w.WriteVInt(p.PlayerExperience)
	w.WriteDataReference(28, p.ProfileIcon)

	w.WriteVInt(9)
	for g := 0; g < 9; g++ {
		w.WriteVInt(g)
	}

	var selectedSkins []int
	p.UnlockedBrawlers.Range(func(_ string, b *logic.BrawlerData) {
		if b.SelectedSkin != 0 {
			selectedSkins = append(selectedSkins, b.SelectedSkin)
		}
	})
	w.WriteVInt(len(selectedSkins))
	for _, s := range selectedSkins {
		w.WriteDataReference(29, s)
	}

	var unlockedSkins []int
	p.UnlockedBrawlers.Range(func(_ string, b *logic.BrawlerData) {
		for _, s := range b.Skins {
			if s != 0 {
				unlockedSkins = append(unlockedSkins, s)
			}
		}
	})
	w.WriteVInt(len(unlockedSkins))
	for _, s := range unlockedSkins {
		w.WriteDataReference(29, s)
	}

	w.WriteBoolean(false)
	w.WriteVInt(0)
	w.WriteVInt(p.KeyReward)
	w.WriteVInt(p.TrophyReward)
	w.WriteVInt(p.StarKeyReward)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteBoolean(false)
	w.WriteVInt(0)
	w.WriteBoolean(true)
	w.WriteVInt(p.TokensDoubler)
	w.WriteVInt(734974)
	w.WriteUInt8(8)
	w.WriteVInt(0)
	w.WriteBoolean(false)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(30)
	w.WriteVInt(0)

	offers := db.LoadOffers(p.Token)
	if offers == nil || len(offers) == 0 {
		db.InitializePlayerOffers(p.Token)
		offers = db.LoadOffers(p.Token)
	}
	info, _ := offers["info"].(map[string]any)
	w.WriteBoolean(false)
	if info != nil {
		w.WriteVInt(len(info))
		for _, k := range sortedNumericKeys(info) {
			item, _ := info[k].(map[string]any)
			if item != nil {
				EncodeOfferBundle(w, item)
			}
		}
	} else {
		w.WriteVInt(0)
	}

	w.WriteVInt(1)
	w.WriteVInt(0)
	w.WriteVInt(1)
	w.WriteVInt(10)
	w.WriteVInt(9999999)
	w.WriteVInt(-64)
	w.WriteVInt(0)
	w.WriteVInt(p.Tickets)
	w.WriteVInt(0)
}

func EncodeClientHome(w *bytestream.Writer, p *logic.Player, db *database.DataBase) {
	EncodeDailyData(w, p, db)
	EncodeConfData(w, p, db)
	w.WriteLong(0, p.LowID)
	w.WriteVInt(0)
	w.WriteVInt(0)
}

func EncodeClientAvatar(w *bytestream.Writer, p *logic.Player) {
	w.WriteVInt(p.HighID)
	w.WriteVInt(p.LowID)
	w.WriteVInt(p.HighID)
	w.WriteVInt(p.LowID)
	w.WriteVInt(p.HighID)
	w.WriteVInt(p.LowID)
	w.WriteStringVal(p.Name)
	w.WriteBoolean(p.Name != "Brawler")
	w.WriteString(nil)
	w.WriteVInt(8)

	w.WriteVInt(p.UnlockedBrawlers.Len() + 3)
	p.UnlockedBrawlers.Range(func(_ string, b *logic.BrawlerData) {
		w.WriteVInt(23)
		w.WriteVInt(b.CardID)
		w.WriteVInt(1)
	})
	w.WriteVInt(5)
	w.WriteVInt(1)
	w.WriteVInt(p.BrawlBoxes)
	w.WriteVInt(5)
	w.WriteVInt(8)
	w.WriteVInt(p.Gold)
	w.WriteVInt(5)
	w.WriteVInt(9)
	w.WriteVInt(p.BigBoxes)

	w.WriteVInt(p.UnlockedBrawlers.Len())
	p.UnlockedBrawlers.Range(func(key string, b *logic.BrawlerData) {
		w.WriteDataReference(16, atoi(key))
		w.WriteVInt(b.Trophies)
	})

	w.WriteVInt(p.UnlockedBrawlers.Len())
	p.UnlockedBrawlers.Range(func(key string, b *logic.BrawlerData) {
		w.WriteDataReference(16, atoi(key))
		w.WriteVInt(b.HighestTrophies)
	})

	w.WriteVInt(0)

	w.WriteVInt(p.UnlockedBrawlers.Len())
	p.UnlockedBrawlers.Range(func(key string, b *logic.BrawlerData) {
		w.WriteDataReference(16, atoi(key))
		w.WriteVInt(b.PowerPoints)
	})

	w.WriteVInt(p.UnlockedBrawlers.Len())
	p.UnlockedBrawlers.Range(func(key string, b *logic.BrawlerData) {
		w.WriteDataReference(16, atoi(key))
		w.WriteVInt(b.PowerLevel)
	})

	w.WriteVInt(p.UnlockedBrawlers.Len())
	p.UnlockedBrawlers.Range(func(key string, b *logic.BrawlerData) {
		w.WriteDataReference(16, atoi(key))
		if b.StarPower != 0 {
			w.WriteVInt(1)
		} else {
			w.WriteVInt(0)
		}
	})

	w.WriteVInt(p.UnlockedBrawlers.Len())
	p.UnlockedBrawlers.Range(func(key string, b *logic.BrawlerData) {
		w.WriteDataReference(16, atoi(key))
		w.WriteVInt(0)
	})

	w.WriteVInt(p.Gems)
	w.WriteVInt(p.Gems)
	w.WriteVInt(p.PlayerExperience)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(p.TutorialState)
}
