package entries

import (
	"time"

	"brawlserver/internal/bytestream"
)

func EncodeArrayVInt(w *bytestream.Writer, list []int) {
	w.WriteVInt(len(list))
	for _, e := range list {
		w.WriteVInt(e)
	}
}

func offerInt(item map[string]any, key string) int {
	if v, ok := item[key]; ok {
		return toInt(v)
	}
	return 0
}

func offerTarget(item map[string]any) (int, int) {
	t, ok := item["Target"]
	if !ok {
		return 0, 0
	}
	switch tt := t.(type) {
	case []any:
		if len(tt) >= 2 {
			return toInt(tt[0]), toInt(tt[1])
		}
	case [2]int:
		return tt[0], tt[1]
	}
	return 0, 0
}

func EncodeGemOffer(w *bytestream.Writer, item map[string]any) {
	w.WriteVInt(offerInt(item, "OfferID"))
	w.WriteVInt(offerInt(item, "Amount"))
	high, low := offerTarget(item)
	w.WriteDataReference(high, low)
	w.WriteVInt(offerInt(item, "Value"))
}

func EncodeOfferBundle(w *bytestream.Writer, item map[string]any) {
	w.WriteVInt(1)
	EncodeGemOffer(w, item)
	w.WriteVInt(offerInt(item, "Currency"))
	w.WriteVInt(offerInt(item, "Price"))
	w.WriteVInt(offerInt(item, "Timer") - int(time.Now().Unix()))
	w.WriteVInt(offerInt(item, "IsOfferSeen"))
	w.WriteVInt(115)
	w.WriteUInt8(offerInt(item, "IsOfferPurchased"))
}
