package entries

func toInt(v any) int {
	switch t := v.(type) {
	case int:
		return t
	case int64:
		return int(t)
	case float64:
		return int(t)
	case string:
		n := 0
		neg := false
		i := 0
		if len(t) > 0 && t[0] == '-' {
			neg, i = true, 1
		}
		for ; i < len(t); i++ {
			if t[i] < '0' || t[i] > '9' {
				break
			}
			n = n*10 + int(t[i]-'0')
		}
		if neg {
			return -n
		}
		return n
	case bool:
		if t {
			return 1
		}
		return 0
	}
	return 0
}

func toStr(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

func sortedNumericKeys(m map[string]any) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	return sortNumeric(keys)
}

func sortNumeric(keys []string) []string {
	out := append([]string(nil), keys...)
	for i := 1; i < len(out); i++ {
		for j := i; j > 0 && atoi(out[j-1]) > atoi(out[j]); j-- {
			out[j-1], out[j] = out[j], out[j-1]
		}
	}
	return out
}

func atoi(s string) int {
	n := 0
	neg := false
	i := 0
	if len(s) > 0 && s[0] == '-' {
		neg, i = true, 1
	}
	for ; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			break
		}
		n = n*10 + int(s[i]-'0')
	}
	if neg {
		return -n
	}
	return n
}
