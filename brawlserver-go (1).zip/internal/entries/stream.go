package entries

import (
	"time"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/database"
	"brawlserver/internal/logic"
)

func playerNameByLowID(db *database.DataBase, lowID int) string {
	token := db.GetTokenByLowId(lowID)
	if token == "" {
		return ""
	}
	players := db.GetSpecifiedPlayers([]string{token})
	if len(players) == 0 {
		return ""
	}
	return toStr(players[0]["name"])
}

func EncodeStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	w.WriteLogicLong(0, toInt(info["Tick"]))
	w.WriteLogicLong(0, toInt(info["PlayerID"]))
	w.WriteStringVal(playerNameByLowID(db, toInt(info["PlayerID"])))
	role, ok := info["PlayerRole"]
	if ok {
		w.WriteVInt(toInt(role))
	} else {
		w.WriteVInt(0)
	}
	w.WriteVInt(int(time.Now().Unix()) - toInt(info["TimeStamp"]))
	w.WriteBoolean(false)
}

func EncodeChatStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	EncodeStreamEntry(w, p, db, info)
	w.WriteStringVal(toStr(info["Message"]))
}

func EncodeJoinRequestStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	EncodeStreamEntry(w, p, db, info)
	w.WriteStringVal(toStr(info["Message"]))
	w.WriteStringVal(toStr(info["PlayerName"]))
	w.WriteVInt(toInt(info["Event"]))
	w.WriteVInt(0)
	w.WriteDataReference(28, profileIconForPlayer(db, toInt(info["PlayerID"])))
}

func profileIconForPlayer(db *database.DataBase, lowID int) int {
	token := db.GetTokenByLowId(lowID)
	if token == "" {
		return 0
	}
	players := db.GetSpecifiedPlayers([]string{token})
	if len(players) == 0 {
		return 0
	}
	return toInt(players[0]["profile_icon"])
}

func EncodeAllianceEventStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	EncodeStreamEntry(w, p, db, info)
	w.WriteVInt(toInt(info["Event"]))
	w.WriteBoolean(true)
	w.WriteLogicLong(0, toInt(info["targetID"]))
	w.WriteStringVal(playerNameByLowID(db, toInt(info["targetID"])))
}

func EncodeReplayStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	EncodeStreamEntry(w, p, db, info)
	w.WriteVInt(0)
	w.WriteLong(0, 1)
	w.WriteBoolean(false)
	w.WriteStringVal("String1")
	w.WriteStringVal("String2")
	w.WriteStringVal("String3")
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
}

func EncodeQuickChatStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	EncodeStreamEntry(w, p, db, info)
	w.WriteDataReference(40, toInt(info["MessageDataID"]))
	w.WriteBoolean(false)
	w.WriteString(nil)
	w.WriteVInt(0)
	w.WriteVInt(toInt(info["PremadeID"]))
}

func EncodeTeamCreatedStreamEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, info map[string]any) {
	EncodeStreamEntry(w, p, db, info)
	w.WriteLong(0, toInt(info["promotedTeam"]))
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(0)
}

func EncodeStreamEntryByType(w *bytestream.Writer, p *logic.Player, db *database.DataBase, message map[string]any) {
	v1 := toInt(message["EventType"])
	switch v1 {
	case 2:
		EncodeChatStreamEntry(w, p, db, message)
	case 3:
		EncodeJoinRequestStreamEntry(w, p, db, message)
	case 4:
		EncodeAllianceEventStreamEntry(w, p, db, message)
	case 5:
		EncodeReplayStreamEntry(w, p, db, message)
	case 8:
		EncodeQuickChatStreamEntry(w, p, db, message)
	case 77:
		EncodeTeamCreatedStreamEntry(w, p, db, message)
	}
}
