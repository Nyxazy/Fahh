package entries

import (
	"time"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/database"
	"brawlserver/internal/logic"
)

func EncodePlayerDisplayData(w *bytestream.Writer, player map[string]any) {
	w.WriteStringVal("primoDEV")
	w.WriteInt(100)
	w.WriteInt(28000000)
}

func EncodeFriendEntry(w *bytestream.Writer, p *logic.Player, db *database.DataBase, player map[string]any) {
	playerToken := db.GetTokenByLowId(toInt(player["low_id"]))
	w.WriteLong(0, toInt(player["low_id"]))
	w.WriteStringVal(toStr(player["name"]))
	w.WriteStringVal("ho")
	w.WriteString(nil)
	w.WriteString(nil)

	friendState := 0
	if _, ok := p.Friends[playerToken]; ok {
		friendState = p.Friends[playerToken]
	}
	w.WriteInt(friendState)
	w.WriteInt(toInt(player["trophies"]))
	w.WriteInt(0)
	w.WriteInt(0)
	w.WriteInt(0)
	w.WriteInt(0)

	w.WriteBoolean(toInt(player["club_id"]) != 0)
	if toInt(player["club_id"]) != 0 {
		club := db.LoadClub(toInt(player["club_id"]))
		if club != nil {
			info := club["info"].(map[string]any)
			w.WriteInt(0)
			w.WriteInt(0)
			w.WriteInt(0)
			w.WriteStringVal(toStr(info["name"]))
			w.WriteInt(0)
			w.WriteInt(0)
		}
	}
	w.WriteStringVal("you")
	w.WriteInt(28000000 + toInt(player["profile_icon"]))
	w.WriteInt(20000)
}

func EncodeFriendOnlineStatusEntry(w *bytestream.Writer, lowID int, playerData map[string]any) {
	w.WriteLong(0, lowID)
	currentTime := int(time.Now().Unix())
	w.WriteVInt(toInt(playerData["player_status"]))
	if currentTime-toInt(playerData["last_connection_time"]) < 3600 {
		w.WriteVInt(0)
	} else {
		w.WriteVInt(currentTime - toInt(playerData["last_connection_time"]))
	}
	w.WriteBoolean(false)
	w.WriteBoolean(false)
}

func EncodeAllianceTeamEntry(w *bytestream.Writer) {
	w.WriteVInt(1)
	w.WriteBoolean(true)
	w.WriteVInt(1)
	w.WriteVInt(2)
	w.WriteLong(0, 1)
	w.WriteVInt(1)
	w.WriteVInt(2)
	w.WriteDataReference(15, 2)
	w.WriteVInt(0)
	w.WriteStringVal("hi")
	w.WriteLong(0, 1)
	w.WriteLong(0, 1)
	w.WriteBoolean(true)
	w.WriteBoolean(true)
	w.WriteVInt(1)
	for x := 0; x < 1; x++ {
		w.WriteLong(0, 1)
	}
}

func EncodeBattleLogPlayerEntry(w *bytestream.Writer, player int) {
	w.WriteVInt(69)
	w.WriteLong(0, player+1)
	w.WriteVInt(5)
	w.WriteBoolean(true)
	w.WriteStringVal("Primo invasion :demon:")
	w.WriteDataReference(16, player)
	w.WriteVInt(669)
	w.WriteVInt(1)
	w.WriteVInt(2)
}

func EncodeBattleLogEntry(w *bytestream.Writer, battle int) {
	w.WriteVInt(0)
	w.WriteVInt(6)
	w.WriteVInt(1)
	w.WriteVInt(69)
	w.WriteVInt(6974)
	w.WriteBoolean(true)
	w.WriteDataReference(15, 0)
	w.WriteVInt(1)
	w.WriteVInt(1)
	w.WriteInt(1)
	w.WriteInt(1)
	w.WriteVInt(1)
	for player := 0; player < 1; player++ {
		EncodeBattleLogPlayerEntry(w, player)
	}
}

func EncodeLogicCommand(w *bytestream.Writer) {
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteLogicLong(0, 0)
}

func EncodeLogicServerCommand(w *bytestream.Writer) {
	w.WriteVInt(0)
	EncodeLogicCommand(w)
}
