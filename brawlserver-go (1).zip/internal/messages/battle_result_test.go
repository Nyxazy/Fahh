package messages

import (
	"os"
	"testing"

	"brawlserver/internal/battle"
	"brawlserver/internal/bytestream"
	"brawlserver/internal/database"
	"brawlserver/internal/logic"
	"brawlserver/internal/packets"
)

func TestBattleResultByteIdentical(t *testing.T) {
	pyHex, err := os.ReadFile("/tmp/py_battle.txt")
	if err != nil {
		t.Skip("run pyserver/battle_ref.py first")
	}
	py := string(pyHex)
	for i := 0; i < len(py); i++ {
		c := py[i]
		if c == '\n' || c == '\r' || c == ' ' {
			py = py[:i] + py[i+1:]
			i--
		}
	}

	p := logic.NewPlayer()
	p.Token = "TESTTOKEN123"
	p.TutorialState = 2
	p.PlayerExperience = 500
	p.Trophies = 200
	p.HighestTrophies = 250
	p.TokensDoubler = 30
	p.Name = "Tester"
	p.LowID = 1
	p.UnlockedBrawlers = logic.NewBrawlerMap()
	p.UnlockedBrawlers.Set("0", &logic.BrawlerData{
		CardID: 0, Skins: []int{0}, SelectedSkin: 0,
		Trophies: 100, HighestTrophies: 100,
		PowerLevel: 5, PowerPoints: 50, State: 2, StarPower: 0,
	})

	fields := &battle.BattleFields{
		GameMode: 1, Victory: 0, Rank: 1, IsInRealGame: true,
		HeroesCount: 1,
		Heroes: []battle.Hero{{
			Name: "Tester", IsPlayer: true, Team: 0, LowID: 0,
			ID: [2]int{16, 0}, SkinID: [2]int{0, 0}, Trophies: 100, PowerLevel: 6,
		}},
	}

	db, err := database.New(p)
	if err != nil {
		t.Fatal(err)
	}
	ctx := &packets.Context{Player: p, DB: db}
	w := bytestream.NewWriter(nil, 23456, 0)
	EncodeBattleResult(w, ctx, fields)
	goHex := hexStr(w.Buffer)

	if goHex != py {
		t.Fatalf("MISMATCH\n go len=%d py len=%d\n go[:120]=%s\n py[:120]=%s", len(goHex)/2, len(py)/2, goHex[:120], py[:120])
	}
	t.Logf("BattleResultMessage BYTE-IDENTICAL: %d bytes match Python exactly", len(goHex)/2)
}

func hexStr(b []byte) string {
	const h = "0123456789abcdef"
	out := make([]byte, len(b)*2)
	for i, v := range b {
		out[i*2] = h[v>>4]
		out[i*2+1] = h[v&0xf]
	}
	return string(out)
}
