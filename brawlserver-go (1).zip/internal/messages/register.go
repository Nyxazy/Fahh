package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/packets"
)

var registered bool

func bs(payload []byte) *bytestream.ByteStream { return bytestream.NewByteStream(payload) }

func RegisterAll() {
	if registered {
		return
	}
	registered = true

	packets.Register(10100, func(ctx *packets.Context, payload []byte) packets.ClientMessage {
		return &ClientHelloMessage{bs: bs(payload), serverStates: ctx.States}
	})
	packets.Register(10101, func(_ *packets.Context, p []byte) packets.ClientMessage { return &LoginMessage{bs: bs(p)} })
	packets.Register(10107, func(_ *packets.Context, p []byte) packets.ClientMessage { return &ClientCapabilities{bs: bs(p)} })
	packets.Register(10108, func(_ *packets.Context, p []byte) packets.ClientMessage { return &KeepAliveMessage{bs: bs(p)} })
	packets.Register(10110, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AnalyticsEvent{bs: bs(p)} })
	packets.Register(10113, func(_ *packets.Context, p []byte) packets.ClientMessage { return &SetDeviceToken{bs: bs(p)} })
	packets.Register(10212, func(_ *packets.Context, p []byte) packets.ClientMessage { return &ChangeAvatarName{bs: bs(p)} })

	packets.Register(10502, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AddFriend{bs: bs(p)} })
	packets.Register(10504, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AskForFriendList{bs: bs(p)} })
	packets.Register(10599, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AskForFriendSuggestions{bs: bs(p)} })
	packets.Register(14201, func(_ *packets.Context, p []byte) packets.ClientMessage { return &FacebookConnect{bs: bs(p)} })
	packets.Register(14211, func(_ *packets.Context, p []byte) packets.ClientMessage { return &UnlinkFacebook{bs: bs(p)} })

	packets.Register(14102, func(_ *packets.Context, p []byte) packets.ClientMessage { return &EndClientTurn{bs: bs(p)} })
	packets.Register(14103, func(_ *packets.Context, p []byte) packets.ClientMessage { return &OnPlay{bs: bs(p)} })
	packets.Register(14106, func(_ *packets.Context, p []byte) packets.ClientMessage { return &CancelMatchMaking{bs: bs(p)} })
	packets.Register(14109, func(_ *packets.Context, p []byte) packets.ClientMessage { return &GoHome{bs: bs(p)} })
	packets.Register(14110, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AskForBattleEnd{bs: bs(p)} })
	packets.Register(14113, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AskProfile{bs: bs(p)} })
	packets.Register(14114, func(_ *packets.Context, p []byte) packets.ClientMessage { return &HomeBattleReplay{bs: bs(p)} })
	packets.Register(14177, func(_ *packets.Context, p []byte) packets.ClientMessage { return &PlayAgain{bs: bs(p)} })

	packets.Register(14301, func(_ *packets.Context, p []byte) packets.ClientMessage { return &CreateMessage{bs: bs(p)} })
	packets.Register(14302, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AskForAllianceData{bs: bs(p)} })
	packets.Register(14303, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AskJoinableAlliances{bs: bs(p)} })
	packets.Register(14305, func(_ *packets.Context, p []byte) packets.ClientMessage { return &JoinMessage{bs: bs(p)} })
	packets.Register(14306, func(_ *packets.Context, p []byte) packets.ClientMessage { return &PromoteMember{bs: bs(p)} })
	packets.Register(14307, func(_ *packets.Context, p []byte) packets.ClientMessage { return &KickAllianceMember{bs: bs(p)} })
	packets.Register(14308, func(_ *packets.Context, p []byte) packets.ClientMessage { return &LeaveMessage{bs: bs(p)} })
	packets.Register(14315, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AllianceChat{bs: bs(p)} })
	packets.Register(14316, func(_ *packets.Context, p []byte) packets.ClientMessage { return &EditSettingsMessage{bs: bs(p)} })
	packets.Register(14317, func(_ *packets.Context, p []byte) packets.ClientMessage { return &RequestJoinAlliance{bs: bs(p)} })
	packets.Register(14321, func(_ *packets.Context, p []byte) packets.ClientMessage { return &RespondJoinRequest{bs: bs(p)} })
	packets.Register(14324, func(_ *packets.Context, p []byte) packets.ClientMessage { return &SearchMessage{bs: bs(p)} })
	packets.Register(14330, func(_ *packets.Context, p []byte) packets.ClientMessage { return &SendClubMail{bs: bs(p)} })

	packets.Register(14350, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamCreate{bs: bs(p)} })
	packets.Register(14352, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamKick{bs: bs(p)} })
	packets.Register(14353, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamLeave{bs: bs(p)} })
	packets.Register(14354, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamChangeMemberSettings{bs: bs(p)} })
	packets.Register(14355, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamSetReady{bs: bs(p)} })
	packets.Register(14358, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamSpectate{bs: bs(p)} })
	packets.Register(14359, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamChat{bs: bs(p)} })
	packets.Register(14360, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamPostAd{bs: bs(p)} })
	packets.Register(14361, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamMemberStatus{bs: bs(p)} })
	packets.Register(14362, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamSetRankedLocation{bs: bs(p)} })
	packets.Register(14363, func(_ *packets.Context, p []byte) packets.ClientMessage { return &TeamSetLocation{bs: bs(p)} })
	packets.Register(14366, func(_ *packets.Context, p []byte) packets.ClientMessage { return &PlayerStatus{bs: bs(p)} })

	packets.Register(14403, func(_ *packets.Context, p []byte) packets.ClientMessage { return &GetLeaderboard{bs: bs(p)} })
	packets.Register(14600, func(_ *packets.Context, p []byte) packets.ClientMessage { return &AvatarNameCheckRequest{bs: bs(p)} })
}
