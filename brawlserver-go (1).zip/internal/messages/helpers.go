package messages

import (
	"strconv"

	"brawlserver/internal/csvlogic"
)

func asInt(v any) int {
	switch t := v.(type) {
	case int:
		return t
	case int64:
		return int(t)
	case float64:
		return int(t)
	case string:
		n, _ := strconv.Atoi(t)
		return n
	case bool:
		if t {
			return 1
		}
		return 0
	}
	return 0
}

func asBool(v any) bool {
	switch t := v.(type) {
	case bool:
		return t
	case int:
		return t != 0
	case float64:
		return t != 0
	}
	return false
}

func asString(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

func itoa(i int) string { return strconv.Itoa(i) }

func logicGameModeString(location int) string {
	return csvlogic.GetGameModeString(location)
}

type jsonNumber = float64
