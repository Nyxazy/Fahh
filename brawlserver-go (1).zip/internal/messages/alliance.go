package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/entries"
	"brawlserver/internal/jsonutil"
	"brawlserver/internal/packets"

	"brawlserver/internal/logic"
)

func SendMyAlliance(ctx *packets.Context, clubLowID int) error {
	return packets.SendServerPlain(ctx, 24399, func(w *bytestream.Writer) {
		if clubLowID == 0 {
			w.WriteVInt(0)
			w.WriteVInt(0)
			return
		}
		db, _ := ctx.EnsureDB()
		clubInfo := db.LoadClub(clubLowID)
		if clubInfo == nil {
			w.WriteVInt(0)
			w.WriteVInt(0)
			return
		}
		info := clubInfo["info"].(map[string]any)
		memberCount := info["memberCount"].([]any)
		w.WriteVInt(len(memberCount))
		w.WriteVInt(1)
		w.WriteVInt(25)
		w.WriteVInt(ctx.Player.ClubRole)
		w.WriteInt(0)
		w.WriteInt(clubLowID)
		w.WriteStringVal(asString(info["name"]))
		w.WriteVInt(8)
		w.WriteVInt(asInt(info["clubBadge"]))
		w.WriteVInt(asInt(info["clubType"]))
		w.WriteVInt(len(memberCount))
		w.WriteVInt(asInt(info["trophies"]))
		w.WriteVInt(asInt(info["requiredTrophies"]))
		w.WriteVInt(0)
		w.WriteStringVal(asString(info["region"]))
		w.WriteVInt(asInt(info["onlineMembers"]))
	})
}

func SendAllianceStream(ctx *packets.Context, clubLowID int, eventType int) error {
	return packets.SendServerPlain(ctx, 24311, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		if clubLowID == 0 {
			w.WriteVInt(0)
			return
		}
		clubMessages := db.LoadClubMessages(clubLowID)
		msgCount := 0
		var messages map[string]any
		if clubMessages != nil {
			if info, ok := clubMessages["info"].(map[string]any); ok {
				if mm, ok := info["messages"].(map[string]any); ok {
					messages = mm
					msgCount = len(mm)
				}
			}
		}
		w.WriteVInt(msgCount)
		for index := 0; index < msgCount; index++ {
			message, _ := messages[itoa(index)].(map[string]any)
			if message == nil {
				continue
			}
			w.WriteVInt(asInt(message["EventType"]))
			entries.EncodeStreamEntryByType(w, ctx.Player, db, message)
		}
	})
}

func SendAllianceTeams(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24364, func(w *bytestream.Writer) {
		w.WriteBoolean(true)
		w.WriteVInt(2)
		for x := 0; x < 2; x++ {
			entries.EncodeAllianceTeamEntry(w)
		}
	})
}

func SendTeamGameroomData(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24124, func(w *bytestream.Writer) {
		p := ctx.Player
		db, _ := ctx.EnsureDB()
		infoAny := db.GetGameroomInfo("info")
		info, ok := infoAny.(map[string]any)
		if !ok {
			return
		}
		playersObj := info["players"].(map[string]any)
		playerKeys := jsonutil.OrderedKeysAtPath(db.LoadGameroomRaw(p.RoomID), "info", "players")

		w.WriteVInt(asInt(info["room_type"]))
		w.WriteBoolean(asInt(info["room_type"]) == 1)
		gameModeVariation := getGameModeVariation(asInt(info["map_id"]))
		w.WriteVInt(logic.GetPlayerCountWithGameMode(gameModeVariation))
		w.WriteLong(0, p.RoomID)
		w.WriteVInt(0)
		w.WriteBoolean(asBool(info["advertiseToBand"]))
		w.WriteBoolean(asBool(info["advertiseToFriends"]))
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteDataReference(15, asInt(info["map_id"]))
		playerCount := asInt(info["player_count"])
		w.WriteVInt(playerCount)

		if playerKeys == nil {
			playerKeys = make([]string, 0, len(playersObj))
			for k := range playersObj {
				playerKeys = append(playerKeys, k)
			}
		}
		for _, key := range playerKeys {
			player, _ := playersObj[key].(map[string]any)
			if player == nil {
				continue
			}
			lowID := asInt(player["low_id"])
			playerToken := db.GetTokenByLowId(lowID)
			var playersData map[string]any
			if playerToken != "" {
				ps := db.GetSpecifiedPlayers([]string{playerToken})
				if len(ps) > 0 {
					playersData = ps[0]
				}
			}
			w.WriteBoolean(asBool(player["host"]))
			w.WriteLong(0, lowID)
			w.WriteStringVal(asString(player["name"]))
			friendState := 0
			if v, ok := p.Friends[playerToken]; ok {
				friendState = v
			}
			w.WriteVInt(friendState)
			w.WriteDataReference(16, asInt(player["brawler_id"]))
			w.WriteDataReference(0, 1)
			brawlerID := itoa(asInt(player["brawler_id"]))
			var ub map[string]any
			if playersData != nil {
				if u, ok := playersData["unlocked_brawlers"].(map[string]any); ok {
					ub = u
				}
			}
			var bd map[string]any
			if ub != nil {
				bd, _ = ub[brawlerID].(map[string]any)
			}
			if bd != nil {
				w.WriteVInt(asInt(bd["Trophies"]))
				w.WriteVInt(asInt(bd["HighestTrophies"]))
				w.WriteVInt(asInt(bd["PowerLevel"]))
			} else {
				w.WriteVInt(0)
				w.WriteVInt(0)
				w.WriteVInt(0)
			}
			status := asInt(player["status"])
			if playersData != nil && asInt(playersData["player_status"]) == 0 {
				status = 0
			}
			w.WriteVInt(status)
			w.WriteBoolean(asBool(player["ready"]))
			w.WriteVInt(asInt(player["team"]))
		}
		w.WriteVInt(0)
	})
}

func getGameModeVariation(location int) int {
	variationString := logicGameModeString(location)
	switch variationString {
	case "CoinRush":
		return 0
	case "AttackDefend":
		return 2
	case "BossFight":
		return 7
	case "BountyHunter":
		return 3
	case "Artifact":
		return 4
	case "LaserBall":
		return 5
	case "BattleRoyale":
		return 6
	case "BattleRoyaleTeam":
		return 9
	case "Survival":
		return 8
	}
	return -1
}
