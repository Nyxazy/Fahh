package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/entries"
	"brawlserver/internal/packets"
)

func SendTeamStream(ctx *packets.Context, roomLowID int) error {
	return packets.SendServerPlain(ctx, 24131, func(w *bytestream.Writer) {
		w.WriteLogicLong(0, ctx.Player.RoomID)
		db, _ := ctx.EnsureDB()
		if roomLowID == 0 {
			w.WriteVInt(0)
			return
		}
		roomMessages := db.LoadRoomMessages(roomLowID)
		msgCount := 0
		var messages map[string]any
		if roomMessages != nil {
			if info, ok := roomMessages["info"].(map[string]any); ok {
				if mm, ok := info["messages"].(map[string]any); ok {
					messages = mm
					msgCount = len(mm)
				}
			}
		}
		w.WriteVInt(msgCount)
		for index := 0; index < msgCount; index++ {
			message, _ := messages[itoa(index)].(map[string]any)
			if message == nil {
				continue
			}
			w.WriteVInt(asInt(message["EventType"]))
			entries.EncodeStreamEntryByType(w, ctx.Player, db, message)
		}
	})
}
