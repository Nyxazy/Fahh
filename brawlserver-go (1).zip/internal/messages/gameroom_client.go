package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/logic"
	"brawlserver/internal/packets"
)

type TeamCreate struct {
	bs       *bytestream.ByteStream
	mapID    int
	roomType int
}

func (m *TeamCreate) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	m.mapID = m.bs.ReadVInt()
	m.roomType = m.bs.ReadVInt()
	m.bs.ReadVInt()
	return nil
}

func (m *TeamCreate) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.RoomID != 0 {
		return nil
	}
	db, _ := ctx.EnsureDB()
	db.GetRoomId()
	db.ReplaceValue("room_id", p.RoomID)
	if m.mapID > 100 {
		p.MapID = 0
	} else {
		p.MapID = m.mapID
	}
	chatData := map[string]any{
		"info": map[string]any{
			"roomID": p.RoomID,
			"messages": map[string]any{
				"0": map[string]any{
					"EventType": 4, "Event": 101, "Tick": 1, "PlayerID": p.LowID,
					"PlayerName": p.Name, "PlayerRole": 0, "Message": "",
					"promotedTeam": 0, "TimeStamp": float64(nowUnix()),
					"targetID": p.LowID, "targetName": p.Name,
				},
			},
		},
	}
	db.CreateGameroom(m.roomType, chatData)
	return SendTeamGameroomData(ctx)
}

type TeamLeave struct{ bs *bytestream.ByteStream }

func (m *TeamLeave) Decode(ctx *packets.Context) error { return nil }

func (m *TeamLeave) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.RoomID == 0 {
		return nil
	}
	SendTeamLeft(ctx)
	db, _ := ctx.EnsureDB()
	db.RemoveGameroomPlayer(p.LowID, p.RoomID, p.Token)
	db.AddGameroomMsg(p.RoomID, 4, p.LowID, p.Name, "", 103, p.LowID, p.Name)
	p.RoomID = 0
	return nil
}

type TeamKick struct {
	bs       *bytestream.ByteStream
	playerID [2]int
}

func (m *TeamKick) Decode(ctx *packets.Context) error {
	m.playerID = m.bs.ReadVLong()
	return nil
}

func (m *TeamKick) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	infoAny := db.GetGameroomInfo("info")
	info, ok := infoAny.(map[string]any)
	if !ok {
		return nil
	}
	players := info["players"].(map[string]any)
	me, ok := players[itoa(p.LowID)].(map[string]any)
	if !ok || !asBool(me["host"]) {
		return nil
	}
	playerToken := db.GetTokenByLowId(m.playerID[1])
	db.RemoveGameroomPlayer(m.playerID[1], p.RoomID, playerToken)
	db.AddGameroomMsg(p.RoomID, 4, p.LowID, p.Name, "", 104, m.playerID[1], p.Name)
	db.ReplaceOtherValue("room_id", 0, playerToken)
	return nil
}

type TeamSetLocation struct {
	bs       *bytestream.ByteStream
	roomType int
}

func (m *TeamSetLocation) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	ctx.Player.MapID = m.bs.ReadVInt()
	m.roomType = 1
	return nil
}

func (m *TeamSetLocation) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	if !intInSlice(p.MapID, logic.AllLocationsList()) {
		return nil
	}
	db.UpdateGameroomInfo(p.MapID, p.RoomID, "map_id")
	db.UpdateGameroomInfo(m.roomType, p.RoomID, "room_type")
	return SendTeamGameroomData(ctx)
}

type TeamSetRankedLocation struct{ bs *bytestream.ByteStream }

func (m *TeamSetRankedLocation) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	slot := m.bs.ReadVInt()
	if slot >= 1 && slot <= len(logic.EventSlotsMaps) {
		ctx.Player.MapID = logic.EventSlotsMaps[slot-1].ID
	}
	return nil
}

func (m *TeamSetRankedLocation) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	db.UpdateGameroomInfo(p.MapID, p.RoomID, "map_id")
	db.UpdateGameroomInfo(0, p.RoomID, "room_type")
	return SendTeamGameroomData(ctx)
}

type TeamChangeMemberSettings struct {
	bs        *bytestream.ByteStream
	csvTarget int
}

func (m *TeamChangeMemberSettings) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	m.bs.ReadVInt()
	m.csvTarget = m.bs.ReadVInt()
	return nil
}

func (m *TeamChangeMemberSettings) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	playerInfo := db.GetPlayerInfo(p.LowID)
	if playerInfo != nil {
		playerInfo["brawler_id"] = m.csvTarget
		db.UpdateGameroomPlayerInfo(p.LowID, p.RoomID, playerInfo)
	}
	return SendTeamGameroomData(ctx)
}

type TeamSetReady struct{ bs *bytestream.ByteStream }

func (m *TeamSetReady) Decode(ctx *packets.Context) error { return nil }

func (m *TeamSetReady) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	playerInfo := db.GetPlayerInfo(p.LowID)
	if playerInfo != nil {
		ready := asInt(playerInfo["ready"])
		if ready == 1 {
			ready = 0
		} else {
			ready = 1
		}
		playerInfo["ready"] = ready
		db.UpdateGameroomPlayerInfo(p.LowID, p.RoomID, playerInfo)
	}
	return SendTeamGameroomData(ctx)
}

type TeamMemberStatus struct{ bs *bytestream.ByteStream }

func (m *TeamMemberStatus) Decode(ctx *packets.Context) error {
	ctx.Player.PlayerStatus = m.bs.ReadVInt()
	return nil
}

func (m *TeamMemberStatus) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	playerInfo := db.GetPlayerInfo(p.LowID)
	if playerInfo != nil {
		playerInfo["status"] = p.PlayerStatus
		db.UpdateGameroomPlayerInfo(p.LowID, p.RoomID, playerInfo)
	}
	return SendTeamGameroomData(ctx)
}

type TeamChat struct {
	bs  *bytestream.ByteStream
	msg string
}

func (m *TeamChat) Decode(ctx *packets.Context) error {
	m.msg = m.bs.ReadString()
	return nil
}

func (m *TeamChat) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	db.AddGameroomMsg(p.RoomID, 2, p.LowID, p.Name, m.msg, 0, 0, "")
	db.LoadGameroom()
	return nil
}

type TeamPostAd struct {
	bs         *bytestream.ByteStream
	boolTarget int
}

func (m *TeamPostAd) Decode(ctx *packets.Context) error {
	m.boolTarget = m.bs.ReadVInt()
	return nil
}

func (m *TeamPostAd) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	infoAny := db.GetGameroomInfo("info")
	info, ok := infoAny.(map[string]any)
	if !ok {
		return nil
	}
	if m.boolTarget == 1 {
		info["advertiseToBand"] = !asBool(info["advertiseToBand"])
		if asBool(info["advertiseToBand"]) && !asBool(info["alreadyAdvertisedToBand"]) {
			db.AddMsg(p.ClubID, 77, p.LowID, p.Name, p.ClubRole, "", 0, 0, "")
			info["alreadyAdvertisedToBand"] = true
			db.UpdateGameroomInfo(asBool(info["alreadyAdvertisedToBand"]), p.RoomID, "alreadyAdvertisedToBand")
		}
		db.UpdateGameroomInfo(asBool(info["advertiseToBand"]), p.RoomID, "advertiseToBand")
	} else if m.boolTarget == 2 {
		info["advertiseToFriends"] = !asBool(info["advertiseToFriends"])
		db.UpdateGameroomInfo(asBool(info["advertiseToFriends"]), p.RoomID, "advertiseToFriends")
	}
	return SendTeamGameroomData(ctx)
}

type TeamSpectate struct {
	bs  *bytestream.ByteStream
	unk [3]int
}

func (m *TeamSpectate) Decode(ctx *packets.Context) error {
	m.unk[0] = m.bs.ReadVInt()
	m.unk[1] = m.bs.ReadVInt()
	m.unk[2] = m.bs.ReadVInt()
	return nil
}

func (m *TeamSpectate) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.RoomID != 0 {
		return nil
	}
	db, _ := ctx.EnsureDB()
	joined := db.JoinGameroom(m.unk[1])
	if joined {
		p.RoomID = m.unk[1]
		db.ReplaceValue("room_id", p.RoomID)
		db.AddGameroomMsg(p.RoomID, 4, p.LowID, p.Name, " ", 102, p.LowID, p.Name)
		return nil
	}
	return SendTeamError(ctx, 6)
}

func intInSlice(v int, s []int) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}
