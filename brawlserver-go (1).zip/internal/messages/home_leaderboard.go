package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/entries"
	"brawlserver/internal/packets"
	"strconv"
)

func SendAvatarNameChangeFailed(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 20205, func(w *bytestream.Writer) {
		w.WriteVInt(0)
	})
}

func SendAvatarNameCheckResponse(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 20300, func(w *bytestream.Writer) {
		w.WriteVInt(0)
		w.WriteInt(0)
		w.WriteStringVal(ctx.Player.Name)
	})
}

func SendPlayerProfile(ctx *packets.Context, highID, lowID int, players []map[string]any) error {
	return packets.SendServerPlain(ctx, 24113, func(w *bytestream.Writer) {
		p := ctx.Player
		db, _ := ctx.EnsureDB()
		for _, player := range players {
			if lowID != asInt(player["low_id"]) {
				continue
			}
			w.WriteVInt(highID)
			w.WriteVInt(lowID)
			w.WriteStringVal(asString(player["name"]))
			w.WriteVInt(0)
			ub, _ := player["unlocked_brawlers"].(map[string]any)
			w.WriteVInt(len(ub))
			for k, v := range ub {
				bd, _ := v.(map[string]any)
				w.WriteDataReference(16, atoi(k))
				w.WriteVInt(0)
				w.WriteVInt(asInt(bd["Trophies"]))
				w.WriteVInt(asInt(bd["HighestTrophies"]))
				pl := asInt(bd["PowerLevel"])
				if pl == 8 {
					w.WriteVInt(10)
				} else {
					w.WriteVInt(1 + pl)
				}
			}
			w.WriteVInt(10)
			w.WriteVInt(1)
			w.WriteVInt(asInt(player["three_vs_three_wins"]))
			w.WriteVInt(2)
			w.WriteVInt(asInt(player["player_experience"]))
			w.WriteVInt(3)
			w.WriteVInt(asInt(player["trophies"]))
			w.WriteVInt(4)
			w.WriteVInt(asInt(player["highest_trophies"]))
			w.WriteVInt(5)
			w.WriteVInt(len(ub))
			w.WriteVInt(7)
			w.WriteVInt(28000000 + asInt(player["profile_icon"]))
			w.WriteVInt(8)
			w.WriteVInt(asInt(player["solo_wins"]))
			w.WriteVInt(9)
			w.WriteVInt(0)
			w.WriteVInt(10)
			w.WriteVInt(0)
			w.WriteVInt(11)
			w.WriteVInt(asInt(player["duo_wins"]))
			clubID := asInt(player["club_id"])
			w.WriteBoolean(clubID != 0)
			if clubID != 0 {
				club := db.LoadClub(clubID)
				if club != nil {
					info := club["info"].(map[string]any)
					w.WriteInt(0)
					w.WriteInt(clubID)
					w.WriteStringVal(asString(info["name"]))
					w.WriteDataReference(8, asInt(info["clubBadge"]))
					w.WriteVInt(asInt(info["clubType"]))
					mc := asSlice(info["memberCount"])
					w.WriteVInt(len(mc))
					w.WriteVInt(asInt(info["trophies"]))
					w.WriteVInt(asInt(info["requiredTrophies"]))
					w.WriteVInt(0)
					w.WriteVInt(0)
				}
			}
			w.WriteDataReference(25, asInt(player["club_role"]))
			break
		}
		_ = p
	})
}

type LeaderboardFields struct {
	LeaderboardType int
	IsLocal         int
	TargetBrawler   [2]int
	Entries         []map[string]any
}

func SendLeaderboard(ctx *packets.Context, fields *LeaderboardFields) error {
	return packets.SendServerPlain(ctx, 24403, func(w *bytestream.Writer) {
		p := ctx.Player
		db, _ := ctx.EnsureDB()
		indexOfPlayer := 1
		w.WriteVInt(fields.LeaderboardType)
		if fields.LeaderboardType == 0 {
			w.WriteDataReference(16, fields.TargetBrawler[1])
		} else {
			w.WriteVInt(0)
		}
		if fields.IsLocal != 0 {
			w.WriteStringVal(p.Region)
		} else {
			w.WriteString(nil)
		}
		w.WriteVInt(len(fields.Entries))
		for idx, entry := range fields.Entries {
			w.WriteVInt(0)
			if fields.LeaderboardType == 2 {
				w.WriteVInt(asInt(entry["clubID"]))
			} else {
				w.WriteVInt(asInt(entry["low_id"]))
			}
			w.WriteVInt(1)
			if fields.LeaderboardType == 0 {
				if ub, ok := entry["unlocked_brawlers"].(map[string]any); ok {
					if bd, ok := ub[itoa(fields.TargetBrawler[1])].(map[string]any); ok {
						w.WriteVInt(asInt(bd["Trophies"]))
					} else {
						w.WriteVInt(0)
					}
				} else {
					w.WriteVInt(0)
				}
			} else {
				w.WriteVInt(asInt(entry["trophies"]))
			}
			isPlayer := fields.LeaderboardType != 2
			w.WriteBoolean(isPlayer)
			if isPlayer {
				club := db.LoadClub(asInt(entry["club_id"]))
				if asInt(entry["low_id"]) == p.LowID {
					indexOfPlayer = idx + 1
				}
				w.WriteStringVal(asString(entry["name"]))
				clubName := ""
				if asInt(entry["club_id"]) != 0 && club != nil {
					if info, ok := club["info"].(map[string]any); ok {
						clubName = asString(info["name"])
					}
				}
				w.WriteStringVal(clubName)
				w.WriteVInt(asInt(entry["player_experience"]))
				w.WriteDataReference(28, asInt(entry["profile_icon"]))
			}
			isClub := !isPlayer
			w.WriteBoolean(isClub)
			if isClub {
				w.WriteStringVal(asString(entry["name"]))
				mc := asSlice(entry["memberCount"])
				w.WriteVInt(len(mc))
				w.WriteDataReference(8, asInt(entry["clubBadge"]))
			}
		}
		w.WriteVInt(0)
		w.WriteVInt(indexOfPlayer)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteStringVal(p.Region)
	})
}

func SendBattleLog(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 23458, func(w *bytestream.Writer) {
		w.WriteBoolean(true)
		w.WriteVInt(0)
	})
}

func SendMatchMakingStatus(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 20405, func(w *bytestream.Writer) {
		w.WriteInt(0)
		w.WriteInt(1)
		w.WriteInt(999999999)
		w.WriteInt(0)
		w.WriteInt(0)
	})
}

func SendMatchMakingCancelled(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 20406, func(w *bytestream.Writer) {})
}

func SendPlayAgainStatus(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24777, func(w *bytestream.Writer) {
		w.WriteInt(3)
		w.WriteVInt(2)
	})
}

func SendTeamLeft(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24125, func(w *bytestream.Writer) {
		w.WriteInt(0)
	})
}

func SendTeamError(ctx *packets.Context, errCode int) error {
	return packets.SendServerPlain(ctx, 24129, func(w *bytestream.Writer) {
		w.WriteVInt(errCode)
		w.WriteVInt(errCode)
	})
}

func SendDoNotDistrubOk(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24111, func(w *bytestream.Writer) {
		w.WriteVInt(213)
		w.WriteVInt(ctx.Player.DoNotDisturb)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteVInt(0)
	})
}

func SendAddableFriends(ctx *packets.Context, players []map[string]any) error {
	return packets.SendServerPlain(ctx, 20199, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		w.WriteInt(len(players))
		for _, player := range players {
			w.WriteInt(0)
			w.WriteInt(0)
			w.WriteInt(asInt(player["low_id"]))
			w.WriteStringVal(asString(player["name"]))
			w.WriteString(nil)
			w.WriteString(nil)
			w.WriteString(nil)
			w.WriteInt(28)
			w.WriteInt(asInt(player["trophies"]))
			w.WriteInt(0)
			w.WriteInt(0)
			w.WriteInt(0)
			w.WriteInt(0)
			if asInt(player["club_id"]) != 0 {
				club := db.LoadClub(asInt(player["club_id"]))
				w.WriteBoolean(true)
				if club != nil {
					info := club["info"].(map[string]any)
					w.WriteInt(0)
					w.WriteInt(0)
					w.WriteInt(0)
					w.WriteStringVal(asString(info["name"]))
					w.WriteInt(0)
					w.WriteInt(0)
				}
			} else {
				w.WriteBoolean(false)
			}
			w.WriteString(nil)
			w.WriteInt(28000000 + asInt(player["profile_icon"]))
			w.WriteInt(0)
		}
	})
}

func SendFriendListUpdate(ctx *packets.Context, players []map[string]any) error {
	return packets.SendServerPlain(ctx, 20106, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		w.WriteBoolean(true)
		for _, player := range players {
			entries.EncodeFriendEntry(w, ctx.Player, db, player)
		}
	})
}

func SendAddFriendFailed(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 20112, func(w *bytestream.Writer) {
		w.WriteInt(3)
	})
}

func SendFBAccountDisconnectedOK(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24214, func(w *bytestream.Writer) {})
}

func SendFacebookBindOK(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24201, func(w *bytestream.Writer) {
		w.WriteInt(0)
	})
}

func atoi(s string) int {
	n, _ := strconv.Atoi(s)
	return n
}
