package messages

import (
	"sort"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/entries"
	"brawlserver/internal/packets"
)

func SendFriendList(ctx *packets.Context, players []map[string]any) error {
	return packets.SendServerPlain(ctx, 20105, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		w.WriteInt(len(players))
		w.WriteBoolean(true)
		w.WriteInt(len(players))
		for _, player := range players {
			entries.EncodeFriendEntry(w, ctx.Player, db, player)
		}
	})
}

func SendFriendOnlineStatus(ctx *packets.Context, lowID int) error {
	return packets.SendServerPlain(ctx, 24555, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		playerToken := db.GetTokenByLowId(lowID)
		var playerData map[string]any
		if playerToken != "" {
			ps := db.GetSpecifiedPlayers([]string{playerToken})
			if len(ps) > 0 {
				playerData = ps[0]
			}
		}
		w.WriteLong(0, lowID)
		w.WriteBoolean(true)
		if playerData != nil {
			entries.EncodeFriendOnlineStatusEntry(w, lowID, playerData)
		} else {
			w.WriteVInt(0)
			w.WriteVInt(0)
			w.WriteBoolean(false)
			w.WriteBoolean(false)
		}
	})
}

func sortPlayersByTrophy(players []map[string]any) {
	sort.SliceStable(players, func(i, j int) bool {
		return asInt(players[i]["trophies"]) > asInt(players[j]["trophies"])
	})
}
