package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/entries"
	"brawlserver/internal/packets"
)

func SendChangeAvatarNameCommand(ctx *packets.Context, state int) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	db.ReplaceValue("name", p.Name)
	return packets.SendServerPlain(ctx, 24111, func(w *bytestream.Writer) {
		w.WriteVInt(201)
		w.WriteStringVal(p.Name)
		w.WriteVInt(state)
		entries.EncodeLogicServerCommand(w)
	})
}
