package messages

import "time"

func currentUnix() int {
	return int(time.Now().Unix())
}

func nowUnix() float64 {
	return float64(time.Now().Unix())
}
