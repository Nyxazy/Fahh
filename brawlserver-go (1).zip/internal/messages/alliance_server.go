package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/csvlogic"
	"brawlserver/internal/entries"
	"brawlserver/internal/packets"
	"strconv"
)

func SendAllianceData(ctx *packets.Context, clubLowID int) error {
	return packets.SendServerPlain(ctx, 24301, func(w *bytestream.Writer) {
		p := ctx.Player
		db, _ := ctx.EnsureDB()
		club := db.LoadClub(clubLowID)
		if club == nil {
			w.WriteVInt(0)
			return
		}
		info := club["info"].(map[string]any)
		if p.ClubID != 0 {
			w.WriteVInt(0)
		} else {
			w.WriteVInt(2)
		}
		w.WriteInt(0)
		w.WriteInt(clubLowID)
		w.WriteStringVal(asString(info["name"]))
		w.WriteVInt(8)
		w.WriteVInt(asInt(info["clubBadge"]))
		w.WriteVInt(asInt(info["clubType"]))
		w.WriteVInt(asInt(info["onlineMembers"]))
		w.WriteVInt(asInt(info["trophies"]))
		w.WriteVInt(asInt(info["requiredTrophies"]))
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteStringVal(asString(info["description"]))
		memberCount := info["memberCount"].([]any)
		w.WriteVInt(len(memberCount))
		for _, tok := range memberCount {
			token, _ := tok.(string)
			member := db.GetMemberData(token)
			if member == nil {
				continue
			}
			w.WriteInt(0)
			w.WriteInt(asInt(member["low_id"]))
			w.WriteStringVal(asString(member["name"]))
			w.WriteVInt(asInt(member["club_role"]))
			friendState := 0
			if v, ok := p.Friends[token]; ok {
				friendState = v
			}
			w.WriteVInt(friendState)
			w.WriteVInt(asInt(member["trophies"]))
			w.WriteVInt(asInt(member["player_status"]))
			delta := currentUnix() - asInt(member["last_connection_time"])
			if delta < 3600 {
				w.WriteVInt(0)
			} else {
				w.WriteVInt(delta)
			}
			w.WriteDataReference(28, asInt(member["profile_icon"]))
		}
	})
}

func SendAllianceSearchResult(ctx *packets.Context, requestedName string, found []map[string]any) error {
	return packets.SendServerPlain(ctx, 24310, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		db.CountClubs(1, 100, 2, 30)
		w.WriteStringVal(requestedName)
		w.WriteVInt(len(found))
		for _, i := range found {
			w.WriteInt(0)
			w.WriteInt(asInt(i["clubID"]))
			w.WriteStringVal(asString(i["name"]))
			w.WriteVInt(8)
			w.WriteVInt(asInt(i["clubBadge"]))
			w.WriteVInt(asInt(i["clubType"]))
			mc := asSlice(i["memberCount"])
			w.WriteVInt(len(mc))
			w.WriteVInt(asInt(i["trophies"]))
			w.WriteVInt(asInt(i["requiredTrophies"]))
			w.WriteVInt(0)
			w.WriteStringVal(asString(i["region"]))
			w.WriteVInt(asInt(i["onlineMembers"]))
		}
	})
}

func SendJoinableAllianceList(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24304, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		_, clubs := db.CountClubs(1, 100, 2, 50)
		w.WriteVInt(len(clubs))
		for _, club := range clubs {
			info := club["info"].(map[string]any)
			w.WriteInt(0)
			w.WriteInt(asInt(info["clubID"]))
			w.WriteStringVal(asString(info["name"]))
			w.WriteVInt(8)
			w.WriteVInt(asInt(info["clubBadge"]))
			w.WriteVInt(asInt(info["clubType"]))
			mc := asSlice(info["memberCount"])
			w.WriteVInt(len(mc))
			w.WriteVInt(asInt(info["trophies"]))
			w.WriteVInt(asInt(info["requiredTrophies"]))
			w.WriteVInt(0)
			w.WriteStringVal(asString(info["region"]))
			w.WriteVInt(asInt(info["onlineMembers"]))
		}
	})
}

func SendAllianceChatServer(ctx *packets.Context, clubLowID, tick int) error {
	return packets.SendServerPlain(ctx, 24312, func(w *bytestream.Writer) {
		db, _ := ctx.EnsureDB()
		messageKey := "0"
		if clubLowID != 0 {
			clubMessages := db.LoadClubMessages(clubLowID)
			if clubMessages != nil {
				if info, ok := clubMessages["info"].(map[string]any); ok {
					if mm, ok := info["messages"].(map[string]any); ok {
						for index := 0; index < len(mm); index++ {
							if msg, ok := mm[strconv.Itoa(index)].(map[string]any); ok {
								if asInt(msg["Tick"]) == tick-1 {
									messageKey = strconv.Itoa(index)
								}
							}
						}
					}
				}
			}
			clubMessages = db.LoadClubMessages(clubLowID)
			if info, ok := clubMessages["info"].(map[string]any); ok {
				if mm, ok := info["messages"].(map[string]any); ok {
					if msg, ok := mm[messageKey].(map[string]any); ok {
						w.WriteVInt(asInt(msg["EventType"]))
						entries.EncodeStreamEntryByType(w, ctx.Player, db, msg)
					}
				}
			}
		} else {
			w.WriteVInt(0)
		}
	})
}

func SendAllianceEvent(ctx *packets.Context, event int) error {
	return packets.SendServerPlain(ctx, 24333, func(w *bytestream.Writer) {
		w.WriteVInt(event)
	})
}

func SendAllianceCreateOk(ctx *packets.Context) error    { return SendAllianceEvent(ctx, 20) }
func SendAllianceEditOk(ctx *packets.Context) error      { return SendAllianceEvent(ctx, 10) }
func SendAllianceJoinOk(ctx *packets.Context) error      { return SendAllianceEvent(ctx, 40) }
func SendAllianceLeaveOk(ctx *packets.Context) error     { return SendAllianceEvent(ctx, 80) }
func SendAllianceRoleChanged(ctx *packets.Context) error { return SendAllianceEvent(ctx, 1) }

func SendAllianceMemberEntry(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24308, func(w *bytestream.Writer) {
		p := ctx.Player
		w.WriteInt(0)
		w.WriteInt(p.ClubID)
		w.WriteInt(p.HighID)
		w.WriteInt(p.LowID)
		w.WriteStringVal(p.Name)
		w.WriteVInt(0)
		w.WriteVInt(28)
		w.WriteVInt(p.ProfileIcon)
		w.WriteHexa("7F")
	})
}

func SendAllianceBotChat(ctx *packets.Context, botMsg string) error {
	return packets.SendServerPlain(ctx, 24312, func(w *bytestream.Writer) {
		w.WriteVInt(2)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteVInt(1)
		w.WriteVInt(1)
		w.WriteStringVal("Club Bot")
		w.WriteVInt(3)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteStringVal(botMsg)
	})
}

func SendBotProfile(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24113, func(w *bytestream.Writer) {
		p := ctx.Player
		w.WriteVInt(1)
		w.WriteVInt(1)
		w.WriteBoolean(true)
		w.WriteVInt(len(p.BrawlersID))
		for _, bid := range p.BrawlersID {
			w.WriteDataReference(16, bid)
			w.WriteVInt(0)
			w.WriteVInt(99999)
			w.WriteVInt(99999)
			w.WriteVInt(10)
		}
		w.WriteVInt(15)
		pairs := [][2]int{{1, 99999}, {2, 1262469}, {3, p.Trophies}, {4, p.Trophies}, {5, len(p.BrawlersID)}, {6, 0}, {7, 99999}, {8, 99999}, {9, 99999}, {10, 99999}, {11, 99999}, {12, 10}, {13, 99999}, {14, 1}, {15, 99999}}
		for _, pr := range pairs {
			w.WriteVInt(pr[0])
			w.WriteVInt(pr[1])
		}
		w.WriteStringVal(p.Name)
		w.WriteVInt(100)
		w.WriteVInt(28000000)
		w.WriteVInt(43000000)
		w.WriteBoolean(true)
		w.WriteInt(0)
		w.WriteInt(1)
		w.WriteStringVal("Classic Brawl")
		w.WriteVInt(8)
		w.WriteVInt(5)
		w.WriteVInt(3)
		w.WriteVInt(2)
		w.WriteVInt(99999)
		w.WriteVInt(99999)
		w.WriteVInt(0)
		w.WriteVInt(0)
		w.WriteVInt(0)
	})
}

func asSlice(v any) []any {
	if s, ok := v.([]any); ok {
		return s
	}
	return nil
}

var _ = csvlogic.GetBrawlerName
