package messages

import (
	"brawlserver/internal/battle"
	"brawlserver/internal/bytestream"
	"brawlserver/internal/logic"
	"brawlserver/internal/packets"
)

func EncodeBattleResult(w *bytestream.Writer, ctx *packets.Context, fields *battle.BattleFields) {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	mgr := battle.NewManager(p, db)
	rewards := mgr.ProcessRewards(fields)

	w.WriteVInt(fields.GameMode)
	if fields.GameMode == 2 || fields.GameMode == 5 {
		w.WriteVInt(fields.Rank)
	} else {
		w.WriteVInt(fields.Victory)
	}
	w.WriteVInt(rewards.TokensGain)
	w.WriteVInt(rewards.TrophiesGain)
	w.WriteVInt(rewards.DoubledTokens)
	w.WriteVInt(rewards.RemainingTokens)
	w.WriteVInt(0)

	w.WriteBoolBit(rewards.HasStarKey)
	w.WriteBoolBit(false)
	w.WriteBoolBit(false)
	w.WriteBoolBit(p.TutorialState == 1)
	w.WriteBoolBit(fields.IsInRealGame)
	w.WriteBoolBit(p.TutorialState == 1)

	w.WriteVInt(fields.HeroesCount)
	firstTeam := 0
	if len(fields.Heroes) > 0 {
		firstTeam = fields.Heroes[0].Team
	}
	for _, hero := range fields.Heroes {
		w.WriteStringVal(hero.Name)
		w.WriteBoolBit(hero.IsPlayer)
		w.WriteBoolBit(hero.Team != firstTeam)
		w.WriteBoolBit(hero.IsPlayer)
		w.WriteDataReference(hero.ID[0], hero.ID[1])
		w.WriteDataReference(hero.SkinID[0], hero.ID[1])
		w.WriteVInt(hero.Trophies)
		w.WriteVInt(hero.PowerLevel)
		w.WriteBoolBit(hero.IsPlayer)
		if hero.IsPlayer {
			w.WriteLong(0, hero.LowID)
		}
	}

	w.WriteVInt(len(rewards.ExpRewardsArray))
	for id, amt := range rewards.ExpRewardsArray {
		w.WriteVInt(id)
		w.WriteVInt(amt)
	}

	w.WriteVInt(0)
	w.WriteVInt(2)
	w.WriteVInt(1)
	w.WriteVInt(rewards.BrawlerTrophies)
	w.WriteVInt(rewards.BrawlerTrophiesRank)
	w.WriteVInt(5)
	w.WriteVInt(p.PlayerExperience - rewards.Experience - rewards.StarPlayerExp)
	w.WriteVInt(p.PlayerExperience - rewards.Experience - rewards.StarPlayerExp)

	p.KeyReward = rewards.TokensGain
	p.TrophyReward = rewards.TrophiesGain

	w.WriteBoolBit(true)
	w.WriteVInt(621)
	w.WriteHexa(logic.MilestonesHexa)
	w.WriteDataReference(16, 0)
	w.WriteBoolBit(false)
}

func SendBattleResult(ctx *packets.Context, fields *battle.BattleFields) error {
	return packets.SendServerPlain(ctx, 23456, func(w *bytestream.Writer) {
		EncodeBattleResult(w, ctx, fields)
	})
}

type BattleResultShowdownMessage struct {
	Player *logic.Player
}

func (m *BattleResultShowdownMessage) ID() int { return 23456 }

func (m *BattleResultShowdownMessage) Encode(w *bytestream.Writer) {
	tokens := 0
	trophiesinresult := 0
	doubledtokens := 0
	remainingtokens := 0
	result := 0
	brawler_trophies := 0
	brawler_trophies_for_rank := 0
	experience := 0
	startoken := 0

	w.WriteVInt(2)
	w.WriteVInt(m.Player.Rank)

	w.WriteVInt(tokens)
	if m.Player.Result < 16 {
		w.WriteVInt(0)
	}
	if m.Player.Result >= 16 {
		w.WriteVInt(trophiesinresult)
	}
	w.WriteVInt(doubledtokens)
	w.WriteVInt(remainingtokens)
	w.WriteVInt(0)
	w.WriteVInt(result)
	w.WriteVInt(1)

	w.WriteStringVal(m.Player.Name)
	w.WriteVInt(1)
	w.WriteScID(16, m.Player.BrawlerID)
	w.WriteScID(29, m.Player.SkinID)
	w.WriteVInt(brawler_trophies)
	w.WriteVInt(10)
	b := true
	w.WriteBoolean(b)
	if b {
		w.WriteInt(0)
		w.WriteInt(1)
	}

	w.WriteVInt(2)
	w.WriteVInt(0)
	w.WriteVInt(experience)
	w.WriteVInt(8)
	w.WriteVInt(0)

	w.WriteVInt(0)

	w.WriteVInt(2)
	w.WriteVInt(1)
	w.WriteVInt(brawler_trophies)
	w.WriteVInt(brawler_trophies_for_rank)
	w.WriteVInt(5)
	w.WriteVInt(m.Player.PlayerExperience - experience)
	w.WriteVInt(m.Player.PlayerExperience - experience)

	_ = startoken
	w.WriteUInt8(1)

	w.WriteVInt(621)
	w.WriteHexa(logic.MilestonesHexa)
	w.WriteVInt(0)
	w.WriteBoolean(true)
}

type BattleResultDuoShowdownMessage struct {
	Player *logic.Player
}

func (m *BattleResultDuoShowdownMessage) ID() int { return 23456 }

func (m *BattleResultDuoShowdownMessage) Encode(w *bytestream.Writer) {
	tokens := 0
	trophiesinresult := 0
	doubledtokens := 0
	remainingtokens := 0
	result := 0
	brawler_trophies := 0
	brawler_trophies_for_rank := 0
	experience := 0

	w.WriteVInt(5)
	w.WriteVInt(m.Player.Rank)

	w.WriteVInt(tokens)
	if m.Player.Result < 16 {
		w.WriteVInt(0)
	}
	if m.Player.Result >= 16 {
		w.WriteVInt(trophiesinresult)
	}
	w.WriteVInt(doubledtokens)
	w.WriteVInt(remainingtokens)
	w.WriteVInt(0)
	w.WriteVInt(result)
	w.WriteVInt(2)

	w.WriteStringVal(m.Player.Name)
	w.WriteVInt(1)
	w.WriteVInt(16)
	w.WriteVInt(m.Player.BrawlerID)
	w.WriteVInt(29)
	w.WriteVInt(m.Player.SkinID)
	w.WriteVInt(brawler_trophies)
	w.WriteVInt(10)
	b := true
	w.WriteBoolean(b)
	if b {
		w.WriteInt(0)
		w.WriteInt(1)
	}

	w.WriteStringVal("Bot 1")
	w.WriteVInt(0)
	w.WriteVInt(16)
	w.WriteVInt(m.Player.Bot1)
	w.WriteVInt(0)
	w.WriteVInt(0)
	w.WriteVInt(10)
	bb := true
	w.WriteBoolean(bb)
	if bb {
		w.WriteInt(0)
		w.WriteInt(2)
	}

	w.WriteVInt(2)
	w.WriteVInt(0)
	w.WriteVInt(experience)
	w.WriteVInt(8)
	w.WriteVInt(0)

	w.WriteVInt(0)

	w.WriteVInt(2)
	w.WriteVInt(1)
	w.WriteVInt(brawler_trophies)
	w.WriteVInt(brawler_trophies_for_rank)
	w.WriteVInt(5)
	w.WriteVInt(m.Player.PlayerExperience - experience)
	w.WriteVInt(m.Player.PlayerExperience - experience)

	w.WriteScID(26, m.Player.ProfileIcon)
	w.WriteBoolean(true)
}
