package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/entries"
	"brawlserver/internal/logic"
	"brawlserver/internal/packets"
)

func SendServerHello(ctx *packets.Context) error {
	return packets.SendServer(ctx, 20100, 0, func(w *bytestream.Writer) {
		w.WriteInt(24)
		w.WriteHexa(bytestream.RandomKey(11))
		w.WriteHexa("00446f6e277420747279203a29")
	})
}

func SendLoginOk(ctx *packets.Context) error {
	return packets.SendServer(ctx, 20104, 1, func(w *bytestream.Writer) {
		p := ctx.Player
		w.WriteInt(p.HighID)
		w.WriteInt(p.LowID)
		w.WriteInt(p.HighID)
		w.WriteInt(p.LowID)
		w.WriteStringVal(p.Token)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteInt(20)
		w.WriteInt(93)
		w.WriteInt(1)
		w.WriteStringVal("dev")
		w.WriteInt(0)
		w.WriteInt(0)
		w.WriteInt(0)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteInt(0)
		w.WriteString(nil)
		w.WriteStringVal("RU")
		w.WriteString(nil)
		w.WriteInt(1)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteVInt(0)
		w.WriteString(nil)
		w.WriteVInt(1)
	})
}

func SendLoginFailed(ctx *packets.Context) error {
	return packets.SendServer(ctx, 20103, 0, func(w *bytestream.Writer) {
		p := ctx.Player
		w.WriteInt(p.ErrCode)
		w.WriteStringVal(logic.LoadFingerprintFull("GameAssets/fingerprint.json"))
		w.WriteString(nil)
		w.WriteStringVal(p.PatchURL)
		w.WriteStringVal(p.UpdateURL)
		w.WriteString(nil)
		w.WriteInt(p.MaintenanceTime)
		w.WriteBoolean(false)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteInt(0)
		w.WriteInt(3)
		w.WriteString(nil)
		w.WriteString(nil)
		w.WriteInt(0)
		w.WriteInt(0)
		w.WriteBoolean(false)
		w.WriteBoolean(false)
	})
}

func SendKeepAliveOk(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 20108, func(w *bytestream.Writer) {})
}

func SendOwnHomeData(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24101, func(w *bytestream.Writer) {
		p := ctx.Player
		db, _ := ctx.EnsureDB()
		db.LoadAccount()
		p.PlayerStatus = 2
		db.ReplaceValue("player_status", p.PlayerStatus)
		entries.EncodeClientHome(w, p, db)
		entries.EncodeClientAvatar(w, p)
		w.WriteVInt(currentUnix())
		p.TrophyReward = 0
		p.KeyReward = 0
		p.StarKeyReward = 0
		db.ReplaceValue("key_reward", p.KeyReward)
		db.ReplaceValue("trophy_reward", p.TrophyReward)
		db.ReplaceValue("star_key_reward", p.StarKeyReward)
		db.ReplaceValue("region", p.Region)
	})
}
