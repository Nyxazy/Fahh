package messages

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/commands"
	"brawlserver/internal/packets"
)

type EndClientTurn struct {
	bs         *bytestream.ByteStream
	count      int
	commandIDs []int
}

func (m *EndClientTurn) Decode(ctx *packets.Context) error {
	m.bs.ReadBoolean()
	m.bs.ReadVInt()
	m.bs.ReadVInt()
	m.count = m.bs.ReadVInt()
	m.commandIDs = make([]int, 0, m.count)
	for i := 0; i < m.count; i++ {
		m.commandIDs = append(m.commandIDs, m.bs.ReadVInt())
	}
	return nil
}

func (m *EndClientTurn) Process(ctx *packets.Context) error {
	db, _ := ctx.EnsureDB()
	proc := commands.NewProcessor(ctx, db, m.bs)
	for _, cmdID := range m.commandIDs {
		proc.Handle(cmdID)
	}
	return nil
}
