package messages

import (
	"time"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/packets"
)

type CreateMessage struct {
	bs                 *bytestream.ByteStream
	clubName           string
	clubDescription    string
	badgeID, clubType  int
	clubTrophiesNeeded int
}

func (m *CreateMessage) Decode(ctx *packets.Context) error {
	m.clubName = m.bs.ReadString()
	m.clubDescription = m.bs.ReadString()
	m.bs.ReadVInt()
	m.badgeID = m.bs.ReadVInt()
	m.clubType = m.bs.ReadVInt()
	m.clubTrophiesNeeded = m.bs.ReadVInt()
	return nil
}

func (m *CreateMessage) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.ClubID != 0 {
		return nil
	}
	db, _ := ctx.EnsureDB()
	db.GetClubId()
	db.ReplaceValue("club_id", p.ClubID)
	db.ReplaceValue("club_role", 2)
	p.ClubRole = 2
	clubData := map[string]any{
		"info": map[string]any{
			"clubID": p.ClubID, "name": m.clubName, "description": m.clubDescription,
			"region": p.Region, "clubBadge": m.badgeID, "clubType": m.clubType,
			"requiredTrophies": m.clubTrophiesNeeded, "trophies": p.Trophies,
			"memberCount": []any{p.Token}, "onlineMembers": 1,
		},
	}
	chatData := map[string]any{
		"info": map[string]any{
			"clubID": p.ClubID,
			"messages": map[string]any{
				"0": map[string]any{
					"EventType": 4, "Event": 3, "Tick": 1, "PlayerID": p.LowID,
					"PlayerName": p.Name, "PlayerRole": p.ClubRole, "Message": "",
					"promotedTeam": 0, "TimeStamp": float64(time.Now().Unix()),
					"targetID": p.LowID, "targetName": p.Name,
				},
			},
		},
	}
	db.CreateClub(p.ClubID, clubData, chatData)
	SendAllianceJoinOk(ctx)
	SendMyAlliance(ctx, p.ClubID)
	return SendAllianceStream(ctx, p.ClubID, 0)
}

type EditSettingsMessage struct {
	bs               *bytestream.ByteStream
	clubDescription  string
	badgeID          int
	clubType         int
	requiredTrophies int
}

func (m *EditSettingsMessage) Decode(ctx *packets.Context) error {
	m.clubDescription = m.bs.ReadString()
	m.bs.ReadVInt()
	m.badgeID = m.bs.ReadVInt()
	m.clubType = m.bs.ReadVInt()
	m.requiredTrophies = m.bs.ReadVInt()
	return nil
}

func (m *EditSettingsMessage) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	db.ReplaceClubValue(p.ClubID, m.clubDescription, m.badgeID, m.clubType, m.requiredTrophies)
	SendAllianceEditOk(ctx)
	return SendMyAlliance(ctx, p.ClubID)
}

type JoinMessage struct {
	bs  *bytestream.ByteStream
	cid int
}

func (m *JoinMessage) Decode(ctx *packets.Context) error {
	m.bs.ReadInt()
	m.cid = m.bs.ReadInt()
	return nil
}

func (m *JoinMessage) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	p.ClubID = m.cid
	p.ClubRole = 1
	db.ReplaceValue("club_role", 1)
	db.ReplaceValue("club_id", p.ClubID)
	db.AddMember(p.ClubID, p.Token, 1)
	db.AddMsg(p.ClubID, 4, p.LowID, p.Name, p.ClubRole, "", 3, p.LowID, p.Name)
	SendAllianceJoinOk(ctx)
	SendMyAlliance(ctx, p.ClubID)
	SendAllianceStream(ctx, p.ClubID, 0)
	nextKey := db.GetNextKey(p.ClubID)
	return SendAllianceChatServer(ctx, p.ClubID, nextKey+1)
}

type KickAllianceMember struct {
	bs       *bytestream.ByteStream
	playerID [2]int
}

func (m *KickAllianceMember) Decode(ctx *packets.Context) error {
	m.playerID = m.bs.ReadLong()
	m.bs.ReadString()
	return nil
}

func (m *KickAllianceMember) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.ClubRole == 1 {
		return nil
	}
	db, _ := ctx.EnsureDB()
	club := db.LoadClub(p.ClubID)
	if club == nil {
		return nil
	}
	info := club["info"].(map[string]any)
	memberCount := info["memberCount"].([]any)
	playerToken := db.GetTokenByLowId(m.playerID[1])
	if len(memberCount) == 1 {
		db.AddMember(p.ClubID, playerToken, 0)
	} else {
		db.AddMember(p.ClubID, playerToken, 2)
		db.AddMsg(p.ClubID, 4, p.LowID, p.Name, p.ClubRole, "", 1, m.playerID[1], p.Name)
	}
	SendMyAlliance(ctx, p.ClubID)
	db.ReplaceOtherValue("club_id", 0, playerToken)
	db.ReplaceOtherValue("club_role", 0, playerToken)
	return nil
}

type LeaveMessage struct{ bs *bytestream.ByteStream }

func (m *LeaveMessage) Decode(ctx *packets.Context) error { return nil }

func (m *LeaveMessage) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	club := db.LoadClub(p.ClubID)
	if club == nil {
		return nil
	}
	info := club["info"].(map[string]any)
	memberCount := info["memberCount"].([]any)
	if len(memberCount) == 1 {
		db.AddMember(p.ClubID, p.Token, 0)
	} else {
		db.AddMember(p.ClubID, p.Token, 2)
		db.AddMsg(p.ClubID, 4, p.LowID, p.Name, p.ClubRole, "", 4, p.LowID, p.Name)
	}
	SendAllianceLeaveOk(ctx)
	SendMyAlliance(ctx, 0)
	p.ClubID = 0
	db.ReplaceValue("club_id", 0)
	db.ReplaceValue("club_role", 0)
	p.ClubRole = 0
	return nil
}

type PromoteMember struct {
	bs           *bytestream.ByteStream
	targetLowID  int
	targetedRole int
}

func (m *PromoteMember) Decode(ctx *packets.Context) error {
	m.bs.ReadInt()
	m.targetLowID = m.bs.ReadInt()
	m.targetedRole = m.bs.ReadVInt()
	return nil
}

func (m *PromoteMember) Process(ctx *packets.Context) error {
	p := ctx.Player
	if m.targetedRole < 0 || m.targetedRole > 4 {
		return nil
	}
	if p.ClubRole != 2 && p.ClubRole != 4 {
		return nil
	}
	if (p.ClubRole == 3 && (m.targetedRole == 4 || m.targetedRole == 2)) ||
		(p.ClubRole == 4 && m.targetedRole == 2) {
		return nil
	}
	db, _ := ctx.EnsureDB()
	playerToken := db.GetTokenByLowId(m.targetLowID)
	playersData := db.GetSpecifiedPlayers([]string{playerToken})
	var name string
	if len(playersData) > 0 {
		name = asString(playersData[0]["name"])
	}
	db.ReplaceOtherValue("club_role", m.targetedRole, playerToken)
	db.AddMsg(p.ClubID, 4, p.LowID, p.Name, 0, "", 5, m.targetLowID, name)
	if m.targetedRole == 2 {
		p.ClubRole = 4
		db.ReplaceValue("club_role", p.ClubRole)
		db.AddMsg(p.ClubID, 4, p.LowID, p.Name, 0, "", 6, p.LowID, p.Name)
	}
	return SendAllianceEvent(ctx, 81)
}

type RequestJoinAlliance struct {
	bs               *bytestream.ByteStream
	clubID           [2]int
	promotionMessage string
}

func (m *RequestJoinAlliance) Decode(ctx *packets.Context) error {
	m.clubID = m.bs.ReadLong()
	m.promotionMessage = m.bs.ReadString()
	return nil
}

func (m *RequestJoinAlliance) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	db.AddMsg(m.clubID[1], 3, p.LowID, p.Name, p.ClubRole, m.promotionMessage, 1, 0, "")
	return SendAllianceEvent(ctx, 50)
}

type RespondJoinRequest struct {
	bs         *bytestream.ByteStream
	messageID  [2]int
	isAccepted bool
}

func (m *RespondJoinRequest) Decode(ctx *packets.Context) error {
	m.messageID = m.bs.ReadLong()
	m.isAccepted = m.bs.ReadBoolean()
	return nil
}

func (m *RespondJoinRequest) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	newEvent := 0
	if m.isAccepted {
		newEvent = 2
	}
	db.ReplaceMessageValue(m.messageID[1], "Event", newEvent)
	if m.isAccepted {
		clubMessages := db.LoadClubMessages(p.ClubID)
		playerToken := ""
		playerID := 0
		if clubMessages != nil {
			if info, ok := clubMessages["info"].(map[string]any); ok {
				if mm, ok := info["messages"].(map[string]any); ok {
					for index := 0; index < len(mm); index++ {
						if msg, ok := mm[itoa(index)].(map[string]any); ok {
							if asInt(msg["Tick"]) == m.messageID[1] {
								playerToken = db.GetTokenByLowId(asInt(msg["PlayerID"]))
								playerID = asInt(msg["PlayerID"])
							}
						}
					}
				}
			}
		}
		playersData := db.GetSpecifiedPlayers([]string{playerToken})
		if len(playersData) > 0 && asInt(playersData[0]["club_id"]) != 0 {
			return SendAllianceEvent(ctx, 92)
		}
		SendAllianceEvent(ctx, 90)
		db.ReplaceOtherValue("club_id", p.ClubID, playerToken)
		db.ReplaceOtherValue("club_role", 1, playerToken)
		db.AddMember(p.ClubID, playerToken, 1)
		db.AddMsg(p.ClubID, 4, p.LowID, p.Name, 0, "", 3, playerID, "")
	} else {
		SendAllianceEvent(ctx, 91)
	}
	return nil
}

type SearchMessage struct {
	bs            *bytestream.ByteStream
	requestedName string
}

func (m *SearchMessage) Decode(ctx *packets.Context) error {
	m.requestedName = m.bs.ReadString()
	m.bs.ReadInt()
	m.bs.ReadInt()
	m.bs.ReadInt()
	m.bs.ReadInt()
	m.bs.ReadBoolean()
	m.bs.ReadInt()
	m.bs.ReadInt()
	return nil
}

func (m *SearchMessage) Process(ctx *packets.Context) error {
	db, _ := ctx.EnsureDB()
	_, clubs := db.CountClubs(1, 100, 2, 30)
	found := []map[string]any{}
	for _, club := range clubs {
		info := club["info"].(map[string]any)
		name := asString(info["name"])
		if containsLower(name, m.requestedName) || toHLLow(m.requestedName) == asInt(info["clubID"]) {
			found = append(found, info)
		}
	}
	return SendAllianceSearchResult(ctx, m.requestedName, found)
}

type SendClubMail struct{ bs *bytestream.ByteStream }

func (m *SendClubMail) Decode(ctx *packets.Context) error {
	for i := 0; i < 30; i++ {
		m.bs.ReadVInt()
	}
	return nil
}

func (m *SendClubMail) Process(ctx *packets.Context) error { return nil }

type AllianceChat struct {
	bs  *bytestream.ByteStream
	msg string
}

func (m *AllianceChat) Decode(ctx *packets.Context) error {
	m.msg = m.bs.ReadString()
	return nil
}

func (m *AllianceChat) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	db.AddMsg(p.ClubID, 2, p.LowID, p.Name, p.ClubRole, m.msg, 0, 0, "")
	db.LoadClub(p.ClubID)
	return nil
}

type AskForAllianceData struct {
	bs        *bytestream.ByteStream
	clubLowID int
}

func (m *AskForAllianceData) Decode(ctx *packets.Context) error {
	m.bs.ReadInt()
	m.clubLowID = m.bs.ReadInt()
	return nil
}

func (m *AskForAllianceData) Process(ctx *packets.Context) error {
	return SendAllianceData(ctx, m.clubLowID)
}

type AskJoinableAlliances struct{ bs *bytestream.ByteStream }

func (m *AskJoinableAlliances) Decode(ctx *packets.Context) error { return nil }

func (m *AskJoinableAlliances) Process(ctx *packets.Context) error {
	return SendJoinableAllianceList(ctx)
}

func containsLower(haystack, needle string) bool {
	return strIndexLower(haystack, needle) >= 0
}

func strIndexLower(haystack, needle string) int {
	h := lowerASCII(haystack)
	n := lowerASCII(needle)
	if len(n) == 0 {
		return 0
	}
	for i := 0; i+len(n) <= len(h); i++ {
		if h[i:i+len(n)] == n {
			return i
		}
	}
	return -1
}

func lowerASCII(s string) string {
	b := []byte(s)
	for i := range b {
		if b[i] >= 'A' && b[i] <= 'Z' {
			b[i] += 32
		}
	}
	return string(b)
}

func toHLLow(hashtag string) int {
	tagChars := []byte("0289PYLQGRCJUV")
	if len(hashtag) > 0 && hashtag[0] == '#' {
		hashtag = hashtag[1:]
	}
	id := 0
	for i := 0; i < len(hashtag); i++ {
		c := hashtag[i]
		if c >= 'a' && c <= 'z' {
			c -= 32
		}
		idx := -1
		for j, ch := range tagChars {
			if ch == c {
				idx = j
				break
			}
		}
		if idx < 0 {
			return 0
		}
		id = id*len(tagChars) + idx
	}
	return id >> 8
}
