package messages

import (
	"encoding/json"
	"os"
	"time"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/packets"
)

type ClientHelloMessage struct {
	bs           *bytestream.ByteStream
	Fields       map[string]any
	serverStates any
}

func (m *ClientHelloMessage) Decode(ctx *packets.Context) error {
	f := map[string]any{}
	f["Protocol"] = m.bs.ReadInt()
	f["KeyVersion"] = m.bs.ReadInt()
	f["MajorVersion"] = m.bs.ReadInt()
	f["MinorVersion"] = m.bs.ReadInt()
	f["Build"] = m.bs.ReadInt()
	f["ContentHash"] = m.bs.ReadString()
	f["DeviceType"] = m.bs.ReadInt()
	f["AppStore"] = m.bs.ReadInt()
	m.Fields = f
	return nil
}

func (m *ClientHelloMessage) Process(ctx *packets.Context) error {
	if err := SendServerHello(ctx); err != nil {
		return err
	}
	if states, ok := m.serverStates.(interface{ IsMaintenance() bool }); ok && states.IsMaintenance() {
		return SendLoginFailed(ctx)
	}
	if asInt(m.Fields["MajorVersion"]) != 12 {
		return SendLoginFailed(ctx)
	}
	return nil
}

type LoginMessage struct {
	bs             *bytestream.ByteStream
	major          int
	fingerprintSha string
}

func (m *LoginMessage) Decode(ctx *packets.Context) error {
	p := ctx.Player
	p.HighID = m.bs.ReadInt()
	p.LowID = m.bs.ReadInt()
	p.Token = m.bs.ReadString()
	m.major = m.bs.ReadInt()
	m.bs.ReadInt()
	m.bs.ReadInt()
	m.fingerprintSha = m.bs.ReadString()
	m.bs.ReadString()
	p.DeviceID = m.bs.ReadString()
	m.bs.ReadString()
	p.Device = m.bs.ReadString()
	p.PreferredLanguage = m.bs.ReadDataReference()
	regionStr := m.bs.ReadString()
	parts := splitOnce(regionStr, "-")
	if len(parts) > 1 {
		p.Region = parts[1]
	}
	return nil
}

func (m *LoginMessage) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, err := ctx.EnsureDB()
	if err != nil {
		return err
	}
	if m.major != 12 {
		p.ErrCode = 16
		return SendLoginFailed(ctx)
	}
	if m.fingerprintSha != p.PatchSha && p.Patch {
		return SendLoginFailed(ctx)
	}

	if p.LowID != 0 {
		func() {
			defer func() { recover() }()
			db.GetPlayerId()
			db.CreateAccount()
		}()
		if err := SendLoginOk(ctx); err != nil {
			return err
		}
		db.LoadAccount()
		so := loadSpecialOffer()
		hasSpecial, _ := so["isEnabled"].(bool)
		offers := db.LoadOffers(p.Token)
		if info, ok := offers["info"].(map[string]any); ok {
			for index := 0; index < len(info); index++ {
				item, _ := info[itoa(index)].(map[string]any)
				if item == nil {
					continue
				}
				if asInt(item["Timer"]) < int(time.Now().Unix()) || (hasSpecial && index == 0) {
					db.RerollOffer(p.Token, index)
				}
			}
		}
		if err := SendOwnHomeData(ctx); err != nil {
			return err
		}
		db.LoadGameroom()
		if err := SendMyAlliance(ctx, p.ClubID); err != nil {
			return err
		}
		friendTokens := make([]string, 0, len(p.Friends))
		for token := range p.Friends {
			friendTokens = append(friendTokens, token)
		}
		players := db.GetSpecifiedPlayers(friendTokens)
		sortPlayersByTrophy(players)
		if err := SendFriendList(ctx, players); err != nil {
			return err
		}
		for _, player := range players {
			if err := SendFriendOnlineStatus(ctx, asInt(player["low_id"])); err != nil {
				return err
			}
		}
		nextKey := db.GetNextKey(p.ClubID)
		p.LastSeenKey = nextKey
		if err := SendAllianceStream(ctx, p.ClubID, 0); err != nil {
			return err
		}
		if err := SendAllianceTeams(ctx); err != nil {
			return err
		}
		if p.RoomID > 0 {
			func() {
				defer func() { recover() }()
				SendTeamGameroomData(ctx)
				SendTeamStream(ctx, p.RoomID)
			}()
		}
		return nil
	}

	p.HighID = 0
	p.Token = bytestream.RandomStringDigits()
	db.GetPlayerId()
	db.CreateAccount()
	if err := SendLoginOk(ctx); err != nil {
		return err
	}
	if err := SendOwnHomeData(ctx); err != nil {
		return err
	}
	return SendMyAlliance(ctx, p.ClubID)
}

type KeepAliveMessage struct {
	bs *bytestream.ByteStream
}

func (m *KeepAliveMessage) Decode(ctx *packets.Context) error { return nil }
func (m *KeepAliveMessage) Process(ctx *packets.Context) error {
	return SendKeepAliveOk(ctx)
}

type ClientCapabilities struct {
	bs *bytestream.ByteStream
}

func (m *ClientCapabilities) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	return nil
}

func (m *ClientCapabilities) Process(ctx *packets.Context) error { return nil }

func loadSpecialOffer() map[string]any {
	raw, err := os.ReadFile("special_offer.json")
	if err != nil {
		return map[string]any{"isEnabled": false}
	}
	var m map[string]any
	json.Unmarshal(raw, &m)
	return m
}

func splitOnce(s, sep string) []string {
	for i := 0; i+len(sep) <= len(s); i++ {
		if s[i:i+len(sep)] == sep {
			return []string{s[:i], s[i+len(sep):]}
		}
	}
	return []string{s}
}
