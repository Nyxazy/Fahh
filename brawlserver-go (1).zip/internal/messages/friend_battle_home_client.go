package messages

import (
	"brawlserver/internal/battle"
	"brawlserver/internal/bytestream"
	"brawlserver/internal/packets"
	"strconv"
)

type AddFriend struct {
	bs    *bytestream.ByteStream
	lowID int
}

func (m *AddFriend) Decode(ctx *packets.Context) error {
	m.bs.ReadInt()
	m.lowID = m.bs.ReadInt()
	return nil
}

func (m *AddFriend) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	newFriend := db.GetTokenByLowId(m.lowID)
	if newFriend != "" {
		p.Friends[newFriend] = 2
		db.ReplaceValue("friends", p.Friends)
		players := db.GetSpecifiedPlayers([]string{newFriend})
		if len(players) > 0 {
			friendData, _ := players[0]["friends"].(map[string]any)
			if friendData == nil {
				friendData = map[string]any{}
			}
			friendData[p.Token] = 3
			db.ReplaceOtherValue("friends", friendData, newFriend)
		}
		sortPlayersByTrophy(players)
		return SendFriendListUpdate(ctx, players)
	}
	return nil
}

type AskForFriendList struct{ bs *bytestream.ByteStream }

func (m *AskForFriendList) Decode(ctx *packets.Context) error { return nil }

func (m *AskForFriendList) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	tokens := make([]string, 0, len(p.Friends))
	for token := range p.Friends {
		tokens = append(tokens, token)
	}
	players := db.GetSpecifiedPlayers(tokens)
	sortPlayersByTrophy(players)
	return SendFriendList(ctx, players)
}

type AskForFriendSuggestions struct{ bs *bytestream.ByteStream }

func (m *AskForFriendSuggestions) Decode(ctx *packets.Context) error { return nil }

func (m *AskForFriendSuggestions) Process(ctx *packets.Context) error {
	return SendAddableFriends(ctx, []map[string]any{})
}

type FacebookConnect struct {
	bs *bytestream.ByteStream
}

func (m *FacebookConnect) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	ctx.Player.FacebookID = m.bs.ReadString()
	ctx.Player.FacebookToken = m.bs.ReadString()
	return nil
}

func (m *FacebookConnect) Process(ctx *packets.Context) error {
	ctx.Player.IsFbLinked = 1
	return SendFacebookBindOK(ctx)
}

type UnlinkFacebook struct {
	bs *bytestream.ByteStream
}

func (m *UnlinkFacebook) Decode(ctx *packets.Context) error {
	m.bs.ReadVInt()
	ctx.Player.FacebookID = m.bs.ReadString()
	ctx.Player.FacebookToken = m.bs.ReadString()
	return nil
}

func (m *UnlinkFacebook) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.IsFbLinked == 1 {
		p.IsFbLinked = 0
		db, _ := ctx.EnsureDB()
		db.ReplaceValue("is_fb_linked", 0)
		db.ReplaceValue("facebook_id", "None")
		return SendFBAccountDisconnectedOK(ctx)
	}
	return nil
}

type AskProfile struct {
	bs     *bytestream.ByteStream
	lowID  int
	highID int
}

func (m *AskProfile) Decode(ctx *packets.Context) error {
	m.highID = m.bs.ReadInt()
	m.lowID = m.bs.ReadInt()
	return nil
}

func (m *AskProfile) Process(ctx *packets.Context) error {
	db, _ := ctx.EnsureDB()
	players := db.GetAllPlayers()
	return SendPlayerProfile(ctx, m.highID, m.lowID, players)
}

type AvatarNameCheckRequest struct {
	bs *bytestream.ByteStream
}

func (m *AvatarNameCheckRequest) Decode(ctx *packets.Context) error {
	ctx.Player.Name = m.bs.ReadString()
	return nil
}

func (m *AvatarNameCheckRequest) Process(ctx *packets.Context) error {
	return SendAvatarNameCheckResponse(ctx)
}

type PlayerStatus struct {
	bs     *bytestream.ByteStream
	status int
}

func (m *PlayerStatus) Decode(ctx *packets.Context) error {
	m.status = m.bs.ReadVInt()
	return nil
}

func (m *PlayerStatus) Process(ctx *packets.Context) error { return nil }

type GetLeaderboard struct {
	bs              *bytestream.ByteStream
	isLocal         int
	leaderboardType int
	targetBrawler   [2]int
}

func (m *GetLeaderboard) Decode(ctx *packets.Context) error {
	m.isLocal = m.bs.ReadVInt()
	m.leaderboardType = m.bs.ReadVInt()
	m.targetBrawler = m.bs.ReadDataReference()
	return nil
}

func (m *GetLeaderboard) Process(ctx *packets.Context) error {
	p := ctx.Player
	db, _ := ctx.EnsureDB()
	f := &LeaderboardFields{LeaderboardType: m.leaderboardType, IsLocal: m.isLocal, TargetBrawler: m.targetBrawler}
	switch m.leaderboardType {
	case 0:
		all := db.GetAllPlayers()
		entries := []map[string]any{}
		for _, player := range all {
			if ub, ok := player["unlocked_brawlers"].(map[string]any); ok {
				if bd, ok := ub[itoa(m.targetBrawler[1])].(map[string]any); ok && asInt(bd["Trophies"]) > 0 {
					entries = append(entries, player)
				}
			}
		}
		sortByBrawlerTrophy(entries, m.targetBrawler[1])
		if m.isLocal != 0 {
			entries = filterByRegion(entries, p.Region)
		}
		f.Entries = entries
	case 1:
		entries := db.GetAllPlayers()
		sortByTrophy(entries)
		if m.isLocal != 0 {
			entries = filterByRegion(entries, p.Region)
		}
		f.Entries = entries
	case 2:
		_, clubs := db.CountClubs(1, 100, 2, 200)
		entries := []map[string]any{}
		for _, club := range clubs {
			entries = append(entries, club["info"].(map[string]any))
		}
		sortByClubTrophy(entries)
		if m.isLocal != 0 {
			entries = filterByRegion(entries, p.Region)
		}
		f.Entries = entries
	}
	return SendLeaderboard(ctx, f)
}

type AskForBattleEnd struct {
	bs     *bytestream.ByteStream
	fields *battle.BattleFields
}

func (m *AskForBattleEnd) Decode(ctx *packets.Context) error {
	p := ctx.Player
	f := &battle.BattleFields{}
	f.IsInRealGame = p.TutorialState == 2
	f.Victory = m.bs.ReadVInt()
	f.Result = m.bs.ReadVInt()
	f.Rank = m.bs.ReadVInt()
	eventSlotThing := m.bs.ReadVInt()
	m.bs.ReadVInt()
	db, _ := ctx.EnsureDB()
	eventData := db.LoadEvents(1)
	if eventData != nil {
		info := eventData["info"].(map[string]any)
		events := info["events"].(map[string]any)
		if eventSlotThing == 4 && p.LastEventTimeStamp != asInt64(events[itoa(eventSlotThing-1)].(map[string]any)["TimeStamp"]) {
			eventData = db.LoadEvents(2)
			info = eventData["info"].(map[string]any)
			events = info["events"].(map[string]any)
		}
		if ev, ok := events[itoa(eventSlotThing-1)].(map[string]any); ok {
			mapid := asInt(ev["ID"])
			f.GameMode = getGameModeVariationBattleEnd(mapid)
		}
	}
	f.HeroesCount = m.bs.ReadVInt()
	f.Heroes = make([]battle.Hero, 0, f.HeroesCount)
	for i := 0; i < f.HeroesCount; i++ {
		h := battle.Hero{}
		h.ID = m.bs.ReadDataReference()
		h.SkinID = m.bs.ReadDataReference()
		h.Team = m.bs.ReadVInt()
		h.IsPlayer = m.bs.ReadBoolean()
		h.Name = m.bs.ReadString()
		if i == 0 {
			h.LowID = p.LowID
		}
		f.Heroes = append(f.Heroes, h)
	}
	if len(f.Heroes) > 0 {
		key := itoa(f.Heroes[0].ID[1])
		if bd := p.UnlockedBrawlers.Get(key); bd != nil {
			f.Heroes[0].Trophies = bd.Trophies
			spb := 1
			if bd.StarPower == 0 {
				spb = 1
			} else {
				spb = 2
			}
			f.Heroes[0].PowerLevel = bd.PowerLevel + spb
		}
	}
	f.ReceiveTime = nowUnix()
	m.fields = f
	return nil
}

func (m *AskForBattleEnd) Process(ctx *packets.Context) error {
	p := ctx.Player
	if m.fields.ReceiveTime-float64(p.LastRecieved) < 10 {
		return nil
	}
	p.LastRecieved = int(m.fields.ReceiveTime)
	if m.fields.HeroesCount != 6 && m.fields.HeroesCount != 10 {
		return nil
	}
	return SendBattleResult(ctx, m.fields)
}

type CancelMatchMaking struct{ bs *bytestream.ByteStream }

func (m *CancelMatchMaking) Decode(ctx *packets.Context) error { return nil }

func (m *CancelMatchMaking) Process(ctx *packets.Context) error {
	return SendMatchMakingCancelled(ctx)
}

type GoHome struct{ bs *bytestream.ByteStream }

func (m *GoHome) Decode(ctx *packets.Context) error { return nil }

func (m *GoHome) Process(ctx *packets.Context) error {
	p := ctx.Player
	if p.TutorialState < 2 {
		p.TutorialState += 1
	}
	db, _ := ctx.EnsureDB()
	db.ReplaceValue("tutorialState", p.TutorialState)
	return SendOwnHomeData(ctx)
}

type OnPlay struct {
	bs     *bytestream.ByteStream
	fields map[string]int
}

func (m *OnPlay) Decode(ctx *packets.Context) error {
	m.fields = map[string]int{}
	m.fields["Brawler"] = m.bs.ReadDataReference()[1]
	m.fields["Unk"] = m.bs.ReadVInt()
	m.fields["MapIndex"] = m.bs.ReadVInt()
	m.fields["Unk1"] = m.bs.ReadVInt()
	m.fields["Unk2"] = m.bs.ReadVInt()
	m.fields["Unk3"] = m.bs.ReadVInt()
	return nil
}

func (m *OnPlay) Process(ctx *packets.Context) error {
	return SendMatchMakingStatus(ctx)
}

type HomeBattleReplay struct{ bs *bytestream.ByteStream }

func (m *HomeBattleReplay) Decode(ctx *packets.Context) error { return nil }

func (m *HomeBattleReplay) Process(ctx *packets.Context) error {
	return SendBattleLog(ctx)
}

type PlayAgain struct{ bs *bytestream.ByteStream }

func (m *PlayAgain) Decode(ctx *packets.Context) error { return nil }

func (m *PlayAgain) Process(ctx *packets.Context) error {
	return SendPlayAgainStatus(ctx)
}

type AnalyticsEvent struct {
	bs      *bytestream.ByteStream
	string1 string
	string2 string
}

func (m *AnalyticsEvent) Decode(ctx *packets.Context) error {
	m.string1 = m.bs.ReadString()
	m.string2 = m.bs.ReadString()
	return nil
}

func (m *AnalyticsEvent) Process(ctx *packets.Context) error { return nil }

type SetDeviceToken struct{ bs *bytestream.ByteStream }

func (m *SetDeviceToken) Decode(ctx *packets.Context) error {
	m.bs.ReadBytes(m.bs.ReadInt())
	m.bs.ReadInt()
	return nil
}

func (m *SetDeviceToken) Process(ctx *packets.Context) error { return nil }

type ChangeAvatarName struct {
	bs       *bytestream.ByteStream
	username string
	state    int
}

func (m *ChangeAvatarName) Decode(ctx *packets.Context) error {
	m.username = m.bs.ReadString()
	m.state = m.bs.ReadVInt()
	return nil
}

func (m *ChangeAvatarName) Process(ctx *packets.Context) error {
	if m.username != "" {
		if len(m.username) >= 2 && len(m.username) <= 20 {
			ctx.Player.Name = m.username
			return SendChangeAvatarNameCommand(ctx, m.state)
		}
	}
	return SendAvatarNameChangeFailed(ctx)
}

func filterByRegion(entries []map[string]any, region string) []map[string]any {
	out := make([]map[string]any, 0, len(entries))
	for _, e := range entries {
		if asString(e["region"]) == region {
			out = append(out, e)
		}
	}
	return out
}

func sortByBrawlerTrophy(entries []map[string]any, brawler int) {
	key := strconv.Itoa(brawler)
	insertionSort(entries, func(a, b map[string]any) bool {
		return brawlerTrophy(a, key) > brawlerTrophy(b, key)
	})
}

func sortByTrophy(entries []map[string]any) {
	insertionSort(entries, func(a, b map[string]any) bool {
		return asInt(a["trophies"]) > asInt(b["trophies"])
	})
}

func sortByClubTrophy(entries []map[string]any) {
	insertionSort(entries, func(a, b map[string]any) bool {
		return asInt(a["trophies"]) > asInt(b["trophies"])
	})
}

func insertionSort(entries []map[string]any, less func(a, b map[string]any) bool) {
	for i := 1; i < len(entries); i++ {
		for j := i; j > 0 && less(entries[j], entries[j-1]); j-- {
			entries[j], entries[j-1] = entries[j-1], entries[j]
		}
	}
}

func brawlerTrophy(player map[string]any, key string) int {
	if ub, ok := player["unlocked_brawlers"].(map[string]any); ok {
		if bd, ok := ub[key].(map[string]any); ok {
			return asInt(bd["Trophies"])
		}
	}
	return 0
}

func getGameModeVariationBattleEnd(location int) int {
	switch logicGameModeString(location) {
	case "CoinRush":
		return 0
	case "AttackDefend":
		return 0
	case "BossFight":
		return 4
	case "BountyHunter":
		return 0
	case "Artifact":
		return 0
	case "LaserBall":
		return 0
	case "BattleRoyale":
		return 2
	case "BattleRoyaleTeam":
		return 5
	case "Survival":
		return 4
	}
	return -1
}

func asInt64(v any) int64 {
	switch t := v.(type) {
	case float64:
		return int64(t)
	case int:
		return int64(t)
	case int64:
		return t
	}
	return 0
}
