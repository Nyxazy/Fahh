package jsonutil

import (
	"bytes"
	"encoding/json"
)

func OrderedKeysAtPath(data []byte, path ...string) []string {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	tok, err := dec.Token()
	if err != nil {
		return nil
	}
	if d, ok := tok.(json.Delim); !ok || d != '{' {
		return nil
	}
	current := collectObject(dec)
	for _, p := range path {
		v, ok := current[p]
		if !ok {
			return nil
		}
		m, ok := v.(orderedMap)
		if !ok {
			return nil
		}
		current = m
	}
	keys := make([]string, 0, len(current))
	for k := range current {
		keys = append(keys, k)
	}
	return keys
}

type orderedMap map[string]any

func collectObject(dec *json.Decoder) orderedMap {
	m := orderedMap{}
	for dec.More() {
		t, err := dec.Token()
		if err != nil {
			return m
		}
		key, _ := t.(string)
		v := readValue(dec)
		m[key] = v
	}
	_, _ = dec.Token()
	return m
}

func readValue(dec *json.Decoder) any {
	tok, err := dec.Token()
	if err != nil {
		return nil
	}
	if d, ok := tok.(json.Delim); ok {
		if d == '{' {
			return collectObject(dec)
		}
		if d == '[' {
			arr := []any{}
			for dec.More() {
				arr = append(arr, readValue(dec))
			}
			_, _ = dec.Token()
			return arr
		}
	}
	return tok
}
