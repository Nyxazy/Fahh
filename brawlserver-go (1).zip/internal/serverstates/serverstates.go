package serverstates

import "sync"

type States struct {
	mu               sync.RWMutex
	Maintenance      bool
	MaintenanceTime  int
	BannedIps        []string
	BannedAccountIds []int64
	Running          bool

	Player any
}

func New() *States {
	return &States{
		Maintenance:      false,
		MaintenanceTime:  3600,
		BannedIps:        []string{},
		BannedAccountIds: []int64{},
		Running:          true,
		Player:           true,
	}
}

func (s *States) IsRunning() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.Running
}

func (s *States) SetRunning(v bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Running = v
}

func (s *States) IsMaintenance() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.Maintenance
}

func (s *States) SetMaintenance(v bool) {
	s.mu.Lock()
	s.Maintenance = v
	s.mu.Unlock()
}
