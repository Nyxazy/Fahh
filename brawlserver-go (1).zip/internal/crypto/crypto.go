package crypto

import (
	"crypto/rand"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"

	"golang.org/x/crypto/blake2b"
	"golang.org/x/crypto/curve25519"
	"golang.org/x/crypto/nacl/box"
	"golang.org/x/crypto/nacl/secretbox"
)

const NonceSize = 24

const KeySize = 32

type Nonce struct {
	value [NonceSize]byte
}

func NewNonce(nonce, clientKey, serverKey []byte) *Nonce {
	n := &Nonce{}
	if len(clientKey) == 0 {
		if len(nonce) > 0 {
			copy(n.value[:], nonce)
		} else {
			_, _ = rand.Read(n.value[:])
		}
		return n
	}
	h, _ := blake2b.New(NonceSize, nil)
	if len(nonce) > 0 {
		h.Write(nonce)
	}
	h.Write(clientKey)
	h.Write(serverKey)
	copy(n.value[:], h.Sum(nil))
	return n
}

func (n *Nonce) Bytes() []byte { return n.value[:] }

func (n *Nonce) Len() int { return NonceSize }

func (n *Nonce) Increment() {
	v := binary.LittleEndian.Uint64(n.value[0:8])

	const add = uint64(2)
	sum, carry := bitsAdd64(v, add)
	binary.LittleEndian.PutUint64(n.value[0:8], sum)
	for i := 1; carry != 0 && i < 3; i++ {
		off := i * 8
		cur := binary.LittleEndian.Uint64(n.value[off : off+8])
		sum, carry = bitsAdd64(cur, carry)
		binary.LittleEndian.PutUint64(n.value[off:off+8], sum)
	}
}

func bitsAdd64(a, b uint64) (uint64, uint64) {
	r := a + b
	if r < a {
		return r, 1
	}
	return r, 0
}

type Crypto struct {
	Authenticated bool

	serverKey [KeySize]byte
	clientSk  [KeySize]byte
	clientPk  [KeySize]byte

	s [KeySize]byte

	sessionKey [24]byte

	decryptNonce *Nonce
	encryptNonce *Nonce

	sharedEn [KeySize]byte

	publicKey [KeySize]byte

	handshakeNonce *Nonce
}

func New() *Crypto {
	c := &Crypto{}

	sk, _ := hex.DecodeString("03BBE171010D8F928E7B3B71773CCBEF75AE4B02E6D7B11BC760ED3AE853C839")
	copy(c.serverKey[:], sk)

	csk, _ := hex.DecodeString("BB14D6FD2B7C9823EAEDB4338CB7237F61E422D23C4977F74ADA052702C0C62D")
	copy(c.clientSk[:], csk)

	curve25519.ScalarBaseMult(&c.clientPk, &c.clientSk)

	sess, _ := hex.DecodeString("1359D8134D19F6FF76E7717BB09D6C0C81E729289B09C3FC")
	copy(c.sessionKey[:], sess)

	rn := make([]byte, NonceSize)
	_, _ = rand.Read(rn)
	c.encryptNonce = NewNonce(rn, nil, nil)

	_, _ = rand.Read(c.sharedEn[:])
	return c
}

func (c *Crypto) ClientPk() [KeySize]byte { return c.clientPk }

func (c *Crypto) Decrypt(packetID int, payload []byte) ([]byte, error) {
	switch packetID {
	case 10100:
		return payload, nil

	case 10101:
		c.Authenticated = false
		if !bytesEqual(payload[:32], c.clientPk[:]) {
			return nil, fmt.Errorf("cryptography error: client pk mismatch (msg %d)", packetID)
		}
		copy(c.publicKey[:], payload[:32])
		payload = payload[32:]
		c.handshakeNonce = NewNonce(nil, c.clientPk[:], c.serverKey[:])

		box.Precompute(&c.s, &c.serverKey, &c.clientSk)

		decrypted, ok := secretbox.Open(nil, payload, &c.handshakeNonce.value, &c.s)
		if !ok {
			return nil, errors.New("secretbox_open failed for login handshake")
		}
		copy(c.sessionKey[:], decrypted[0:24])
		c.decryptNonce = NewNonce(decrypted[24:48], nil, nil)
		return decrypted[48:], nil

	default:
		if c.decryptNonce == nil {
			return payload, nil
		}
		c.decryptNonce.Increment()
		decrypted, ok := secretbox.Open(nil, payload, c.decryptNonce.BytesPtr(), &c.sharedEn)
		if !ok {
			return nil, errors.New("secretbox_open failed")
		}
		return decrypted, nil
	}
}

func (c *Crypto) Encrypt(packetID int, payload []byte) ([]byte, error) {
	if packetID == 20100 || packetID == 20103 {
		return payload, nil
	}
	if packetID == 20104 {
		nonce := NewNonce(c.decryptNonce.Bytes(), c.clientPk[:], c.serverKey[:])
		buf := make([]byte, 0, NonceSize+KeySize+len(payload))
		buf = append(buf, c.encryptNonce.Bytes()...)
		buf = append(buf, c.sharedEn[:]...)
		buf = append(buf, payload...)
		sealed := secretbox.Seal(nil, buf, nonce.BytesPtr(), &c.s)
		return sealed, nil
	}
	c.encryptNonce.Increment()
	sealed := secretbox.Seal(nil, payload, c.encryptNonce.BytesPtr(), &c.sharedEn)
	return sealed, nil
}

func (n *Nonce) BytesPtr() *[NonceSize]byte { return &n.value }

func bytesEqual(a, b []byte) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}
