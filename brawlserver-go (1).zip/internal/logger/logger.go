package logger

import (
	"fmt"
	"log"
	"os"
	"sync"
)

var (
	once    sync.Once
	fileLog *log.Logger
)

func initFile() {
	f, err := os.OpenFile("errors.log", os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0644)
	if err != nil {
		return
	}
	fileLog = log.New(f, "", log.LstdFlags)
}

func Info(v ...any) {
	fmt.Println(append([]any{"[INFO]"}, v...)...)
}

func Error(message any) {
	once.Do(initFile)
	fmt.Println("[ERROR]", message)
	if fileLog != nil {
		fileLog.Println(message)
	}
}

func Warning(message any) {
	once.Do(initFile)
	fmt.Println("[WARNING]", message)
}

func Infof(format string, v ...any) {
	Info(fmt.Sprintf(format, v...))
}

func Errorf(format string, v ...any) {
	Error(fmt.Sprintf(format, v...))
}

func Warningf(format string, v ...any) {
	Warning(fmt.Sprintf(format, v...))
}
