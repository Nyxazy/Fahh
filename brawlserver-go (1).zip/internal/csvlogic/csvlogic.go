package csvlogic

import (
	"embed"
	"encoding/csv"
	"strings"
)

//go:embed assets/*.csv
var csvFS embed.FS

func readCsv(name string) [][]string {
	f, err := csvFS.Open("assets/" + name)
	if err != nil {
		return nil
	}
	defer f.Close()
	r := csv.NewReader(f)
	r.FieldsPerRecord = -1
	r.LazyQuotes = true
	rows, err := r.ReadAll()
	if err != nil || len(rows) <= 2 {
		return nil
	}
	return rows[2:]
}

func cell(row []string, idx int) string {
	if idx < len(row) {
		return row[idx]
	}
	return ""
}

func lower(s string) string { return strings.ToLower(s) }

func GetBrawlersID() []int {
	rows := readCsv("characters.csv")
	out := []int{}
	for i, row := range rows {
		if cell(row, 20) == "Hero" && lower(cell(row, 2)) != "true" && lower(cell(row, 1)) != "true" {
			out = append(out, i)
		}
	}
	return out
}

func GetBrawlerName(brawlerID int) string {
	rows := readCsv("cards.csv")
	idx := brawlerID - 1
	if idx < 0 || idx >= len(rows) {
		return ""
	}
	return cell(rows[idx], 0)
}

func GetBrawlerByName(name string) int {
	rows := readCsv("characters.csv")
	for i, row := range rows {
		if cell(row, 0) == name {
			return i
		}
	}
	return 0
}

func GetSpgID() []int {
	rows := readCsv("cards.csv")
	out := []int{}
	for i, row := range rows {
		if lower(cell(row, 5)) == "4" || lower(cell(row, 5)) == "5" {
			out = append(out, i)
		}
	}
	return out
}

func GetBrawlerUnlock() []int {
	rows := readCsv("cards.csv")
	out := []int{}
	for i, row := range rows {
		if lower(cell(row, 4)) == "0" {
			out = append(out, i)
		}
	}
	return out
}

func GetBrawlerStarPower(char int) int {
	rows := readCsv("characters.csv")
	if char >= len(rows) {
		return 0
	}
	name := cell(rows[char], 0)
	cards := readCsv("cards.csv")
	for i, row := range cards {
		if cell(row, 3) == name && strings.TrimSpace(cell(row, 4)) == "4" {
			return i
		}
	}
	return 0
}

func GetBrawlerRarity(cardID int) string {
	rows := readCsv("cards.csv")
	idx := cardID - 1
	if idx < 0 || idx >= len(rows) {
		return ""
	}
	return cell(rows[idx], 10)
}

func GetBrawlerUnlockByCharacter(char int) int {
	rows := readCsv("characters.csv")
	if char >= len(rows) {
		return 0
	}
	name := cell(rows[char], 0)
	cards := readCsv("cards.csv")
	for i, row := range cards {
		if cell(row, 3) == name && strings.TrimSpace(cell(row, 4)) == "0" {
			return i
		}
	}
	return 0
}

func GetSkinsID() []int {
	rows := readCsv("skins.csv")
	out := []int{}
	for i, row := range rows {
		if cell(row, 2) != "" {
			out = append(out, i)
		}
	}
	return out
}

func GetBrawler(skinID int) int {
	rows := readCsv("skins.csv")
	if skinID >= len(rows) {
		return 0
	}
	target := cell(rows[skinID], 2)
	chars := readCsv("characters.csv")
	for i, row := range chars {
		if cell(row, 0) == target {
			return i
		}
	}
	return 0
}

func defaultSkinNames() []string {
	rows := readCsv("characters.csv")
	out := []string{}
	for _, row := range rows {
		out = append(out, cell(row, 22))
	}
	return out
}

func GetNonDefaultSkins() []int {
	defaults := defaultSkinNames()
	dset := map[string]bool{}
	for _, d := range defaults {
		dset[d] = true
	}
	rows := readCsv("skins.csv")
	out := []int{}
	for i, row := range rows {
		if !dset[cell(row, 0)] && cell(row, 2) != "" {
			out = append(out, i)
		}
	}
	return out
}

func GetSkinPrice(skinID int) string {
	rows := readCsv("skins.csv")
	if skinID >= len(rows) {
		return "0"
	}
	return cell(rows[skinID], 4)
}

func GetIsDefaultSkin(skinID int) bool {
	defaults := defaultSkinNames()
	rows := readCsv("skins.csv")
	if skinID >= len(rows) {
		return false
	}
	name := cell(rows[skinID], 0)
	for _, d := range defaults {
		if d == name {
			return true
		}
	}
	return false
}

func GetGameModeString(gameModeID int) string {
	rows := readCsv("locations.csv")
	if gameModeID < 0 || gameModeID >= len(rows) {
		return ""
	}
	return cell(rows[gameModeID], 14)
}

func GetAllLocations() []int {
	rows := readCsv("locations.csv")
	out := []int{}
	for i, row := range rows {
		if lower(cell(row, 1)) != "true" {
			out = append(out, i)
		}
	}
	return out
}

func GetAllLocationsWithGamemode(gamemode string) []int {
	rows := readCsv("locations.csv")
	out := []int{}
	for i, row := range rows {
		if lower(cell(row, 1)) != "true" && cell(row, 14) == gamemode {
			out = append(out, i)
		}
	}
	return out
}

func GetAllLocationsWithException(gamemode []string) []int {
	excl := map[string]bool{}
	for _, g := range gamemode {
		excl[g] = true
	}
	rows := readCsv("locations.csv")
	out := []int{}
	for i, row := range rows {
		if lower(cell(row, 1)) != "true" && !excl[cell(row, 14)] {
			out = append(out, i)
		}
	}
	return out
}

func GetAllThumbnails() []int {
	rows := readCsv("player_thumbnails.csv")
	out := []int{}
	for i := range rows {
		out = append(out, i)
	}
	return out
}

func GetRequiredTrophiesForThumbnail(id int) int {
	rows := readCsv("player_thumbnails.csv")
	if id < 0 || id >= len(rows) {
		return 0
	}
	return atoiSafe(cell(rows[id], 2))
}

func GetRequiredExpForThumbnail(id int) int {
	rows := readCsv("player_thumbnails.csv")
	if id < 0 || id >= len(rows) {
		return 0
	}
	return atoiSafe(cell(rows[id], 1))
}

func GetRequiredBrawlerForThumbnail(id int) string {
	rows := readCsv("player_thumbnails.csv")
	if id < 0 || id >= len(rows) {
		return "0"
	}
	return cell(rows[id], 4)
}

func atoiSafe(s string) int {
	n := 0
	neg := false
	i := 0
	if len(s) > 0 && s[0] == '-' {
		neg = true
		i = 1
	}
	for ; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			break
		}
		n = n*10 + int(s[i]-'0')
	}
	if neg {
		return -n
	}
	return n
}
