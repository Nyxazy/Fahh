package csvlogic

import (
	"encoding/json"
	"os"
	"reflect"
	"testing"
)

func TestCsvLogicFidelity(t *testing.T) {
	data, err := os.ReadFile("/tmp/py_csv.json")
	if err != nil {
		t.Skip("run verify_py/csvlogic_ref.py first")
	}
	var py map[string]any
	if err := json.Unmarshal(data, &py); err != nil {
		t.Fatal(err)
	}
	check := func(name string, got []int) {
		exp := toIntSlice(py[name])
		if !reflect.DeepEqual(got, exp) {
			t.Errorf("%s mismatch\n go=%v\n py =%v", name, got, exp)
		} else {
			t.Logf("%s OK (%d entries)", name, len(got))
		}
	}
	check("brawlers_id", GetBrawlersID())
	check("spg_id", GetSpgID())
	check("brawler_unlock", GetBrawlerUnlock())
	check("skins_id", GetSkinsID())
	check("all_locations", GetAllLocations())
	check("non_default_skins", GetNonDefaultSkins())
	check("thumbs", GetAllThumbnails())
	if py["gm7"] != GetGameModeString(7) {
		t.Errorf("gm7 go=%s py=%v", GetGameModeString(7), py["gm7"])
	} else {
		t.Logf("gm7 OK (%s)", GetGameModeString(7))
	}
	if py["rarity3"] != GetBrawlerRarity(3) {
		t.Errorf("rarity3 go=%s py=%v", GetBrawlerRarity(3), py["rarity3"])
	} else {
		t.Logf("rarity3 OK (%s)", GetBrawlerRarity(3))
	}
}

func toIntSlice(v any) []int {
	a, ok := v.([]any)
	if !ok {
		return nil
	}
	out := make([]int, len(a))
	for i, x := range a {
		if f, ok := x.(float64); ok {
			out[i] = int(f)
		}
	}
	return out
}
