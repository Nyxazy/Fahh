package server

import (
	"errors"
	"io"
	"net"
	"time"

	"brawlserver/internal/crypto"
	"brawlserver/internal/logger"
	"brawlserver/internal/logic"
	"brawlserver/internal/packets"
	"brawlserver/internal/serverstates"
)

type Server struct {
	ip     string
	port   int
	states *serverstates.States
	ln     net.Listener
}

func New(ip string, port int, states *serverstates.States) *Server {
	return &Server{ip: ip, port: port, states: states}
}

func (s *Server) Start() error {
	ln, err := net.Listen("tcp", s.ip+":"+itoa(s.port))
	if err != nil {
		return err
	}
	s.ln = ln
	logger.Infof("Server started! Ip: %s, Port: %d", s.ip, s.port)
	go s.acceptLoop()
	return nil
}

func (s *Server) acceptLoop() {
	for s.states.IsRunning() {
		conn, err := s.ln.Accept()
		if err != nil {
			if !s.states.IsRunning() {
				return
			}
			logger.Errorf("Error accepting client: %v", err)
			continue
		}
		addr := conn.RemoteAddr().String()
		logger.Infof("New connection! Ip: %s", addr)
		go s.handleClient(conn, addr)
	}
}

func (s *Server) Stop() {
	s.states.SetRunning(false)
	if s.ln != nil {
		s.ln.Close()
	}
	logger.Info("Server stopped.")
}

func (s *Server) handleClient(conn net.Conn, addr string) {
	defer conn.Close()
	c := crypto.New()
	player := logic.NewPlayer()
	ctx := packets.NewContext(conn, player, c, s.states)

	lastPacket := time.Now()
	for s.states.IsRunning() {
		header := make([]byte, 7)
		n, err := io.ReadFull(conn, header)
		if err != nil {
			if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
				break
			}
			if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
				if time.Since(lastPacket) > 10*time.Second {
					break
				}
				continue
			}
			logger.Infof("Error reading from client %s: %v", addr, err)
			break
		}
		_ = n

		packetID := int(uint16(header[0])<<8 | uint16(header[1]))
		length := int(header[2])<<16 | int(header[3])<<8 | int(header[4])

		data := make([]byte, length)
		if length > 0 {
			if _, err := io.ReadFull(conn, data); err != nil {
				logger.Infof("Error reading body from %s: %v", addr, err)
				break
			}
		}

		payload, err := c.Decrypt(packetID, data)
		if err != nil {
			logger.Infof("Decrypt error from %s: %v", addr, err)
			break
		}

		lastPacket = time.Now()
		entry, ok := packets.Lookup(packetID)
		if !ok {
			logger.Infof("Packet not handled! Id: %d", packetID)
			if time.Since(lastPacket) > 10*time.Second {
				break
			}
			continue
		}

		msg := entry.New(ctx, payload)
		if err := msg.Decode(ctx); err != nil {
			logger.Infof("Decode error (%d) from %s: %v", packetID, addr, err)
		}
		if err := msg.Process(ctx); err != nil {
			logger.Infof("Process error (%d) from %s: %v", packetID, addr, err)
		}

		if time.Since(lastPacket) > 10*time.Second {
			break
		}
	}

	logger.Infof("Ip: %s disconnected!", addr)
	if db, err := ctx.EnsureDB(); err == nil {
		player.PlayerStatus = 0
		db.ReplaceValue("player_status", player.PlayerStatus)
		player.LastConnectionTime = float64(time.Now().Unix())
		db.ReplaceValue("last_connection_time", player.LastConnectionTime)
	}
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	neg := i < 0
	if neg {
		i = -i
	}
	var buf [12]byte
	pos := len(buf)
	for i > 0 {
		pos--
		buf[pos] = byte('0' + i%10)
		i /= 10
	}
	if neg {
		pos--
		buf[pos] = '-'
	}
	return string(buf[pos:])
}
