package database

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"time"

	_ "modernc.org/sqlite"

	"brawlserver/internal/csvlogic"
	"brawlserver/internal/logic"
)

type DataBase struct {
	db            *sql.DB
	Player        *logic.Player
	PlayerInfo    map[string]any
	GameroomInfo  any
	Slot          int
	PlayerCount   int
	Map           int
	MatchmakeData map[string]any
}

var shared *sql.DB

func New(p *logic.Player) (*DataBase, error) {
	if shared == nil {
		conn, err := sql.Open("sqlite", "database.db")
		if err != nil {
			return nil, err
		}
		shared = conn
	}
	d := &DataBase{db: shared, Player: p}
	if err := d.initTables(); err != nil {
		return nil, err
	}
	return d, nil
}

func (d *DataBase) initTables() error {
	stmts := []string{
		`CREATE TABLE IF NOT EXISTS Matchmake (slot INTEGER PRIMARY KEY, data TEXT)`,
		`CREATE TABLE IF NOT EXISTS PlayerOffers (PlayerToken TEXT PRIMARY KEY, Offers TEXT NOT NULL)`,
		`CREATE TABLE IF NOT EXISTS Players (token TEXT PRIMARY KEY, data TEXT)`,
		`CREATE TABLE IF NOT EXISTS Gamerooms (room_id INTEGER PRIMARY KEY, data TEXT)`,
		`CREATE TABLE IF NOT EXISTS Clubs (club_id INTEGER PRIMARY KEY, data TEXT)`,
		`CREATE TABLE IF NOT EXISTS ClubChats (club_id INTEGER PRIMARY KEY, data TEXT)`,
		`CREATE TABLE IF NOT EXISTS GameroomChats (room_id INTEGER PRIMARY KEY, data TEXT)`,
		`CREATE TABLE IF NOT EXISTS Events (state INTEGER PRIMARY KEY, data TEXT)`,
	}
	for _, s := range stmts {
		if _, err := d.db.Exec(s); err != nil {
			return err
		}
	}
	return d.seedEvents()
}

func (d *DataBase) seedEvents() error {
	var count int
	if err := d.db.QueryRow("SELECT COUNT(*) FROM Events WHERE state = ?", 1).Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	events := map[string]any{
		"info": map[string]any{
			"events": map[string]any{
				"0": map[string]any{"ID": 7, "Tokens": 10, "TimeStamp": time.Now().Unix(), "Modifier": map[string]int{"0": 1}},
				"1": map[string]any{"ID": 32, "Tokens": 10, "TimeStamp": time.Now().Unix(), "Modifier": map[string]int{"0": 1}},
				"2": map[string]any{"ID": 0, "Tokens": 10, "TimeStamp": time.Now().Unix(), "Modifier": map[string]int{"0": 1}},
				"3": map[string]any{"ID": 25, "Tokens": 10, "TimeStamp": time.Now().Unix(), "Modifier": map[string]int{"0": 1}},
				"4": map[string]any{"ID": 38, "Tokens": 10, "TimeStamp": time.Now().Unix(), "Modifier": map[string]int{"0": 1}},
				"5": map[string]any{"ID": 21, "Tokens": 2, "TimeStamp": time.Now().Unix(), "Modifier": map[string]int{"0": 1}},
			},
		},
	}
	out, _ := json.Marshal(events)
	if _, err := d.db.Exec("INSERT INTO Events (state, data) VALUES (?, ?)", 1, string(out)); err != nil {
		return err
	}
	d.RerollEvents()
	return nil
}

func (d *DataBase) LoadAccount() error {
	var data string
	err := d.db.QueryRow("SELECT data FROM Players WHERE token = ?", d.Player.Token).Scan(&data)
	if err != nil {
		return err
	}
	return json.Unmarshal([]byte(data), d.Player)
}

func (d *DataBase) GetPlayerId() error {
	var n int
	if err := d.db.QueryRow("SELECT COUNT(*) FROM Players").Scan(&n); err != nil {
		return err
	}
	d.Player.LowID = n + 1
	return nil
}

func (d *DataBase) CreateAccount() error {
	var count int
	if err := d.db.QueryRow("SELECT COUNT(*) FROM Players WHERE token = ?", d.Player.Token).Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return fmt.Errorf("account with token %s already exists", d.Player.Token)
	}
	data, err := json.Marshal(d.Player)
	if err != nil {
		return err
	}
	_, err = d.db.Exec("INSERT INTO Players (token, data) VALUES (?, ?)", d.Player.Token, string(data))
	return err
}

func (d *DataBase) SavePlayer() error {
	data, err := json.Marshal(d.Player)
	if err != nil {
		return err
	}
	_, err = d.db.Exec("UPDATE Players SET data = ? WHERE token = ?", string(data), d.Player.Token)
	return err
}

func (d *DataBase) GetAllPlayers() []map[string]any {
	rows, err := d.db.Query("SELECT data FROM Players")
	if err != nil {
		return nil
	}
	defer rows.Close()
	var out []map[string]any
	for rows.Next() {
		var data string
		if rows.Scan(&data) == nil {
			var m map[string]any
			if json.Unmarshal([]byte(data), &m) == nil {
				out = append(out, m)
			}
		}
	}
	return out
}

func (d *DataBase) GetSpecifiedPlayers(tokens []string) []map[string]any {
	if len(tokens) == 0 {
		return nil
	}
	placeholders := ""
	args := make([]any, 0, len(tokens))
	for i, t := range tokens {
		if i > 0 {
			placeholders += ","
		}
		placeholders += "?"
		args = append(args, t)
	}
	q := fmt.Sprintf("SELECT data FROM Players WHERE token IN (%s)", placeholders)
	rows, err := d.db.Query(q, args...)
	if err != nil {
		return nil
	}
	defer rows.Close()
	out := make([]map[string]any, 0, len(tokens))
	for rows.Next() {
		var data string
		if rows.Scan(&data) == nil {
			var m map[string]any
			if json.Unmarshal([]byte(data), &m) == nil {
				out = append(out, m)
			}
		}
	}
	return out
}

func (d *DataBase) GetTokenByLowId(lowID int) string {
	rows, err := d.db.Query("SELECT token, data FROM Players")
	if err != nil {
		return ""
	}
	defer rows.Close()
	for rows.Next() {
		var token, data string
		if rows.Scan(&token, &data) != nil {
			continue
		}
		var m map[string]any
		if json.Unmarshal([]byte(data), &m) == nil {
			if li, ok := m["low_id"].(float64); ok && int(li) == lowID {
				return token
			}
		}
	}
	return ""
}

func (d *DataBase) GetMemberData(token string) map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Players WHERE token = ?", token).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	json.Unmarshal([]byte(data), &m)
	return m
}

func (d *DataBase) ReplaceValue(name string, value any) error {
	d.setField(name, value)
	return d.SavePlayer()
}

func (d *DataBase) ReplaceOtherValue(name string, value any, token string) error {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Players WHERE token = ?", token).Scan(&data); err != nil {
		return err
	}
	var m map[string]any
	if err := json.Unmarshal([]byte(data), &m); err != nil {
		return err
	}
	m[name] = value
	out, _ := json.Marshal(m)
	_, err := d.db.Exec("UPDATE Players SET data = ? WHERE token = ?", string(out), token)
	return err
}

func (d *DataBase) GetSpecifiedValue(name string) any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Players WHERE token = ?", d.Player.Token).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return nil
	}
	return m[name]
}

func (d *DataBase) AppendElementToArray(name string, element any) error {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Players WHERE token = ?", d.Player.Token).Scan(&data); err != nil {
		return err
	}
	var m map[string]any
	if err := json.Unmarshal([]byte(data), &m); err != nil {
		return err
	}
	if arr, ok := m[name].([]any); ok {
		m[name] = append(arr, element)
	} else {
		m[name] = []any{element}
	}
	out, _ := json.Marshal(m)
	_, err := d.db.Exec("UPDATE Players SET data = ? WHERE token = ?", string(out), d.Player.Token)
	return err
}

func (d *DataBase) ExecuteQuery(query string, params ...any) error {
	_, err := d.db.Exec(query, params...)
	return err
}

func (d *DataBase) FetchOne(query string, params ...any) []string {
	rows, err := d.db.Query(query, params...)
	if err != nil {
		return nil
	}
	defer rows.Close()
	cols, err := rows.Columns()
	if err != nil {
		return nil
	}
	if !rows.Next() {
		return nil
	}
	raw := make([]sql.NullString, len(cols))
	ptrs := make([]any, len(cols))
	for i := range raw {
		ptrs[i] = &raw[i]
	}
	if err := rows.Scan(ptrs...); err != nil {
		return nil
	}
	out := make([]string, len(cols))
	for i, v := range raw {
		out[i] = v.String
	}
	return out
}

func (d *DataBase) FetchAll(query string, params ...any) [][]string {
	rows, err := d.db.Query(query, params...)
	if err != nil {
		return nil
	}
	defer rows.Close()
	cols, err := rows.Columns()
	if err != nil {
		return nil
	}
	var out [][]string
	for rows.Next() {
		raw := make([]sql.NullString, len(cols))
		ptrs := make([]any, len(cols))
		for i := range raw {
			ptrs[i] = &raw[i]
		}
		if err := rows.Scan(ptrs...); err != nil {
			continue
		}
		row := make([]string, len(cols))
		for i, v := range raw {
			row[i] = v.String
		}
		out = append(out, row)
	}
	return out
}

func (d *DataBase) setField(name string, value any) {
	p := d.Player
	switch name {
	case "name":
		p.Name = asString(value)
	case "low_id":
		p.LowID = asInt(value)
	case "club_id":
		p.ClubID = asInt(value)
	case "club_role":
		p.ClubRole = asInt(value)
	case "player_experience":
		p.PlayerExperience = asInt(value)
	case "gems":
		p.Gems = asInt(value)
	case "gold":
		p.Gold = asInt(value)
	case "tickets":
		p.Tickets = asInt(value)
	case "trophies":
		p.Trophies = asInt(value)
	case "highest_trophies":
		p.HighestTrophies = asInt(value)
	case "profile_icon":
		p.ProfileIcon = asInt(value)
	case "brawl_boxes":
		p.BrawlBoxes = asInt(value)
	case "big_boxes":
		p.BigBoxes = asInt(value)
	case "tokens_doubler":
		p.TokensDoublerDB = asInt(value)
	case "tokens":

	case "room_id":
		p.RoomID = asInt(value)
	case "player_status":
		p.PlayerStatus = asInt(value)
	case "region":
		p.Region = asString(value)
	case "tutorialState":
		p.TutorialState = asInt(value)
	case "trophyRoad":
		p.TrophyRoad = asInt(value)
	case "do_not_disturb":
		p.DoNotDisturb = asInt(value)
	case "brawler_id":
		p.BrawlerID = asInt(value)
	case "skin_id":
		p.SkinID = asInt(value)
	case "key_reward":
		p.KeyReward = asInt(value)
	case "trophy_reward":
		p.TrophyReward = asInt(value)
	case "star_key_reward":
		p.StarKeyReward = asInt(value)
	case "unlocked_brawlers":
		if ub, ok := value.(*logic.BrawlerMap); ok {
			p.UnlockedBrawlers = ub
		}
	case "friends":
		if f, ok := value.(map[string]int); ok {
			p.Friends = f
		}
	}
}

func (d *DataBase) GetRoomId() error {
	var n int
	if err := d.db.QueryRow("SELECT COUNT(*) FROM Gamerooms").Scan(&n); err != nil {
		return err
	}
	d.Player.RoomID = n + 1
	return nil
}

func (d *DataBase) CreateGameroom(roomType int, chatData map[string]any) error {
	p := d.Player
	players := map[string]any{
		fmt.Sprintf("%d", p.LowID): map[string]any{
			"host":         true,
			"low_id":       p.LowID,
			"name":         p.Name,
			"team":         p.Team,
			"ready":        p.IsReady,
			"status":       3,
			"brawler_id":   p.BrawlerID,
			"skin_id":      p.SkinID,
			"profile_icon": p.ProfileIcon,
		},
	}
	data := map[string]any{
		"room_id": p.RoomID,
		"info": map[string]any{
			"room_type":               roomType,
			"map_id":                  p.MapID,
			"player_count":            1,
			"advertiseToBand":         false,
			"advertiseToFriends":      false,
			"alreadyAdvertisedToBand": false,
			"players":                 players,
		},
	}
	bd, _ := json.Marshal(data)
	if _, err := d.db.Exec("INSERT INTO Gamerooms (room_id, data) VALUES (?, ?)", p.RoomID, string(bd)); err != nil {
		return err
	}
	cb, _ := json.Marshal(chatData)
	_, err := d.db.Exec("INSERT INTO GameroomChats (room_id, data) VALUES (?, ?)", p.RoomID, string(cb))
	return err
}

func (d *DataBase) JoinGameroom(roomID int) bool {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Gamerooms WHERE room_id = ?", roomID).Scan(&data); err != nil {
		return false
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return false
	}
	info := m["info"].(map[string]any)
	info["player_count"] = asInt(info["player_count"]) + 1
	players := info["players"].(map[string]any)
	p := d.Player
	players[fmt.Sprintf("%d", p.LowID)] = map[string]any{
		"host":         false,
		"low_id":       p.LowID,
		"name":         p.Name,
		"team":         p.Team,
		"ready":        p.IsReady,
		"status":       p.PlayerStatus,
		"brawler_id":   p.BrawlerID,
		"skin_id":      p.SkinID,
		"profile_icon": p.ProfileIcon,
	}
	out, _ := json.Marshal(m)
	_, err := d.db.Exec("UPDATE Gamerooms SET data = ? WHERE room_id = ?", string(out), roomID)
	return err == nil
}

func (d *DataBase) LoadGameroom() map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Gamerooms WHERE room_id = ?", d.Player.RoomID).Scan(&data); err != nil {
		d.ReplaceValue("room_id", 0)
		return map[string]any{}
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return map[string]any{}
	}
	if info, ok := m["info"].(map[string]any); ok {
		return info
	}
	return map[string]any{}
}

func (d *DataBase) GetGameroomInfo(index string) any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Gamerooms WHERE room_id = ?", d.Player.RoomID).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return nil
	}
	d.GameroomInfo = m[index]
	return d.GameroomInfo
}

func (d *DataBase) GetPlayerInfo(lowID int) map[string]any {
	data := d.FetchOne("SELECT data FROM Gamerooms WHERE room_id = ?", d.Player.RoomID)
	if data == nil {
		return nil
	}
	var m map[string]any
	if json.Unmarshal([]byte(data[0]), &m) != nil {
		return nil
	}
	info := m["info"].(map[string]any)
	players := info["players"].(map[string]any)
	d.PlayerInfo, _ = players[fmt.Sprintf("%d", lowID)].(map[string]any)
	return d.PlayerInfo
}

func (d *DataBase) UpdateGameroomPlayerInfo(lowID, roomID int, playerInfo map[string]any) {
	data := d.FetchOne("SELECT data FROM Gamerooms WHERE room_id = ?", roomID)
	if data == nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data[0]), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	players := info["players"].(map[string]any)
	players[fmt.Sprintf("%d", lowID)] = playerInfo
	out, _ := json.Marshal(m)
	d.ExecuteQuery("UPDATE Gamerooms SET data = ? WHERE room_id = ?", string(out), roomID)
}

func (d *DataBase) UpdateGameroomInfo(value any, roomID int, index string) {
	data := d.FetchOne("SELECT data FROM Gamerooms WHERE room_id = ?", roomID)
	if data == nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data[0]), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	info[index] = value
	out, _ := json.Marshal(m)
	d.ExecuteQuery("UPDATE Gamerooms SET data = ? WHERE room_id = ?", string(out), roomID)
}

func (d *DataBase) LoadGameroomRaw(roomID int) []byte {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Gamerooms WHERE room_id = ?", roomID).Scan(&data); err != nil {
		return nil
	}
	return []byte(data)
}

func (d *DataBase) RemoveGameroomPlayer(lowID, roomID int, token string) {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Gamerooms WHERE room_id = ?", roomID).Scan(&data); err != nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	players := info["players"].(map[string]any)
	key := fmt.Sprintf("%d", lowID)
	if _, ok := players[key]; ok {
		delete(players, key)
		info["player_count"] = asInt(info["player_count"]) - 1
		out, _ := json.Marshal(m)
		d.db.Exec("UPDATE Gamerooms SET data = ? WHERE room_id = ?", string(out), roomID)
		if asInt(info["player_count"]) == 0 {
			d.RemoveGameroom(roomID)
		}
	}
	d.ReplaceOtherValue("room_id", 0, token)
}

func (d *DataBase) RemoveGameroom(roomID int) {
	d.db.Exec("DELETE FROM Gamerooms WHERE room_id = ?", roomID)
	d.db.Exec("DELETE FROM GameroomChats WHERE room_id = ?", roomID)
}

func (d *DataBase) LoadRoomMessages(roomID int) map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM GameroomChats WHERE room_id = ?", roomID).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	json.Unmarshal([]byte(data), &m)
	return m
}

func (d *DataBase) GetNextGameroomKey(roomID int) int {
	var data string
	if err := d.db.QueryRow("SELECT data FROM GameroomChats WHERE room_id = ?", roomID).Scan(&data); err != nil {
		return 0
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return 0
	}
	info := m["info"].(map[string]any)
	messages := info["messages"].(map[string]any)
	maxK := -1
	for k := range messages {
		if ki := asInt(k); ki > maxK {
			maxK = ki
		}
	}
	return maxK + 1
}

func (d *DataBase) AddGameroomMsg(roomID, eventType, playerID int, playerName, msg string, event int, targetID int, targetName string) {
	var data string
	if err := d.db.QueryRow("SELECT data FROM GameroomChats WHERE room_id = ?", roomID).Scan(&data); err != nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	messages := info["messages"].(map[string]any)
	next := 0
	for k := range messages {
		if ki := asInt(k); ki > next {
			next = ki
		}
	}
	messages[fmt.Sprintf("%d", next)] = map[string]any{
		"EventType":    eventType,
		"Event":        event,
		"Tick":         next + 1,
		"PlayerID":     playerID,
		"PlayerName":   playerName,
		"Message":      msg,
		"promotedTeam": d.Player.RoomID,
		"TimeStamp":    float64(time.Now().Unix()),
		"targetID":     targetID,
		"targetName":   targetName,
	}
	out, _ := json.Marshal(m)
	d.db.Exec("UPDATE GameroomChats SET data = ? WHERE room_id = ?", string(out), roomID)
}

func (d *DataBase) CreateClub(clubID int, clubData, chatData map[string]any) error {
	bd, _ := json.Marshal(clubData)
	cb, _ := json.Marshal(chatData)
	if _, err := d.db.Exec("INSERT INTO Clubs (club_id, data) VALUES (?, ?)", clubID, string(bd)); err != nil {
		return err
	}
	_, err := d.db.Exec("INSERT INTO ClubChats (club_id, data) VALUES (?, ?)", clubID, string(cb))
	return err
}

func (d *DataBase) CountClubs(minMembers, maxMembers, clubType, maxListLength int) ([]int, []map[string]any) {
	rows, err := d.db.Query("SELECT club_id, data FROM Clubs")
	if err != nil {
		return nil, nil
	}
	defer rows.Close()
	var clubList []int
	var clubData []map[string]any
	for rows.Next() {
		var id int
		var data string
		if rows.Scan(&id, &data) != nil {
			continue
		}
		var m map[string]any
		if json.Unmarshal([]byte(data), &m) != nil {
			continue
		}
		info := m["info"].(map[string]any)
		mc := info["memberCount"].([]any)
		total := len(mc)
		if minMembers <= total && total < maxMembers && asInt(info["clubType"]) <= clubType {
			clubList = append(clubList, id)
			clubData = append(clubData, m)
			if len(clubList) == maxListLength {
				break
			}
		}
	}
	return clubList, clubData
}

func (d *DataBase) GetClubId() error {
	var n int
	if err := d.db.QueryRow("SELECT COUNT(*) FROM Clubs").Scan(&n); err != nil {
		return err
	}
	d.Player.ClubID = n + 1
	return nil
}

func (d *DataBase) LoadClub(clubID int) map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Clubs WHERE club_id = ?", clubID).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	json.Unmarshal([]byte(data), &m)
	return m
}

func (d *DataBase) AddMember(clubID int, playerToken string, action int) {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Clubs WHERE club_id = ?", clubID).Scan(&data); err != nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	switch action {
	case 0:
		d.db.Exec("DELETE FROM Clubs WHERE club_id = ?", clubID)
	case 1:
		mc := info["memberCount"].([]any)
		info["memberCount"] = append(mc, playerToken)
		out, _ := json.Marshal(m)
		d.db.Exec("UPDATE Clubs SET data = ? WHERE club_id = ?", string(out), clubID)
	case 2:
		mc := info["memberCount"].([]any)
		for i, t := range mc {
			if t == playerToken {
				info["memberCount"] = append(mc[:i], mc[i+1:]...)
				break
			}
		}
		out, _ := json.Marshal(m)
		d.db.Exec("UPDATE Clubs SET data = ? WHERE club_id = ?", string(out), clubID)
	}
}

func (d *DataBase) ReplaceClubValue(clubID int, description string, badgeID, clubType, trophiesNeeded int) {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Clubs WHERE club_id = ?", clubID).Scan(&data); err != nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	info["description"] = description
	info["clubBadge"] = badgeID
	info["clubType"] = clubType
	info["requiredTrophies"] = trophiesNeeded
	out, _ := json.Marshal(m)
	d.db.Exec("UPDATE Clubs SET data = ? WHERE club_id = ?", string(out), clubID)
}

func (d *DataBase) LoadClubMessages(clubID int) map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM ClubChats WHERE club_id = ?", clubID).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	json.Unmarshal([]byte(data), &m)
	return m
}

func (d *DataBase) GetNextKey(clubID int) int {
	var data string
	if err := d.db.QueryRow("SELECT data FROM ClubChats WHERE club_id = ?", clubID).Scan(&data); err != nil {
		return 0
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return 0
	}
	info := m["info"].(map[string]any)
	messages := info["messages"].(map[string]any)
	maxK := -1
	for k := range messages {
		if ki := asInt(k); ki > maxK {
			maxK = ki
		}
	}
	return maxK + 1
}

func (d *DataBase) AddMsg(clubID, eventType, playerID int, playerName string, role int, msg string, event int, targetID int, targetName string) {
	var data string
	if err := d.db.QueryRow("SELECT data FROM ClubChats WHERE club_id = ?", clubID).Scan(&data); err != nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	messages := info["messages"].(map[string]any)
	next := 0
	for k := range messages {
		if ki := asInt(k); ki > next {
			next = ki
		}
	}
	messages[fmt.Sprintf("%d", next)] = map[string]any{
		"EventType":    eventType,
		"Event":        event,
		"Tick":         next + 1,
		"PlayerID":     playerID,
		"PlayerName":   playerName,
		"PlayerRole":   role,
		"Message":      msg,
		"promotedTeam": d.Player.RoomID,
		"TimeStamp":    float64(time.Now().Unix()),
		"targetID":     targetID,
		"targetName":   targetName,
	}
	out, _ := json.Marshal(m)
	d.db.Exec("UPDATE ClubChats SET data = ? WHERE club_id = ?", string(out), clubID)
}

func (d *DataBase) ReplaceMessageValue(tick int, name string, value any) {
	var data string
	if err := d.db.QueryRow("SELECT data FROM ClubChats WHERE club_id = ?", d.Player.ClubID).Scan(&data); err != nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data), &m) != nil {
		return
	}
	messages := m["info"].(map[string]any)["messages"].(map[string]any)
	msg := messages[fmt.Sprintf("%d", tick-1)].(map[string]any)
	msg[name] = value
	out, _ := json.Marshal(m)
	d.db.Exec("UPDATE ClubChats SET data = ? WHERE club_id = ?", string(out), d.Player.ClubID)
}

func (d *DataBase) LoadEvents(state int) map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT data FROM Events WHERE state = ?", state).Scan(&data); err != nil {
		return nil
	}
	var m map[string]any
	json.Unmarshal([]byte(data), &m)
	return m
}

func (d *DataBase) RerollEvents() {
	rows, err := d.db.Query("SELECT state, data FROM Events WHERE state = ?", 1)
	if err != nil {
		return
	}
	defer rows.Close()
	type ev struct {
		state int
		data  string
	}
	var all []ev
	for rows.Next() {
		var st int
		var dt string
		if rows.Scan(&st, &dt) == nil {
			all = append(all, ev{st, dt})
		}
	}
	for _, e := range all {
		var event map[string]any
		if json.Unmarshal([]byte(e.data), &event) != nil {
			continue
		}
		info := event["info"].(map[string]any)
		eventData := info["events"].(map[string]any)
		now := time.Now()
		tomorrow := now.Add(24 * time.Hour)
		ts := time.Date(tomorrow.Year(), tomorrow.Month(), tomorrow.Day(), 10, 0, 0, 0, tomorrow.Location()).Unix()
		for k, dd := range eventData {
			data := dd.(map[string]any)
			data["TimeStamp"] = ts
			key := asInt(k)
			var gamemodes []int
			switch key {
			case 0:
				gamemodes = csvlogic.GetAllLocationsWithGamemode("CoinRush")
			case 1:
				gamemodes = csvlogic.GetAllLocationsWithGamemode("BattleRoyale")
			case 2:
				gamemodes = csvlogic.GetAllLocationsWithException([]string{"CoinRush", "BattleRoyale", "Survival", "BossFight", "BattleRoyaleTeam"})
			case 3:
				gamemodes = csvlogic.GetAllLocationsWithException([]string{"Survival", "BossFight"})
			default:
				gamemodes = csvlogic.GetAllLocationsWithGamemode("BattleRoyaleTeam")
			}
			if len(gamemodes) > 0 {
				data["ID"] = gamemodes[rand.Intn(len(gamemodes))]
			}
			mod := map[string]int{}
			if key != 3 && key != 5 {
				mod[fmt.Sprintf("%d", rand.Intn(5))] = 1
			} else {
				mod[fmt.Sprintf("%d", 1+rand.Intn(3))] = 10 + rand.Intn(41)
			}
			data["Modifier"] = mod
		}
		out, _ := json.Marshal(event)
		d.db.Exec("UPDATE Events SET data = ? WHERE state = ?", string(out), e.state)
	}
}

func (d *DataBase) LoadOffers(token string) map[string]any {
	var data string
	if err := d.db.QueryRow("SELECT Offers FROM PlayerOffers WHERE PlayerToken = ?", token).Scan(&data); err != nil {
		return map[string]any{}
	}
	var m map[string]any
	json.Unmarshal([]byte(data), &m)
	return m
}

func (d *DataBase) LoadPlayerOffers(token string) map[string]any {
	data := d.FetchOne("SELECT data FROM PlayerOffers WHERE PlayerToken = ?", token)
	if data == nil {
		return nil
	}
	var m map[string]any
	json.Unmarshal([]byte(data[0]), &m)
	return m
}

func (d *DataBase) CreateOffers(token string) {
	var count int
	if err := d.db.QueryRow("SELECT COUNT(*) FROM PlayerOffers WHERE PlayerToken = ?", token).Scan(&count); err != nil {
		return
	}
	_ = count
	defaults := map[string]any{}
	out, _ := json.Marshal(defaults)
	if _, err := d.db.Exec("INSERT INTO PlayerOffers (PlayerToken, Offers) VALUES (?, ?)", d.Player.Token, string(out)); err != nil {
		return
	}
	d.InitializePlayerOffers(d.Player.Token)
}

func (d *DataBase) SaveOffers(token string, offers map[string]any) error {
	out, _ := json.Marshal(offers)
	_, err := d.db.Exec(`INSERT INTO PlayerOffers (PlayerToken, Offers) VALUES (?, ?)
		ON CONFLICT(PlayerToken) DO UPDATE SET Offers = excluded.Offers`, token, string(out))
	return err
}

func (d *DataBase) InitializePlayerOffers(token string) {
	so := loadSpecialOffer()
	hasSpecial, _ := so["isEnabled"].(bool)
	unlocked := []int{}
	unlockable := csvlogic.GetBrawlersID()
	d.Player.UnlockedBrawlers.Range(func(k string, _ *logic.BrawlerData) {
		ki := asInt(k)
		unlocked = append(unlocked, ki)
		unlockable = removeInt(unlockable, ki)
	})
	notMaxed := []int{}
	for _, b := range unlocked {
		if bd := d.Player.UnlockedBrawlers.Get(fmt.Sprintf("%d", b)); bd != nil && bd.PowerPoints < 1410 {
			notMaxed = append(notMaxed, b)
		}
	}
	brawlersPrice := []int{0, 30, 80, 170, 350, 0}
	selectedRarity := 1 + rand.Intn(4)
	brawlersThing := len(notMaxed)
	if brawlersThing > 5 {
		brawlersThing = 5
	}
	targetBrawlers := randSample(notMaxed, brawlersThing)
	defaults := map[string]any{"info": map[string]any{}}
	info := defaults["info"].(map[string]any)
	for i := 0; i < 2+brawlersThing; i++ {
		powerPoints := 6 + rand.Intn(15)
		offer := buildOffer(i, selectedRarity, powerPoints, brawlersPrice, targetBrawlers)
		info[fmt.Sprintf("%d", i)] = offer
	}
	if hasSpecial {
		info["0"] = so
	}
	d.SaveOffers(token, defaults)
}

func (d *DataBase) RerollOffer(token string, i int) {
	so := loadSpecialOffer()
	hasSpecial, _ := so["isEnabled"].(bool)
	unlocked := []int{}
	unlockable := csvlogic.GetBrawlersID()
	d.Player.UnlockedBrawlers.Range(func(k string, _ *logic.BrawlerData) {
		ki := asInt(k)
		unlocked = append(unlocked, ki)
		unlockable = removeInt(unlockable, ki)
	})
	notMaxed := []int{}
	for _, b := range unlocked {
		if bd := d.Player.UnlockedBrawlers.Get(fmt.Sprintf("%d", b)); bd != nil && bd.PowerPoints < 1410 {
			notMaxed = append(notMaxed, b)
		}
	}
	brawlersPrice := []int{0, 30, 80, 170, 350, 0}
	selectedRarity := 1 + rand.Intn(4)
	brawlersThing := len(notMaxed)
	if brawlersThing > 5 {
		brawlersThing = 5
	}
	targetBrawlers := randSample(notMaxed, brawlersThing)
	newOffers := d.LoadOffers(token)
	powerPoints := 6 + rand.Intn(15)
	offer := buildOffer(i, selectedRarity, powerPoints, brawlersPrice, targetBrawlers)
	if info, ok := newOffers["info"].(map[string]any); ok {
		info[fmt.Sprintf("%d", i)] = offer
		if hasSpecial {
			info["0"] = so
		}
	}
	d.SaveOffers(token, newOffers)
}

func buildOffer(i, selectedRarity, powerPoints int, brawlersPrice, targetBrawlers []int) map[string]any {
	offerID := 4
	target := [2]int{29, firstInt(csvlogic.GetNonDefaultSkins())}
	value := 1
	amount := 1
	currency := 0
	price := 0
	switch {
	case i == 0:
		offerID, value, amount, currency, price = 4, 1, 1, 0, 0
	case i == 1:
		offerID, value, amount, currency, price = 0, 1, 1, 0, 0
		target = [2]int{0, 0}
	case i == 2:
		offerID = 2
		value = selectedRarity
		amount = 1
		currency = 0
		price = brawlersPrice[selectedRarity]
		target = [2]int{0, 0}
	default:
		offerID = 8
		tb := 0
		if i-2 < len(targetBrawlers) {
			tb = targetBrawlers[i-2]
		}
		target = [2]int{16, tb}
		value = powerPoints * 2
		amount = powerPoints
		currency = 1
		price = powerPoints * 2
	}
	ts := time.Now().Add(24 * time.Hour).Unix()
	return map[string]any{
		"OfferID": offerID, "Target": target, "Value": value, "Amount": amount,
		"Currency": currency, "Price": price, "Timer": int(ts),
		"IsOfferSeen": 0, "IsOfferPurchased": 0,
	}
}

func (d *DataBase) CreateMMPool(index int, selectedBrawler int) {
	data := map[string]any{
		"slot": index,
		"info": map[string]any{
			"PlayerCount": 1,
			"map":         0,
			"players":     map[string]any{d.Player.Token: selectedBrawler},
		},
	}
	out, _ := json.Marshal(data)
	d.db.Exec("INSERT INTO Matchmake (slot, data) VALUES (?, ?)", index, string(out))
}

func (d *DataBase) JoinMMPool(index int, brawlerID int) {
	data := d.FetchOne("SELECT data FROM Matchmake WHERE slot = ?", index)
	if data == nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data[0]), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	info["PlayerCount"] = asInt(info["PlayerCount"]) + 1
	players := info["players"].(map[string]any)
	players[d.Player.Token] = brawlerID
	out, _ := json.Marshal(m)
	d.db.Exec("UPDATE Matchmake SET data = ? WHERE slot = ?", string(out), index)
}

func (d *DataBase) LeaveMMPool(index int) {
	data := d.FetchOne("SELECT data FROM Matchmake WHERE slot = ?", index)
	if data == nil {
		return
	}
	var m map[string]any
	if json.Unmarshal([]byte(data[0]), &m) != nil {
		return
	}
	info := m["info"].(map[string]any)
	if asInt(info["PlayerCount"]) == 1 {
		d.db.Exec("DELETE FROM Matchmake WHERE slot = ?", index)
		return
	}
	players := info["players"].(map[string]any)
	if _, ok := players[d.Player.Token]; ok {
		delete(players, d.Player.Token)
		info["PlayerCount"] = asInt(info["PlayerCount"]) - 1
		out, _ := json.Marshal(m)
		d.db.Exec("UPDATE Matchmake SET data = ? WHERE slot = ?", string(out), index)
	}
}

func (d *DataBase) LoadMMPool(index int) error {
	data := d.FetchOne("SELECT data FROM Matchmake WHERE slot = ?", index)
	if data == nil {
		return fmt.Errorf("matchmaking pool not found for slot %d", index)
	}
	var m map[string]any
	if json.Unmarshal([]byte(data[0]), &m) != nil {
		return fmt.Errorf("matchmaking pool not found for slot %d", index)
	}
	info := m["info"].(map[string]any)
	d.Slot = asInt(m["slot"])
	d.PlayerCount = asInt(info["PlayerCount"])
	d.Map = asInt(info["map"])
	players := info["players"].(map[string]any)
	d.MatchmakeData = make(map[string]any, len(players))
	for k, v := range players {
		d.MatchmakeData[k] = v
	}
	return nil
}

func (d *DataBase) RemoveMMPool(index int) {
	d.db.Exec("DELETE FROM Matchmake WHERE slot = ?", index)
}

func (d *DataBase) Close() {
	if shared != nil {
		shared.Close()
		shared = nil
	}
}

func asInt(v any) int {
	switch t := v.(type) {
	case int:
		return t
	case int64:
		return int(t)
	case float64:
		return int(t)
	case string:
		n := 0
		neg := false
		i := 0
		if len(t) > 0 && t[0] == '-' {
			neg, i = true, 1
		}
		for ; i < len(t); i++ {
			if t[i] < '0' || t[i] > '9' {
				break
			}
			n = n*10 + int(t[i]-'0')
		}
		if neg {
			return -n
		}
		return n
	case bool:
		if t {
			return 1
		}
		return 0
	}
	return 0
}

func asString(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case fmt.Stringer:
		return t.String()
	default:
		return fmt.Sprintf("%v", v)
	}
}

func removeInt(s []int, v int) []int {
	out := s[:0]
	for _, x := range s {
		if x != v {
			out = append(out, x)
		}
	}
	return out
}

func randSample(s []int, n int) []int {
	if n >= len(s) {
		n = len(s)
	}
	perm := rand.Perm(len(s))
	out := make([]int, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, s[perm[i]])
	}
	return out
}

func firstInt(s []int) int {
	if len(s) > 0 {
		return s[0]
	}
	return 0
}

func loadSpecialOffer() map[string]any {
	raw, err := readFile("special_offer.json")
	if err != nil {
		return map[string]any{"isEnabled": false}
	}
	var m map[string]any
	json.Unmarshal([]byte(raw), &m)
	return m
}

func readFile(path string) (string, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	return string(b), nil
}
