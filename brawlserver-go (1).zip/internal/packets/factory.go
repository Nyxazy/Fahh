package packets

type MessageEntry struct {
	New func(ctx *Context, payload []byte) ClientMessage
}

var registry = map[int]MessageEntry{}

func Register(id int, newFn func(ctx *Context, payload []byte) ClientMessage) {
	registry[id] = MessageEntry{New: newFn}
}

func Lookup(id int) (MessageEntry, bool) {
	e, ok := registry[id]
	return e, ok
}
