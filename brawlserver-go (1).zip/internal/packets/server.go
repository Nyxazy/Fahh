package packets

import (
	"brawlserver/internal/bytestream"
)

func SendServer(ctx *Context, id int, version int16, encode func(w *bytestream.Writer)) error {
	w := bytestream.NewWriter(ctx.Conn, id, version)
	encode(w)
	return w.Send(ctx.Crypto)
}

func SendServerPlain(ctx *Context, id int, encode func(w *bytestream.Writer)) error {
	return SendServer(ctx, id, 0, encode)
}
