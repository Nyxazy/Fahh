package packets

import (
	"net"

	"brawlserver/internal/crypto"
	"brawlserver/internal/database"
	"brawlserver/internal/logic"
	"brawlserver/internal/serverstates"
)

type Context struct {
	Conn   net.Conn
	Player *logic.Player
	Crypto *crypto.Crypto
	DB     *database.DataBase
	States *serverstates.States
}

func NewContext(conn net.Conn, p *logic.Player, c *crypto.Crypto, st *serverstates.States) *Context {
	return &Context{Conn: conn, Player: p, Crypto: c, States: st}
}

func (ctx *Context) EnsureDB() (*database.DataBase, error) {
	if ctx.DB != nil {
		return ctx.DB, nil
	}
	db, err := database.New(ctx.Player)
	if err != nil {
		return nil, err
	}
	ctx.DB = db
	return db, nil
}

type ClientMessage interface {
	Decode(ctx *Context) error
	Process(ctx *Context) error
}

type HandlerFunc func(ctx *Context, payload []byte) (ClientMessage, error)
