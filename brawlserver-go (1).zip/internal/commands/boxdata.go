package commands

import (
	"fmt"
	"math/rand"

	"brawlserver/internal/bytestream"
	"brawlserver/internal/csvlogic"
	"brawlserver/internal/database"
	"brawlserver/internal/entries"
	"brawlserver/internal/logic"
	"brawlserver/internal/packets"
)

type BoxData struct {
	player        *logic.Player
	db            *database.DataBase
	boxID         int
	rewards       []int
	rewardNames   []string
	rewardsTarget []int
	isTrophyRoad  bool
	updatedBonus  int
}

func newBoxData(p *logic.Player, db *database.DataBase, boxID int) *BoxData {
	return &BoxData{player: p, db: db, boxID: boxID, rewards: []int{}, rewardNames: []string{}, rewardsTarget: []int{}}
}

func (b *BoxData) WithRewards(rewards []int, names []string, targets []int) *BoxData {
	b.rewards = rewards
	b.rewardNames = names
	b.rewardsTarget = targets
	return b
}

func (b *BoxData) getBoxType(boxID int) int {
	switch boxID {
	case 0, 5:
		return 10
	case 1, 4:
		return 12
	case 3:
		return 11
	default:
		return boxID
	}
}

func (b *BoxData) itemType(item string) int {
	switch item {
	case "gems":
		return 8
	case "Coins":
		return 7
	case "UpgradePoints":
		return 6
	case "tickets":
		return 3
	case "tokens_doubler":
		return 2
	case "Brawler":
		return 1
	case "Skin":
		return 9
	case "StarPower":
		return 4
	}
	return 0
}

func (b *BoxData) getRewards() {
	p := b.player
	b.isTrophyRoad = false
	b.player.IsTrophyRoad = false
	hasStarPower := false
	hasBrawler := rand.Intn(6) == 2
	hasBonus := rand.Intn(6) == 2

	starPowerable := []int{}
	p.UnlockedBrawlers.Range(func(key string, bd *logic.BrawlerData) {
		if bd.PowerLevel >= 8 && bd.StarPower == 0 {
			starPowerable = append(starPowerable, atoi2(key))
		}
	})
	if len(starPowerable) != 0 {
		hasStarPower = rand.Intn(2) == 1
		hasBrawler = !hasStarPower
	}

	boxType := b.getBoxType(b.boxID)
	if boxType == 10 {
		hasBonus = false
	}
	var coinsRange [2]int
	switch boxType {
	case 10:
		coinsRange = [2]int{13, 70}
	case 12:
		coinsRange = [2]int{25, 105}
	default:
		coinsRange = [2]int{100, 250}
	}
	var tokenDoublersRange []int
	switch boxType {
	case 10:
		tokenDoublersRange = []int{200}
	case 12:
		tokenDoublersRange = []int{200, 400}
	default:
		tokenDoublersRange = []int{200, 400, 600}
	}
	var powerPointsRandomRange [2]int
	switch boxType {
	case 10:
		powerPointsRandomRange = [2]int{4, 25}
	case 12:
		powerPointsRandomRange = [2]int{5, 30}
	default:
		powerPointsRandomRange = [2]int{5, 50}
	}

	powerPointsRange := 0
	if (hasBrawler || hasStarPower) && boxType != 10 {
		switch boxType {
		case 12:
			powerPointsRange = 2
		default:
			powerPointsRange = 4
		}
	} else if !(hasBrawler || hasStarPower) {
		switch boxType {
		case 10:
			powerPointsRange = 2
		case 12:
			powerPointsRange = 3
		default:
			powerPointsRange = 5
		}
	} else if (hasBrawler || hasStarPower) && boxType == 10 {
		powerPointsRange = 0
	}
	if boxType == 11 && (hasBrawler || hasStarPower) {
		powerPointsRange += 1
	}

	unlocked := []int{}
	unlockable := csvlogic.GetBrawlersID()
	p.UnlockedBrawlers.Range(func(key string, _ *logic.BrawlerData) {
		ki := atoi2(key)
		unlocked = append(unlocked, ki)
		unlockable = removeInt(unlockable, ki)
	})
	notMaxed := []int{}
	for _, br := range unlocked {
		if bd := p.UnlockedBrawlers.Get(fmt.Sprintf("%d", br)); bd != nil && bd.PowerPoints < 1410 {
			notMaxed = append(notMaxed, br)
		}
	}

	rare, superRare, epic, megaEpic, legendary := []int{}, []int{}, []int{}, []int{}, []int{}
	for _, br := range unlockable {
		cardID := csvlogic.GetBrawlerUnlockByCharacter(br) + 2
		rarity := csvlogic.GetBrawlerRarity(cardID)
		switch rarity {
		case "rare":
			rare = append(rare, br)
		case "super_rare":
			superRare = append(superRare, br)
		case "epic":
			epic = append(epic, br)
		case "mega_epic":
			megaEpic = append(megaEpic, br)
		case "legendary":
			legendary = append(legendary, br)
		}
	}

	raritiesChoices := [][]int{rare, superRare, epic, megaEpic, legendary}
	probabilities := []float64{0.45, 0.35, 0.15, 0.1, 0.05}
	filteredChoices := [][]int{}
	filteredProbs := []float64{}
	for i, c := range raritiesChoices {
		if len(c) > 0 {
			filteredChoices = append(filteredChoices, c)
			filteredProbs = append(filteredProbs, probabilities[i])
		}
	}
	if len(filteredChoices) == 0 {
		hasBrawler = false
	}

	if (!hasBrawler && !hasStarPower && boxType == 10) || boxType != 10 {
		b.rewards = append(b.rewards, randBetween(coinsRange[0], coinsRange[1]))
		b.rewardNames = append(b.rewardNames, "Coins")
		b.rewardsTarget = append(b.rewardsTarget, 0)
		p.Gold += b.rewards[0]
		b.db.ReplaceValue("gold", p.Gold)
		if p.UnlockedBrawlers.Len() < powerPointsRange {
			powerPointsRange = p.UnlockedBrawlers.Len()
		}
		targetBrawlers := randSample(notMaxed, powerPointsRange)
		for _, tb := range targetBrawlers {
			reward := randBetween(powerPointsRandomRange[0], powerPointsRandomRange[1])
			if bd := p.UnlockedBrawlers.Get(fmt.Sprintf("%d", tb)); bd != nil {
				if bd.PowerPoints+reward > 1410 {
					reward = 1410 - bd.PowerPoints
				}
				bd.PowerPoints += reward
			}
			b.rewards = append(b.rewards, reward)
			b.rewardNames = append(b.rewardNames, "UpgradePoints")
			b.rewardsTarget = append(b.rewardsTarget, tb)
		}
		b.db.ReplaceValue("unlocked_brawlers", p.UnlockedBrawlers)
	}

	brawlersOffset := powerPointsRange

	if hasStarPower && len(starPowerable) > 0 {
		starBrawler := starPowerable[rand.Intn(len(starPowerable))]
		starPower := csvlogic.GetBrawlerStarPower(starBrawler)
		b.rewards = append(b.rewards, starPower)
		b.rewardNames = append(b.rewardNames, "StarPower")
		b.rewardsTarget = append(b.rewardsTarget, starBrawler)
		if powerPointsRange > 0 {
			brawlersOffset = powerPointsRange + 1
		} else {
			brawlersOffset = powerPointsRange
		}
		if bd := p.UnlockedBrawlers.Get(fmt.Sprintf("%d", starBrawler)); bd != nil {
			bd.StarPower = starPower
		}
		b.db.ReplaceValue("unlocked_brawlers", p.UnlockedBrawlers)
	}

	if hasBrawler && len(filteredChoices) > 0 {
		selectedIdx := weightedChoice(filteredProbs)
		chosenRarity := filteredChoices[selectedIdx]
		rewardedBrawler := chosenRarity[rand.Intn(len(chosenRarity))]
		b.rewards = append(b.rewards, rewardedBrawler)
		b.rewardNames = append(b.rewardNames, "Brawler")
		b.rewardsTarget = append(b.rewardsTarget, 0)
		if powerPointsRange > 0 {
			brawlersOffset = powerPointsRange + 1
		} else {
			brawlersOffset = powerPointsRange
		}
		p.UnlockedBrawlers.Set(fmt.Sprintf("%d", rewardedBrawler), &logic.BrawlerData{
			CardID: csvlogic.GetBrawlerUnlockByCharacter(rewardedBrawler),
			Skins:  []int{0}, Trophies: 0, HighestTrophies: 0, PowerLevel: 0,
			PowerPoints: 0, State: 0, StarPower: 0,
		})
		b.db.ReplaceValue("unlocked_brawlers", p.UnlockedBrawlers)
	}

	if rand.Intn(6) == 2 {
		bonuses := []string{"tickets", "gems", "tokens_doubler"}
		sel := bonuses[rand.Intn(len(bonuses))]
		switch sel {
		case "tickets":
			val := []int{1, 2, 3, 5}[rand.Intn(4)]
			b.rewards = append(b.rewards, val)
			p.Tickets += val
			b.updatedBonus = p.Tickets
		case "gems":
			val := []int{3, 5, 6, 8, 12}[rand.Intn(5)]
			b.rewards = append(b.rewards, val)
			p.Gems += val
			b.updatedBonus = p.Gems
		case "tokens_doubler":
			val := tokenDoublersRange[rand.Intn(len(tokenDoublersRange))]
			b.rewards = append(b.rewards, val)
			p.TokensDoubler += val
			b.updatedBonus = p.TokensDoubler
		}
		b.rewardNames = append(b.rewardNames, sel)
		b.rewardsTarget = append(b.rewardsTarget, 0)
		b.db.ReplaceValue(sel, b.updatedBonus)
	}
	_ = brawlersOffset
	_ = hasBonus

	switch b.boxID {
	case 5:
		p.BrawlBoxes -= 100
		b.db.ReplaceValue("brawl_boxes", p.BrawlBoxes)
	case 4:
		p.BigBoxes -= 10
		b.db.ReplaceValue("big_boxes", p.BigBoxes)
	case 3:
		p.Gems -= 80
		b.db.ReplaceValue("gems", p.Gems)
	case 1:
		p.Gems -= 30
		b.db.ReplaceValue("gems", p.Gems)
	}
}

func (b *BoxData) encode(ctx *packets.Context) error {
	return packets.SendServerPlain(ctx, 24111, func(w *bytestream.Writer) {
		w.WriteVInt(203)
		w.WriteVInt(b.getBoxType(b.boxID))
		w.WriteVInt(1)
		w.WriteVInt(0)
		w.WriteVInt(len(b.rewards))
		for i, reward := range b.rewards {
			if b.rewardNames[i] == "Brawler" || b.rewardNames[i] == "StarPower" {
				w.WriteVInt(0)
			} else {
				w.WriteVInt(reward)
			}
			target := b.rewardsTarget[i]
			if target == -1 {
				target = 0
			}
			if b.rewardNames[i] == "Brawler" {
				w.WriteDataReference(16, reward)
			} else {
				w.WriteDataReference(16, target)
			}
			w.WriteVInt(b.itemType(b.rewardNames[i]))
			switch b.rewardNames[i] {
			case "Skin":
				w.WriteDataReference(29, reward)
			case "StarPower":
				w.WriteDataReference(23, reward)
			default:
				w.WriteDataReference(0, 0)
			}
			w.WriteVInt(reward)
		}
		if b.player.IsTrophyRoad {
			w.WriteVInt(b.player.TrophyRoad + 1)
			b.player.IsTrophyRoad = false
		} else {
			w.WriteVInt(0)
		}
		entries.EncodeLogicServerCommand(w)
	})
}

func randBetween(lo, hi int) int {
	if hi <= lo {
		return lo
	}
	return lo + rand.Intn(hi-lo+1)
}

func removeInt(s []int, v int) []int {
	out := make([]int, 0, len(s))
	for _, x := range s {
		if x != v {
			out = append(out, x)
		}
	}
	return out
}

func randSample(s []int, n int) []int {
	if n >= len(s) {
		n = len(s)
	}
	perm := rand.Perm(len(s))
	out := make([]int, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, s[perm[i]])
	}
	return out
}

func weightedChoice(probs []float64) int {
	total := 0.0
	for _, p := range probs {
		total += p
	}
	r := rand.Float64() * total
	acc := 0.0
	for i, p := range probs {
		acc += p
		if r <= acc {
			return i
		}
	}
	return len(probs) - 1
}

func atoi2(s string) int {
	n := 0
	for i := 0; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			break
		}
		n = n*10 + int(s[i]-'0')
	}
	return n
}
