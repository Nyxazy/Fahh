package commands

import (
	"fmt"
	"math/rand"

	"brawlserver/internal/csvlogic"
	"brawlserver/internal/logic"
)

func purchaseBox(p *Processor) {
	player := p.Ctx.Player
	boxID := p.BS.ReadVInt()
	if boxID == 5 && player.BrawlBoxes < 100 {
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{0}, []string{"Coins"}, []int{0})
		player.Gold += 0
		p.DB.ReplaceValue("gold", player.Gold)
		bd.encode(p.Ctx)
	} else if boxID == 4 && player.BigBoxes < 10 {
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{0}, []string{"Coins"}, []int{0})
		player.Gold += 0
		p.DB.ReplaceValue("gold", player.Gold)
		bd.encode(p.Ctx)
	} else if boxID == 3 && player.Gems < 80 {
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{0}, []string{"Coins"}, []int{0})
		player.Gold += 0
		p.DB.ReplaceValue("gold", player.Gold)
		bd.encode(p.Ctx)
	} else if boxID == 1 && player.Gems < 30 {
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{0}, []string{"Coins"}, []int{0})
		player.Gold += 0
		p.DB.ReplaceValue("gold", player.Gold)
		bd.encode(p.Ctx)
	} else {
		bd := newBoxData(player, p.DB, boxID)
		bd.getRewards()
		bd.encode(p.Ctx)
	}
}

var claimRewards = []string{"box", "brawler", "box", "event", "box", "brawler", "box", "tokenDoublers", "powerPoints", "brawler", "box", "event", "powerPoints", "box", "brawler", "coins", "powerPoints", "box", "coins", "box", "event", "powerPoints", "coins", "tickets", "brawler", "coins", "box", "powerPoints", "coins", "powerPoints", "box", "coins", "box", "powerPoints", "brawler", "coins", "box", "powerPoints", "coins", "box", "coins", "box", "powerPoints", "coins", "brawler", "coins", "powerPoints", "coins", "box", "coins", "tokenDoublers", "box", "powerPoints", "coins", "box", "powerPoints", "coins", "box", "powerPoints", "box", "powerPoints", "box", "coins", "powerPoints", "box", "coins", "box", "powerPoints", "coins", "box", "coins", "powerPoints", "box", "coins", "box", "powerPoints", "box", "coins", "box", "box", "coins", "powerPoints", "coins", "box", "box", "coins", "coins", "coins", "box", "coins", "coins", "coins", "box", "coins"}
var claimValues = []int{10, 8, 10, 2, 10, 1, 10, 200, 25, 2, 10, 3, 25, 10, 7, 50, 25, 12, 50, 10, 4, 25, 50, 10, 3, 50, 10, 75, 50, 25, 12, 50, 10, 25, 9, 50, 10, 150, 50, 10, 150, 10, 25, 50, 14, 50, 25, 300, 10, 50, 600, 10, 25, 50, 11, 25, 50, 12, 25, 11, 25, 10, 150, 25, 11, 50, 10, 75, 50, 11, 50, 25, 12, 50, 11, 25, 10, 150, 10, 11, 50, 25, 150, 10, 11, 150, 300, 150, 11, 150, 300, 150, 11, 150}

func claimRankUp(p *Processor) {
	player := p.Ctx.Player
	brawlerTarget := p.BS.ReadDataReference()
	player.IsTrophyRoad = true
	if player.TrophyRoad-1 < 0 || player.TrophyRoad-1 >= len(claimRewards) {
		return
	}
	reward := claimRewards[player.TrophyRoad-1]
	value := claimValues[player.TrophyRoad-1]
	switch reward {
	case "box":
		bd := newBoxData(player, p.DB, value)
		bd.getRewards()
		bd.encode(p.Ctx)
	case "event":
		player.UnlockedEvents += 1
		p.DB.ReplaceValue("unlockedEvents", player.UnlockedEvents)
	case "brawler":
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{value}, []string{"Brawler"}, []int{0})
		player.UnlockedBrawlers.Set(fmt.Sprintf("%d", value), &logic.BrawlerData{
			CardID: csvlogic.GetBrawlerUnlockByCharacter(value), Skins: []int{0},
		})
		p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
		bd.encode(p.Ctx)
	case "tokenDoublers":
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{value}, []string{"tokens_doubler"}, []int{0})
		player.TokensDoubler += value
		p.DB.ReplaceValue("tokens_doubler", player.TokensDoublerDB)
		bd.encode(p.Ctx)
	case "powerPoints":
		target := brawlerTarget[1]
		rewardVal := value
		if bd := player.UnlockedBrawlers.Get(fmt.Sprintf("%d", target)); bd != nil {
			if bd.PowerPoints+rewardVal > 1410 {
				rewardVal = 1410 - bd.PowerPoints
			}
			bd.PowerPoints += rewardVal
		}
		bd2 := newBoxData(player, p.DB, 100).WithRewards([]int{rewardVal}, []string{"UpgradePoints"}, []int{target})
		p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
		bd2.encode(p.Ctx)
	case "coins":
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{value}, []string{"Coins"}, []int{0})
		player.Gold += value
		p.DB.ReplaceValue("gold", player.Gold)
		bd.encode(p.Ctx)
	case "tickets":
		bd := newBoxData(player, p.DB, 100).WithRewards([]int{value}, []string{"tickets"}, []int{0})
		player.Tickets += value
		p.DB.ReplaceValue("tickets", player.Tickets)
		bd.encode(p.Ctx)
	}
	player.TrophyRoad += 1
	p.DB.ReplaceValue("trophyRoad", player.TrophyRoad)
}

func clearShopTickers(p *Processor) {
	player := p.Ctx.Player
	offers := p.DB.LoadOffers(player.Token)
	if info, ok := offers["info"].(map[string]any); ok {
		for k, v := range info {
			if item, ok := v.(map[string]any); ok {
				item["IsOfferSeen"] = 1
				info[k] = item
			}
		}
	}
	p.DB.SaveOffers(player.Token, offers)
}

func purchaseOffer(p *Processor) {
	player := p.Ctx.Player
	offerIndex := p.BS.ReadVInt()
	offers := p.DB.LoadOffers(player.Token)
	info, _ := offers["info"].(map[string]any)
	if info == nil {
		return
	}
	offerInfo, _ := info[fmt.Sprintf("%d", offerIndex)].(map[string]any)
	if offerInfo == nil {
		return
	}
	if asInt(offerInfo["IsOfferPurchased"]) == 1 {
		return
	}
	offerID := asInt(offerInfo["OfferID"])
	switch offerID {
	case 0, 6, 15:
		bd := newBoxData(player, p.DB, 10)
		bd.getRewards()
		bd.encode(p.Ctx)
	case 1:
		amount := asInt(offerInfo["Amount"])
		player.Gold += amount
		p.DB.ReplaceValue("gold", player.Gold)
		newBoxData(player, p.DB, 100).WithRewards([]int{amount}, []string{"Coins"}, []int{0}).encode(p.Ctx)
	case 2:
		value := asInt(offerInfo["Value"])
		unlockable := csvlogic.GetBrawlersID()
		rare, superRare, epic, megaEpic, legendary := []int{}, []int{}, []int{}, []int{}, []int{}
		for _, br := range unlockable {
			cardID := csvlogic.GetBrawlerUnlockByCharacter(br) + 2
			switch csvlogic.GetBrawlerRarity(cardID) {
			case "rare":
				rare = append(rare, br)
			case "super_rare":
				superRare = append(superRare, br)
			case "epic":
				epic = append(epic, br)
			case "mega_epic":
				megaEpic = append(megaEpic, br)
			case "legendary":
				legendary = append(legendary, br)
			}
		}
		var list []int
		switch value {
		case 1:
			list = rare
		case 2:
			list = superRare
		case 3:
			list = epic
		case 4:
			list = megaEpic
		}
		if len(list) == 0 {
			return
		}
		rewarded := list[rand.Intn(len(list))]
		player.UnlockedBrawlers.Set(fmt.Sprintf("%d", rewarded), &logic.BrawlerData{
			CardID: csvlogic.GetBrawlerUnlockByCharacter(rewarded), Skins: []int{0},
		})
		p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
		newBoxData(player, p.DB, 100).WithRewards([]int{rewarded}, []string{"Brawler"}, []int{0}).encode(p.Ctx)
	case 3:
		target := offerTarget(offerInfo)
		player.UnlockedBrawlers.Set(fmt.Sprintf("%d", target), &logic.BrawlerData{
			CardID: csvlogic.GetBrawlerUnlockByCharacter(target), Skins: []int{0},
		})
		p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
		newBoxData(player, p.DB, 100).WithRewards([]int{target}, []string{"Brawler"}, []int{0}).encode(p.Ctx)
	}
	applyOfferCost(p, offerInfo)
	info[fmt.Sprintf("%d", offerIndex)] = offerInfo
	offerInfo["IsOfferPurchased"] = 1
	p.DB.SaveOffers(player.Token, offers)
}

func applyOfferCost(p *Processor, offerInfo map[string]any) {
	player := p.Ctx.Player
	currency := asInt(offerInfo["Currency"])
	price := asInt(offerInfo["Price"])
	switch currency {
	case 0:
		player.Gems -= price
		p.DB.ReplaceValue("gems", player.Gems)
	case 1:
		player.Gold -= price
		p.DB.ReplaceValue("gold", player.Gold)
	}
}

func setPlayerThumbnail(p *Processor) {
	player := p.Ctx.Player
	p.BS.ReadVInt()
	player.ProfileIcon = p.BS.ReadVInt()
	if !intInSlice2(player.ProfileIcon, csvlogic.GetAllThumbnails()) {
		return
	}
	if csvlogic.GetRequiredTrophiesForThumbnail(player.ProfileIcon) > player.Trophies {
		return
	}
	requiredBrawler := csvlogic.GetRequiredBrawlerForThumbnail(player.ProfileIcon)
	if player.UnlockedBrawlers.Get(fmt.Sprintf("%d", csvlogic.GetBrawlerByName(requiredBrawler))) == nil {
		return
	}
	requiredExpLevel := csvlogic.GetRequiredExpForThumbnail(player.ProfileIcon)
	if requiredExpLevel >= len(requiredExps) {
		return
	}
	if requiredExps[requiredExpLevel] > player.PlayerExperience {
		return
	}
	p.DB.ReplaceValue("profile_icon", player.ProfileIcon)
}

func selectSkin(p *Processor) {
	player := p.Ctx.Player
	skinID := p.BS.ReadDataReference()
	brawler := csvlogic.GetBrawler(skinID[1])
	bd := player.UnlockedBrawlers.Get(fmt.Sprintf("%d", brawler))
	if bd == nil {
		return
	}
	has := false
	for _, s := range bd.Skins {
		if s == skinID[1] {
			has = true
			break
		}
	}
	if !has {
		return
	}
	bd.SelectedSkin = skinID[1]
	p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
}

func unlockSkin(p *Processor) {
	player := p.Ctx.Player
	skinRef := p.BS.ReadDataReference()
	if !intInSlice2(skinRef[1], csvlogic.GetSkinsID()) {
		return
	}
	isDefault := csvlogic.GetIsDefaultSkin(skinRef[1])
	brawler := csvlogic.GetBrawler(skinRef[1])
	if isDefault {
		if player.UnlockedBrawlers.Get(fmt.Sprintf("%d", brawler)) != nil {
			return
		}
		player.UnlockedBrawlers.Set(fmt.Sprintf("%d", brawler), &logic.BrawlerData{
			CardID: csvlogic.GetBrawlerUnlockByCharacter(brawler), Skins: []int{0},
		})
		p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
		newBoxData(player, p.DB, 100).WithRewards([]int{brawler}, []string{"Brawler"}, []int{0}).encode(p.Ctx)
	} else {
		bd := player.UnlockedBrawlers.Get(fmt.Sprintf("%d", brawler))
		if bd == nil {
			return
		}
		price := csvlogic.GetSkinPrice(skinRef[1])
		player.Gems -= atoi2(price)
		p.DB.ReplaceValue("gems", player.Gems)
		bd.Skins = append(bd.Skins, skinRef[1])
		bd.SelectedSkin = skinRef[1]
		p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
		newBoxData(player, p.DB, 100).WithRewards([]int{skinRef[1]}, []string{"Skin"}, []int{0}).encode(p.Ctx)
	}
}

func upgradeBrawler(p *Processor) {
	player := p.Ctx.Player
	brawlerRef := p.BS.ReadDataReference()
	bd := player.UnlockedBrawlers.Get(fmt.Sprintf("%d", brawlerRef[1]))
	if bd == nil {
		return
	}
	currentPowerLevel := bd.PowerLevel
	bd.PowerLevel += 1
	p.DB.ReplaceValue("unlocked_brawlers", player.UnlockedBrawlers)
	coins := []int{20, 35, 75, 140, 290, 480, 800, 1250}
	if currentPowerLevel >= 0 && currentPowerLevel < len(coins) {
		player.Gold -= coins[currentPowerLevel]
		p.DB.ReplaceValue("gold", player.Gold)
	}
}

func purchaseHeroMaterial(p *Processor) {
	player := p.Ctx.Player
	goldIdx := p.BS.ReadVInt()
	if goldIdx < 0 || goldIdx >= len(logic.ShopGoldList) {
		return
	}
	cost := logic.ShopGoldList[goldIdx].Cost
	value := logic.ShopGoldList[goldIdx].Amount
	if player.Gems < cost {
		return
	}
	player.Gold += value
	player.Gems -= cost
	p.DB.ReplaceValue("gold", player.Gold)
	p.DB.ReplaceValue("gems", player.Gems)
}

func purchaseDoubleCoins(p *Processor) {
	player := p.Ctx.Player
	cost := logic.ShopTokenDoubler.Cost
	value := logic.ShopTokenDoubler.Amount
	player.Gems -= cost
	player.Tokens += value
	p.DB.ReplaceValue("gems", player.Gems)
	p.DB.ReplaceValue("tokens", player.Tokens)
}

func offerTarget(item map[string]any) int {
	t, ok := item["Target"]
	if !ok {
		return 0
	}
	switch tt := t.(type) {
	case []any:
		if len(tt) >= 2 {
			return asInt(tt[1])
		}
	}
	return 0
}

func asInt(v any) int {
	switch t := v.(type) {
	case int:
		return t
	case int64:
		return int(t)
	case float64:
		return int(t)
	}
	return 0
}

func intInSlice2(v int, s []int) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}
