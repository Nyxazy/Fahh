package commands

import (
	"brawlserver/internal/bytestream"
	"brawlserver/internal/database"
	"brawlserver/internal/packets"
)

type Processor struct {
	Ctx *packets.Context
	DB  *database.DataBase
	BS  *bytestream.ByteStream
}

func NewProcessor(ctx *packets.Context, db *database.DataBase, bs *bytestream.ByteStream) *Processor {
	return &Processor{Ctx: ctx, DB: db, BS: bs}
}

func (p *Processor) Handle(cmdID int) bool {
	switch cmdID {
	case 500, 535:
		purchaseBox(p)
	case 517:
		claimRankUp(p)
	case 515:
		clearShopTickers(p)
	case 519:
		purchaseOffer(p)
	case 505:
		setPlayerThumbnail(p)
	case 506:
		selectSkin(p)
	case 507:
		unlockSkin(p)
	case 520:
		upgradeBrawler(p)
	case 521:
		purchaseHeroMaterial(p)
	case 522:
	case 509:
		purchaseDoubleCoins(p)
	default:
		if cmdID < 500 || cmdID > 570 {
			return true
		}
	}
	return true
}
