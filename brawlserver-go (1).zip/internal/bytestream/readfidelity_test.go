package bytestream

import (
	"encoding/json"
	"os"
	"testing"
)

func TestReadVIntFidelity(t *testing.T) {
	pyData, err := os.ReadFile("/tmp/py_bs.json")
	if err != nil {
		t.Skip("run verify_py/bytestream_ref.py first")
	}
	var vectors []struct {
		Hex string `json:"hex"`
		PY  int    `json:"py"`
	}
	if err := json.Unmarshal(pyData, &vectors); err != nil {
		t.Fatal(err)
	}
	mismatch := 0
	for _, v := range vectors {
		raw := hexDecode(t, v.Hex)
		b := NewByteStream(raw)
		got := b.ReadVInt()
		if got != v.PY {
			mismatch++
			if mismatch < 10 {
				t.Errorf("hex=%s go=%d py=%d", v.Hex, got, v.PY)
			}
		}
	}
	if mismatch == 0 {
		t.Logf("readVInt fidelity: %d vectors verified identical to Python ByteStream.readVInt", len(vectors))
	} else {
		t.Fatalf("%d mismatches", mismatch)
	}
}

func hexDecode(t *testing.T, s string) []byte {
	out := make([]byte, len(s)/2)
	for i := range out {
		var b byte
		for j := 0; j < 2; j++ {
			b <<= 4
			c := s[i*2+j]
			switch {
			case c >= '0' && c <= '9':
				b |= c - '0'
			case c >= 'a' && c <= 'f':
				b |= c - 'a' + 10
			}
		}
		out[i] = b
	}
	return out
}
