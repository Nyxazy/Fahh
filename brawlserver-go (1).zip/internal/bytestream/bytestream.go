package bytestream

import (
	"encoding/binary"
	"fmt"
)

type ByteStream struct {
	payload   []byte
	offset    int
	bitoffset int
	length    int
	fields    map[string]any
}

func NewByteStream(payload []byte) *ByteStream {
	return &ByteStream{
		payload: payload,
		length:  len(payload),
		fields:  map[string]any{},
	}
}

func (b *ByteStream) Fields() map[string]any { return b.fields }

func (b *ByteStream) GetLength() int {
	if b.length <= b.offset {
		return b.offset
	}
	return b.length
}

func (b *ByteStream) GetOffset() int { return b.offset }

func (b *ByteStream) IsAtEnd() bool { return len(b.payload) <= b.offset }

func (b *ByteStream) Skip(n int) {
	b.bitoffset = 0
	b.offset += n
}

func (b *ByteStream) ResetOffset() {
	b.offset = 0
	b.bitoffset = 0
}

func (b *ByteStream) ReadBoolean() bool {
	bitoffset := b.bitoffset
	offset := b.offset + ((8 - bitoffset) >> 3)
	b.offset = offset
	b.bitoffset = (bitoffset + 1) & 7
	return (1<<(bitoffset&31))&b.payload[offset-1] != 0
}

func (b *ByteStream) ReadInt8() int {
	b.bitoffset = 0
	r := int(b.payload[b.offset])
	b.offset++
	return r
}

func (b *ByteStream) ReadBytes(length int) []byte {
	b.bitoffset = 0
	if length&0x80000000 != 0 {
		return nil
	}
	if length > 1000 {
		return nil
	}
	r := b.payload[b.offset : b.offset+length]
	b.offset += length
	out := make([]byte, length)
	copy(out, r)
	return out
}

func (b *ByteStream) ReadInt16() int {
	b.bitoffset = 0
	r := int(b.payload[b.offset])<<8 | int(b.payload[b.offset+1])
	b.offset += 2
	return r
}

func (b *ByteStream) ReadShort() int { return b.ReadInt16() }

func (b *ByteStream) ReadInt24() int {
	b.bitoffset = 0
	r := int(b.payload[b.offset])<<16 | int(b.payload[b.offset+1])<<8 | int(b.payload[b.offset+2])
	b.offset += 3
	return r
}

func (b *ByteStream) ReadInt() int {
	b.bitoffset = 0
	r := int(b.payload[b.offset])<<24 |
		int(b.payload[b.offset+1])<<16 |
		int(b.payload[b.offset+2])<<8 |
		int(b.payload[b.offset+3])
	b.offset += 4
	return r
}

func (b *ByteStream) ReadIntLittleEndian() int {
	b.bitoffset = 0
	r := int(b.payload[b.offset]) |
		int(b.payload[b.offset+1])<<8 |
		int(b.payload[b.offset+2])<<16 |
		int(b.payload[b.offset+3])<<24
	b.offset += 4
	return r
}

func (b *ByteStream) ReadLong() [2]int {
	return [2]int{b.ReadInt(), b.ReadInt()}
}

func (b *ByteStream) ReadLongLong() int64 {
	high := b.ReadInt()
	low := b.ReadInt()
	return int64(uint64(uint32(high))<<32 | uint64(uint32(low)))
}

func (b *ByteStream) ReadString() string {
	b.bitoffset = 0
	length := int(b.payload[b.offset])<<24 |
		int(b.payload[b.offset+1])<<16 |
		int(b.payload[b.offset+2])<<8 |
		int(b.payload[b.offset+3])
	b.offset += 4
	if length <= -1 {
		return ""
	}
	if length > 900000 {
		return ""
	}
	s := string(b.payload[b.offset : b.offset+length])
	b.offset += length
	return s
}

func (b *ByteStream) ReadVInt() int {
	defer func() { recover() }()
	offset := b.offset
	b.bitoffset = 0
	v4 := offset + 1
	b.offset = offset + 1
	result := int(b.payload[offset]) & 0x3F
	if int(b.payload[offset])&0x40 != 0 {
		if int(b.payload[offset])&0x80 != 0 {
			b.offset = offset + 2
			v7 := int(b.payload[v4])
			v8 := result&0xFFFFE03F | ((v7 & 0x7F) << 6)
			if v7&0x80 != 0 {
				b.offset = offset + 3
				v9 := v8&0xFFF01FFF | ((int(b.payload[offset+2]) & 0x7F) << 13)
				if int(b.payload[offset+2])&0x80 != 0 {
					b.offset = offset + 4
					v10 := v9&0xF80FFFFF | ((int(b.payload[offset+3]) & 0x7F) << 20)
					if int(b.payload[offset+3])&0x80 != 0 {
						b.offset = offset + 5
						return v10&0x7FFFFFF | (int(b.payload[offset+4]) << 27) | 0x80000000
					}
					return v10 | 0xF8000000
				}
				return v9 | 0xFFF00000
			}
			return v8 | 0xFFFFE000
		}
		return int(b.payload[offset]) | 0xFFFFFFC0
	}
	if int(b.payload[offset])&0x80 != 0 {
		b.offset = offset + 2
		v6 := int(b.payload[v4])
		result = result&0xFFFFE03F | ((v6 & 0x7F) << 6)
		if v6&0x80 != 0 {
			b.offset = offset + 3
			result = result&0xFFF01FFF | ((int(b.payload[offset+2]) & 0x7F) << 13)
			if int(b.payload[offset+2])&0x80 != 0 {
				b.offset = offset + 4
				result = result&0xF80FFFFF | ((int(b.payload[offset+3]) & 0x7F) << 20)
				if int(b.payload[offset+3])&0x80 != 0 {
					b.offset = offset + 5
					return result&0x7FFFFFF | (int(b.payload[offset+4]) << 27)
				}
			}
		}
	}
	return result
}

func (b *ByteStream) ReadVLong() [2]int {
	return [2]int{b.ReadVInt(), b.ReadVInt()}
}

func (b *ByteStream) ReadDataReference() [2]int {
	high := b.ReadVInt()
	if high == 0 {
		return [2]int{0, 0}
	}
	low := b.ReadVInt()
	return [2]int{high, low}
}

func (b *ByteStream) ReadIntList() []int {
	n := b.ReadVInt()
	out := make([]int, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, b.ReadVInt())
	}
	return out
}

func (b *ByteStream) Debug() string {
	return fmt.Sprintf("offset=%d len=%d rem=%x", b.offset, b.length, b.payload[b.offset:])
}

var _ = binary.BigEndian
