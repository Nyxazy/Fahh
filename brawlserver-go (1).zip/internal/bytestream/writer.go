package bytestream

import (
	"bytes"
	"compress/zlib"
	"encoding/binary"
	"math/rand"
	"net"

	"brawlserver/internal/crypto"
)

type Writer struct {
	conn      net.Conn
	Buffer    []byte
	id        int
	version   int16
	bitoffset int
}

func NewWriter(conn net.Conn, id int, version int16) *Writer {
	return &Writer{conn: conn, id: id, version: version}
}

func (w *Writer) ID() int { return w.id }

func (w *Writer) SetID(id int) { w.id = id }

func (w *Writer) WriteInt(data int, length ...int) {
	w.bitoffset = 0
	n := 4
	if len(length) > 0 {
		n = length[0]
	}
	for i := n - 1; i >= 0; i-- {
		w.Buffer = append(w.Buffer, byte((data>>(uint(i)*8))&0xFF))
	}
}

func (w *Writer) WriteOldInt(data int, length int) { w.WriteInt(data, length) }

func (w *Writer) WriteLong(high, low int) {
	w.WriteInt(high)
	w.WriteInt(low)
}

func (w *Writer) WriteLogicLong(high, low int) {
	w.WriteVInt(high)
	w.WriteVInt(low)
}

func (w *Writer) WriteUInt8(data int) { w.WriteInt(data, 1) }

func (w *Writer) WriteInt16(data int) { w.WriteInt(data, 2) }

func (w *Writer) WriteShort(data int) { w.WriteInt(data, 2) }

func (w *Writer) WriteInt24(data int) { w.WriteInt(data, 3) }

func (w *Writer) WriteBoolean(value bool) {
	w.bitoffset = 0
	if value {
		w.WriteUInt8(1)
	} else {
		w.WriteUInt8(0)
	}
}

func (w *Writer) WriteBoolBit(value bool) {
	if w.bitoffset == 0 {
		w.Buffer = append(w.Buffer, 0)
	}
	if value {
		w.Buffer[len(w.Buffer)-1] |= 1 << (w.bitoffset & 31)
	}
	w.bitoffset = (w.bitoffset + 1) & 7
}

func (w *Writer) WriteString(value *string) {
	w.bitoffset = 0
	if value == nil {
		w.WriteInt(0xFFFFFFFF)
		return
	}
	encoded := []byte(*value)
	w.WriteInt(len(encoded))
	w.Buffer = append(w.Buffer, encoded...)
}

func (w *Writer) WriteStringVal(value string) { w.WriteString(&value) }

func (w *Writer) WriteStringReference(value string) {
	w.bitoffset = 0
	encoded := []byte(value)
	w.WriteInt16(0)
	w.WriteVInt(len(encoded))
	w.Buffer = append(w.Buffer, encoded...)
}

func (w *Writer) WriteHexa(data string) {
	w.bitoffset = 0
	if data == "" {
		return
	}
	src := data
	if len(src) >= 2 && src[0] == '0' && (src[1] == 'x' || src[1] == 'X') {
		src = src[2:]
	}
	cleaned := make([]byte, 0, len(src))
	for i := 0; i < len(src); i++ {
		c := src[i]
		switch {
		case c >= '0' && c <= '9', c >= 'a' && c <= 'f', c >= 'A' && c <= 'F':
			cleaned = append(cleaned, c)
		case c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == '-':
			continue
		}
	}
	out := make([]byte, len(cleaned)/2)
	for i := 0; i < len(out); i++ {
		var b byte
		for j := 0; j < 2; j++ {
			b <<= 4
			c := cleaned[i*2+j]
			switch {
			case c >= '0' && c <= '9':
				b |= c - '0'
			case c >= 'a' && c <= 'f':
				b |= c - 'a' + 10
			case c >= 'A' && c <= 'F':
				b |= c - 'A' + 10
			}
		}
		out[i] = b
	}
	w.Buffer = append(w.Buffer, out...)
}

func (w *Writer) WriteDataReference(high int, low int) {
	w.WriteVInt(high)
	if high != 0 {
		w.WriteVInt(low)
	}
}

func (w *Writer) WriteScID(high int, low int) { w.WriteDataReference(high, low) }

func (w *Writer) WriteArrayVInt(data []int) {
	for _, x := range data {
		w.WriteVInt(x)
	}
}

func (w *Writer) EncodeIntList(list []int) {
	w.WriteVInt(len(list))
	for _, x := range list {
		w.WriteVInt(x)
	}
}

func (w *Writer) WriteVInt(data int) {
	w.bitoffset = 0
	if data == 0 {
		w.Buffer = append(w.Buffer, 0)
		return
	}
	v := int32(data)
	d := uint32((v << 1) ^ (v >> 31))
	rotate := true
	for d != 0 {
		b := d & 0x7f
		if d >= 0x80 {
			b |= 0x80
		}
		if rotate {
			rotate = false
			lsb := b & 0x1
			msb := (b & 0x80) >> 7
			b >>= 1
			b = b & 0x3f
			b = b | (msb << 7) | (lsb << 6)
		}
		w.Buffer = append(w.Buffer, byte(b))
		d >>= 7
	}
}

func (w *Writer) WriteVLong(high, low int) {
	w.WriteVInt(high)
	w.WriteVInt(low)
}

func (w *Writer) WriteCompressedString(data []byte) {
	w.bitoffset = 0
	compressed := zlibCompress(data)
	w.WriteInt(len(compressed) + 4)
	w.WriteIntLittleEndian(len(data))
	w.Buffer = append(w.Buffer, compressed...)
}

func (w *Writer) WriteIntLittleEndian(value int) {
	w.bitoffset = 0
	w.Buffer = append(w.Buffer,
		byte(value&0xFF),
		byte((value>>8)&0xFF),
		byte((value>>16)&0xFF),
		byte((value>>24)&0xFF),
	)
}

func zlibCompress(data []byte) []byte {
	var buf bytes.Buffer
	zw := zlib.NewWriter(&buf)
	_, _ = zw.Write(data)
	_ = zw.Close()
	return buf.Bytes()
}

func (w *Writer) Send(c *crypto.Crypto) error {
	payload, err := c.Encrypt(w.id, w.Buffer)
	if err != nil {
		return err
	}
	header := make([]byte, 7)
	id16 := int16(w.id)
	binary.BigEndian.PutUint16(header[0:2], uint16(id16))
	header[2] = byte(len(payload) >> 16)
	header[3] = byte(len(payload) >> 8)
	header[4] = byte(len(payload))
	binary.BigEndian.PutUint16(header[5:7], uint16(w.version))
	packet := append(header, payload...)
	if w.conn != nil {
		if _, err := w.conn.Write(packet); err != nil {
			return err
		}
	}
	return nil
}

func (w *Writer) RawConn() net.Conn { return w.conn }

func RandomStringDigits() string {
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	out := make([]byte, 40)
	for i := range out {
		out[i] = letters[rand.Intn(len(letters))]
	}
	return string(out)
}

func RandomID() int {
	n := 0
	for i := 0; i < 9; i++ {
		n = n*10 + rand.Intn(10)
	}
	return n
}

func RandomClubID() int { return RandomID() }

func RandomKey(length int) string {
	const hexLetters = "1234567890ABCDEF"
	out := make([]byte, length*2)
	for i := range out {
		out[i] = hexLetters[rand.Intn(len(hexLetters))]
	}
	return string(out)
}
