package bytestream

type LogicLong struct {
	High int
	Low  int
}

func NewLogicLong(high, low int) *LogicLong { return &LogicLong{High: high, Low: low} }

func (l *LogicLong) Clone() *LogicLong { return &LogicLong{High: l.High, Low: l.Low} }

func (l *LogicLong) Equals(other *LogicLong) bool {
	if other == nil {
		return false
	}
	if l.Low != other.Low {
		return false
	}
	return l.High == other.High
}

func (l *LogicLong) IsZero() bool {
	if l.Low != 0 {
		return false
	}
	return l.High == 0
}

func (l *LogicLong) HashCode() int { return 31*l.High + l.Low }

func HigherInt(v int64) int32 { return int32(v >> 32) }

func LowerInt(v int64) int32 {
	if v < 0 {
		return int32(v | 0x80000000)
	}
	return int32(v & 0x7FFFFFFF)
}

func ToLong(high, low int) int64 {
	lowerInt := int64(low & 0x7FFFFFFF)
	if low < 0 {
		lowerInt = int64(low | 0x80000000)
	}
	return lowerInt | (int64(uint32(high)) << 32)
}

func (l *LogicLong) GreaterThan(other *LogicLong) bool {
	if other == nil {
		return false
	}
	if l.High > other.High {
		return true
	}
	if l.High == other.High {
		return l.Low > other.Low
	}
	return false
}
