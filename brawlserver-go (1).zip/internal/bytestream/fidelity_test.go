package bytestream

import (
	"encoding/json"
	"os"
	"testing"
)

func TestVIntFidelity(t *testing.T) {
	pyData, err := os.ReadFile("/tmp/py_vint.json")
	if err != nil {
		t.Skip("no python reference; run verify_py/writer_ref.py first")
	}
	var py map[string]string
	if err := json.Unmarshal(pyData, &py); err != nil {
		t.Fatal(err)
	}
	vals := make([]int, 0, 5000)
	vals = append(vals, makeRange(-2000, 2001)...)
	vals = append(vals, 10000, 100000, 1000000, -50000, 2147483647, -2147483648, 1410, 9999999, 69746974, 8640)
	mismatch := 0
	for _, v := range vals {
		w := NewWriter(nil, 0, 0)
		w.WriteVInt(v)
		goHex := hexEncode(w.Buffer)
		if py[toKey(v)] != goHex {
			mismatch++
			if mismatch < 10 {
				t.Errorf("v=%d go=%s py=%s", v, goHex, py[toKey(v)])
			}
		}
	}

	w := NewWriter(nil, 0, 0)
	w.WriteString(nil)
	if py["__str_none__"] != hexEncode(w.Buffer) {
		t.Errorf("str none mismatch go=%s py=%s", hexEncode(w.Buffer), py["__str_none__"])
	}
	w = NewWriter(nil, 0, 0)
	s := "hello"
	w.WriteString(&s)
	if py["__str_hello__"] != hexEncode(w.Buffer) {
		t.Errorf("str hello mismatch go=%s py=%s", hexEncode(w.Buffer), py["__str_hello__"])
	}
	if mismatch == 0 {
		t.Logf("VInt fidelity: %d values verified byte-identical to Python Writer", len(vals))
	}
}

func makeRange(lo, hi int) []int {
	out := make([]int, 0, hi-lo)
	for i := lo; i < hi; i++ {
		out = append(out, i)
	}
	return out
}

func toKey(v int) string {
	if v < 0 {
		b := []byte{'-'}
		n := -v
		if n == 0 {
			return "0"
		}
		var digits []byte
		for n > 0 {
			digits = append([]byte{byte('0' + n%10)}, digits...)
			n /= 10
		}
		return string(append(b, digits...))
	}
	if v == 0 {
		return "0"
	}
	var digits []byte
	n := v
	for n > 0 {
		digits = append([]byte{byte('0' + n%10)}, digits...)
		n /= 10
	}
	return string(digits)
}

func hexEncode(b []byte) string {
	const hexd = "0123456789abcdef"
	out := make([]byte, len(b)*2)
	for i, v := range b {
		out[i*2] = hexd[v>>4]
		out[i*2+1] = hexd[v&0x0f]
	}
	return string(out)
}
