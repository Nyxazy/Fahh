# Diferenças documentadas — Battle Result messages (Go × Python)

Este documento registra, com transparência total, as diferenças entre o port Go
e os três arquivos Python de resultado de batalha. O objetivo é preservar a
estrutura do projeto e o comportamento o máximo possível, eliminando apenas o
estritamente necessário para o Go compilar.

## 1. BattleResultMessage.py (classe VIVA — usada em AskForBattleEndMessage)

**Status: BYTE-IDENTICAL ao Python.**

Comparação automatizada (`internal/messages/battle_result_test.go`):
o mesmo conjunto de dados de entrada produz **9754 bytes idênticos** ao
`BattleResultMessage.py` original rodando na árvore Python extraída
(`/home/user/pyserver`). Teste: `TestBattleResultByteIdentical` — PASS.

Inclui fielmente:
- Seção de milestones (`Milestones.hexa`, 9696 bytes) via `WriteHexa`.
- Booleans bit-packed (estilo `Writer2.py`) via `WriteBoolBit` — não 1-byte.
- `DataReference(ID[0], ID[1])` e `DataReference(SkinID[0], ID[1])` exatos.
- Boolean "star player" (`writeBoolean(IsPlayer)` no loop de heróis).
- `player_exp - experience - star_player_exp` (com o termo star_player_exp).
- `writeDataReference(16, 0)` para o ícone não-usado.
- `writeBoolean(False)` final (Play Again = false).
- Index negativo do Python (`rankTrophies[rank-1]` com rank=0 → último elemento)
  reproduzido via `pyIdx()`.

## 2. BattleResultShowdownMessage.py (código MORTO no Python)

Importada em `AskForBattleEndMessage.py` (linha 12466) mas **nunca instanciada
nem chamada** em nenhum lugar do projeto. Portada como struct Go separada
`BattleResultShowdownMessage` para preservar a estrutura do projeto.

### Variáveis indefinidas no Python original (causariam `NameError` em runtime)

Estas variáveis são referenciadas em `encode()` mas **nunca atribuídas** em
lugar nenhum do arquivo nem recebidas como parâmetro:

| Variável Python | Valor no port Go | Observação |
|---|---|---|
| `tokens` | `0` | indefinida → NameError no Python |
| `trophiesinresult` | `0` | indefinida → NameError no Python |
| `doubledtokens` | `0` | indefinida → NameError no Python |
| `remainingtokens` | `0` | indefinida → NameError no Python |
| `result` | `0` | indefinida → NameError no Python |
| `brawler_trophies` | `0` | indefinida → NameError no Python |
| `brawler_trophies_for_rank` | `0` | indefinida → NameError no Python |
| `experience` | `0` | indefinida → NameError no Python |
| `startoken` | `0` | indefinida → NameError no Python |

Decisão: no port Go essas variáveis são declaradas como `0` (zero-value do
tipo) para que a classe exista e produza um stream **válido e não-crashing**.
Isso é o "estritamente necessário para eliminar erros de compilação do Go" —
em Go, ao contrário do Python, uma variável não pode ser referenciada sem ser
declarada. O comportamento preservado (stream válido) difere do Python apenas
no fato de não crashar; os bytes escritos correspondem ao caso em que todas as
variáveis indefinidas fossem zero.

### Persistências bugadas omitidas (documentadas)

O Python original contém, ao fim do encode:
```python
self.player.keysReward = tokens
self.player.trophiesReward = trophies
self.player.starkeysReward = startoken
DataBase.replaceValue(self, "keyReward", self.player.keysReward)
DataBase.replaceValue(self, "trReward", self.player.trophiesReward)
DataBase.replaceValue(self, "skReward", self.player.starkeysReward)
```

Estas linhas usam a sintaxe de método **não-vinculado** (`DataBase.replaceValue(self, ...)`)
passando `self` = a própria mensagem (não o DataBase), o que bugaria com
`AttributeError`. Além disso, `tokens`, `trophies` e `startoken` são indefinidas.
Como a classe é código morto (nunca chamada), esse bug nunca se manifesta.

Decisão: omitidas no port Go (não há equivalente de "chamada não-vinculada"),
documentadas aqui. Não afetam o stream.

Nota: esta classe estende `Writer` (1-byte bool), não `Writer2`. Portanto seus
booleans usam `WriteBoolean` (1-byte) no Go — fiel ao original.

## 3. BattleResultDuoShowdownMessage.py (código MORTO no Python)

Importada em `AskForBattleEndMessage.py` (linha 12468) mas **nunca instanciada
nem chamada**. Portada como struct Go separada `BattleResultDuoShowdownMessage`.

### Variáveis indefinidas no Python original

| Variável Python | Valor no port Go |
|---|---|
| `tokens` | `0` |
| `trophiesinresult` | `0` |
| `doubledtokens` | `0` |
| `remainingtokens` | `0` |
| `result` | `0` |
| `brawler_trophies` | `0` |
| `brawler_trophies_for_rank` | `0` |
| `experience` | `0` |

Mesma decisão que a Showdown: zero-values declarados, stream válido.

### Detalhe fiel preservado

Esta classe, ao contrário das outras, escreve o brawler/skin como
`writeVInt(16); writeVInt(brawler_id)` (dois VInts soltos) em vez de
`writeScId(16, brawler_id)`. O port Go reproduz isso exatamente
(`w.WriteVInt(16); w.WriteVInt(...)`).

Estende `Writer` (1-byte bool) → `WriteBoolean` no Go.

## Como reproduzir a comparação byte-a-byte

```bash
# 1. gerar stream Python de referência
cd /home/user/pyserver && python3 battle_ref.py > /tmp/py_battle.txt

# 2. rodar teste Go que compara
cd /home/user/brawlserver-go && go test ./internal/messages/ -run BattleResultByteIdentical -v
# saída esperada: BattleResultMessage BYTE-IDENTICAL: 9754 bytes match Python exactly
```
